<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedEtsy
 */

include_once _PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyCategory.php';

class AdminCedEtsyCategoryController extends ModuleAdminController
{
	public function __construct()
    {
        $this->db         = Db::getInstance();
        $this->CedEtsyCategory = new CedEtsyCategory;
        $this->bootstrap  = true;
        $this->table      = 'cedetsy_category';
        $this->identifier = 'category_id';
        $this->list_no_link = true;
        // $this->addRowAction('mapcategory');
        parent::__construct();
        $this->bulk_actions = array(
            'delete' => array(
                'text' => $this->l('Delete selected'),
                'icon' => 'icon-trash',
                'confirm' => $this->l('Delete selected items on Etsy ?')
            )
        );
        $this->fields_list = array(
            'category_id'       => array(
                'title' => 'Category ID',
                'type'  => 'text',
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ),
            'name'     => array(
                'title' => 'Category Name',
                'type'  => 'text',
            ),
            'path'     => array(
                'title' => 'Path',
                'type'  => 'text',
            ),
            'level'     => array(
                'title' => 'Level',
                'type'  => 'text',
            ),
        );

        if (Tools::getIsset('method') && 
            (trim(Tools::getValue('method'))) == 'fetchEtsyCategory'
        ) {
            $result = $this->CedEtsyCategory->fetchEtsyCategory();
            if(isset($result) && !empty($result)){
                $this->confirmations[] = 'Categories fetched successfully';
            } else {
                $this->errors[] = 'Error while fetching Categories';
            }
        }

        if (Tools::getIsset('method') && 
            (trim(Tools::getValue('method'))) == 'deleteEtsyCategory'
        ) {
            $result = $this->CedEtsyCategory->deleteEtsyCategory();
            if(isset($result) && !empty($result)){
                $this->confirmations[] = 'Categories deleted successfully';
            } else {
                $this->errors[] = 'Error while deleting Categories';
            }
        }
    }

    public function initPageHeaderToolbar()
    {
        if (empty($this->display)) {
            $this->page_header_toolbar_btn['fetch_category'] = array(
                'href' => self::$currentIndex . '&method=fetchEtsyCategory&token=' . $this->token,
                'desc' => $this->l('Fetch Taxonomy Category', null, null, false),
                'icon' => 'process-icon-download'
            );

            $this->page_header_toolbar_btn['add_category_mapping'] = array(
                'href' =>  'index.php?controller=AdminCedEtsyCatMapping&method=renderEditCatMapping&addcedetsy_category_mapping&token=' . $this->token,
                'desc' => $this->l('Add New Mapping', null, null, false),
                'icon' => 'process-icon-plus'
            );

            $this->page_header_toolbar_btn['delete_category'] = array(
                'href' => self::$currentIndex . '&method=deleteEtsyCategory&token=' . $this->token,
                'desc' => $this->l('Delete All Categories', null, null, false),
                'icon' => 'process-icon-delete'
            );
        }
        parent::initPageHeaderToolbar();
    }

    public function processBulkDelete()
    {
        $categoriesIds = $this->boxes;
        // echo '<pre>'; print_r($shippingIds); die;
        if(isset($categoriesIds) && !empty($categoriesIds))
        {
            try
            {
                $success = '';
                $failure = '';
                foreach($categoriesIds as $key => $categoryId)
                {
                    $res = $this->deleteCategory($categoryId);
                    if($res){
                        $success .=  $categoryId . ',';
                    } else {
                        $failure .=  $categoryId . ',';
                    }
                }
                if(!empty($success)){
                    $this->confirmations[] = 'Category ' . rtrim($success, ',') . ' deleted successfully';
                } else {
                    $this->errors[] = 'Error while deleting Category '. rtrim($failure, ',') ;
                }
            } catch (\Exception $e) {
                $this->CedEtsyHelper->log(
                    'AdminCedEtsyCategoryController:: processBulkDelete', 
                    'POST',
                    'Exception',
                    Tools::jsonEncode($e->getMessage()),
                    true
                );
                $this->errors[] = $e->getMessage();
            } catch (Etsy\EtsyRequestException $e) {
              $this->CedEtsyHelper->log(
                'AdminCedEtsyCategoryController:: processBulkDelete', 
                'POST',
                'EtsyRequestException',
                Tools::jsonEncode($e->getMessage()),
                true
                );
              
              $this->errors[] = $e->getMessage();
            } catch (Etsy\OAuthException $e) {
              $this->CedEtsyHelper->log(
                'AdminCedEtsyCategoryController:: processBulkDelete', 
                'POST',
                'OAuthException',
                Tools::jsonEncode($e->getMessage()),
                true
                );
              
              $this->errors[] = $e->getMessage();
            }
        } else {
            $this->errors[] = 'Please select Category';
        }
    }

    public function deleteCategory($id)
    {
        if (!empty($id)) {
            $res = $this->db->delete(
                'cedetsy_category',
                'category_id='.(int)$id
            );
            if ($res) {
                return true;
            }
        }
        return false;
    }

}