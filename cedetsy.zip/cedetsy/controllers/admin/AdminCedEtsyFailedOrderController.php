<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedEtsy
 */

include_once(_PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyHelper.php');

class AdminCedEtsyFailedOrderController extends ModuleAdminController
{
	public function __construct()
    {
        $this->bootstrap  = true;
        $this->table      = 'cedetsy_order_error';
        $this->identifier = 'id';
        $this->list_no_link = true;
        $this->addRowAction('cancel');
        $this->fields_list = array(
            'id'       => array(
                'title' => 'ID',
                'type'  => 'text',
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ),
            'sku' => array(
                'title' => 'SKU',
                'type'  => 'text',
            ),
            'order_id'     => array(
                'title' => 'Etsy Order ID',
                'type'  => 'text',
            ),
            'error_message'     => array(
                'title' => 'Reason',
                'type'  => 'text',
            ),
        );
        
        parent::__construct();
    }

    public function initToolbar()
    {
        $this->toolbar_btn['export'] = array(
            'href' => self::$currentIndex.'&export'.$this->table.'&token='.$this->token,
            'desc' => $this->l('Export')
        );
    }
}