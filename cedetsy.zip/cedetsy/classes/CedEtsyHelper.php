<?php

require_once(_PS_MODULE_DIR_ . 'cedetsy/lib/vendor/autoload.php');
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedEtsy
 */


class CedEtsyHelper
{
    public function getRequestAuthorization() {
        $ced_etsy_keystring       =   Configuration::get('CEDETSY_KEYSTRING');
        $ced_etsy_shared_secret   =   Configuration::get('CEDETSY_SHARED_SECRET');
        $access_token             =   Configuration::get('CEDETSY_API_ACCESS_TOKEN');
        $access_token_secret      =   Configuration::get('CEDETSY_API_ACCESS_TOKEN_SECRET');
        try {
            $client = new Etsy\EtsyClient($ced_etsy_keystring, $ced_etsy_shared_secret);
            $client->authorize($access_token, $access_token_secret);
            $api = new Etsy\EtsyApi($client);
            return $api;
        } catch (OAuthException $e) {
            error_log($e->getMessage());
            return false;
        }
    }

	public function log($method = '', $type = '', $message = '', $response = '', $force_log = false)
    {
        if (Configuration::get('CEDETSY_DEBUG_MODE') || $force_log == true) {
            $db = Db::getInstance();
            $db->insert(
                'cedetsy_logs',
                array(
                    'method' => pSQL($method),
                    'type' => pSQL($type),
                    'message' => pSQL($message),
                    'data' => pSQL($response, true),
                )
            );
        }
    }

    public function getCountries()
    {
        $country_collection = array();
        $db = Db::getInstance();
        
        $country = $db->ExecuteS("SELECT * FROM `". _DB_PREFIX_ ."cedetsy_country` ");
        
        if (isset($country) && !empty($country)) {
            $country_collection = $country;
        } else {
            try{
                if ($this->getRequestAuthorization()) {
                    $result = $this->getRequestAuthorization()->findAllCountry();
                    
                    if (isset($result['results']) && !empty($result['results'])) {
                        foreach ($result['results'] as $key => $country) {
                            $this->prepareCountry($country);
                        }
                        $country_collection = $result['results'];
                    } else {
                        $country_collection = 'Unable to fetch Country';
                    }
                } else {
                    $country_collection = 'Unable to fetch Country';
                }

            } catch(Etsy\EtsyRequestException $e)
            {
                $country_collection = $e->getMessage();
                $this->log(
                    'CedEtsyHelper::getCountries',
                     'GET', 
                     'Error while getting countries', 
                     $country_collection, 
                     true
                );
            }
        }
        
        return $country_collection;
    }

    public function prepareCountry($country)
    {
        $db = Db::getInstance();

        $db->insert(
            'cedetsy_country',
            array(
                'country_id' => pSQL($country['country_id']), 
                'iso_country_code' => pSQL($country['iso_country_code']), 
                'world_bank_country_code' => pSQL($country['world_bank_country_code']), 
                'name' => pSQL($country['name']), 
                'slug' => pSQL($country['slug']), 
                'lat' => pSQL($country['lat']), 
                'lon' => pSQL($country['lon'])
            )
        );
    }

    public function getAllShopSections()
    {
        $shop_templates_collection = array();
        $db = Db::getInstance();
        $shop_templates = $db->ExecuteS("SELECT * FROM `". _DB_PREFIX_ ."cedetsy_shop_sections`");
        if (isset($shop_templates) && !empty($shop_templates)) {
            $shop_templates_collection = $shop_templates;
        } else {
            try {
                if ($this->getRequestAuthorization()) {
                    $params = array('params' => array('shop_id' => Configuration::get('CEDETSY_SHOP_NAME')));
                    $result = $this->getRequestAuthorization()->findAllShopSections($params);
                    
                    if (isset($result['results']) && count($result['results'])) {
                        foreach ($result['results'] as $key => $category) {

                            $this->prepareShopSections($category);  
                        }
                        $shop_templates_collection = $result['results'];
                    } else {
                        $shop_templates_collection = 'Unable to fetch category';
                    }
                } else {
                    $shop_templates_collection = 'Unable to fetch category';
                }
            } catch (Etsy\EtsyRequestException $e) {
                $shop_templates_collection = $e->getMessage();
                $this->log(
                    'CedEtsyHelper::getAllShopSections',
                     'GET', 
                     'Error while getting shops', 
                     $shop_templates_collection, 
                     true
                );
            }
        }
        return $shop_templates_collection;
    }

    public function prepareShopSections($data)
    {
        $db = Db::getInstance();

        $db->insert(
            'cedetsy_shop_sections',
            array(
                'shop_section_id' => pSQL(Tools::jsonEncode($data['shop_section_id'])), 
                'title' => pSQL($data['title']), 
                'user_id' => pSQL($data['user_id']), 
                'rank' => pSQL($data['rank']), 
                'active_listing_count' => pSQL($data['active_listing_count'])
            )
        );
    }

    public function getDefaultFormFields()
    {
        try{
            $default_setting_array = array(

            array(
                'title' => 'CEDETSY_MATERIALS',
                'name' => 'materials',
                'type' => 'text',
                'validation' => 'string',
                ),
            array(
                'title' => 'CEDETSY_TAGS',
                'name' => 'tags',
                'type' => 'text',
                'validation' => 'string',
                ),
            array(
                'title' => 'CEDETSY_PROCESSING_MIN',
                'name' => 'processing_min',
                'type' => 'text',
                'validation' => 'int',
                ),
            array(
                'title' => 'CEDETSY_PROCESSING_MAX',
                'name' => 'processing_max',
                'type' => 'text',
                'validation' => 'int',
                ),
            array(
                'title' => 'CEDETSY_NON_TAXABLE',
                'name' => 'non_taxable',
                'type' => 'select',
                'values' => array('true' => 'Yes', 'false' =>' No'),
                ),
            array(
                'title' => 'CEDETSY_IS_SUPPLY',
                'name' => 'is_supply',
                'type' => 'select',
                'values' => array('true' => 'Yes', 'false' =>' No'),
                ),
            array(
                'title' => 'CEDETSY_STATE',
                'name' => 'state',
                'type' => 'select',
                'values' => array('active' => 'Active', 'draft' =>' Draft'),
                ),
            array(
                'title' => 'CEDETSY_WHO_MADE',
                'name' => 'who_made',
                'type' => 'select',
                'values' => array('i_did' => 'I Did', 'collective' =>' Collective', 'someone_else' => 'Someone Else'),
                ),

            array(
                'title' => 'CEDETSY_WHEN_MADE',
                'name' => 'when_made',
                'type' => 'select',
                'values' => array('made_to_order' => 'Made To Order', '2010_2018' =>' 2010 2018', '2000_2009' => '2000_2009','1999_1999' => '1999_1999', 'before_1999' => 'Before 1999', '1990_1998' => '1990_1998', '1980s' =>'1980s', '1970s' =>'1970s'
                    , '1960s' =>'1960s', '1950s' =>'1950s', '1940s' =>'1940s', '1930s' =>'1930s', '1920s' =>'1920s', '1910s' =>'1910s', '1900s' =>'1900s', '1800s' =>'1800s', '1700s' =>'1700s', 'before_1700' =>'Before 1700'),
                ),
            array(
                'title' => 'CEDETSY_RECIPIENT',
                'name' => 'recipient',
                'type' => 'select',
                'values' => array('men' => 'Men', 'women' =>' Women', 'unisex_adults' => 'Unisex Adults', 'teen_boys' => 'Teen Boys', 'teen_girls' => 'Teen Girls', 'teens'=>'Teens', 'boys'=>'Boys', 'girls'=>'Girls', 'children'=>'Children', 'baby_boys'=>'Baby Boys', 'baby_girls'=>'Baby Girls', 'babies'=>'Babies', 'birds'=>'Birds', 'cats'=>'Cats', 'dogs'=>'Dogs', 'pets'=>'Pets', 'not_specified'=>'Not Specified'),
                ),
            array(
                'title' => 'CEDETSY_OCCASION',
                'name' => 'occasion',
                'type' => 'select',
                'values' => array('anniversary' => 'Anniversary', 'baptism' =>' Baptism', 'bar_or_bat_mitzvah' => 'Bar Or Bat Mitzvah', 'birthday' =>' Birthday' , 'canada_day' =>' Canada Day', 'chinese_new_year' =>' Chinese New Year', 'cinco_de_mayo' =>' Cinco De Mayo', 'confirmation' =>' Confirmation', 'christmas' =>' Christmas', 'day_of_the_dead' =>' Day of The Dead', 'easter' =>' Easter', 'eid' =>' Eid', 'engagement' =>' Engagement','fathers_day'=>'Fathers Day', 'get_well' =>' Get Well', 'graduation' =>' Graduation', 'halloween' =>' Halloween', 'hanukkah' =>' Hanukkah', 'housewarming' =>' Housewarming', 'kwanzaa' =>' Kwanzaa', 'prom' =>' Prom', 'july_4th' =>' July 4th', 'mothers_day' =>' Mothers Day', 'new_baby' =>' new Baby', 'new_years' =>' New Years', 'quinceanera' =>' Quinceanera', 'retirement' =>' Retirement', 'st_patricks_day' =>' st_patricks_day', 'sweet_16' =>' sweet_16', 'sympathy' =>' sympathy', 'thanksgiving' =>' thanksgiving', 'valentines' =>' valentines', 'wedding' =>' wedding'),
                ),
            array(
                'title' => 'CEDETSY_STYLE',
                'name' => 'style',
                'type' => 'text',
                ),
            );
          return $default_setting_array;
        } catch(\Exception $e) {
            return $e->getMessage();
        }
    }
	
}