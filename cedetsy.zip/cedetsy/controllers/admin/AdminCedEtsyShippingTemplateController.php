<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedEtsy
 */

include_once _PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyHelper.php';
include_once _PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyShippingTemplate.php';

class AdminCedEtsyShippingTemplateController extends ModuleAdminController
{
	public function __construct()
    {
        $this->db         = Db::getInstance();
        $this->CedEtsyHelper  = new CedEtsyHelper;
        $this->CedEtsyShippingTemplate = new CedEtsyShippingTemplate;
        $this->bootstrap  = true;
        $this->table      = 'cedetsy_shipping_template';
        $this->identifier = 'shipping_template_id';
        $this->list_no_link = true;
        $this->explicitSelect = true;
        $this->addRowAction('edit');
        $this->addRowAction('deleteShipping');
        parent::__construct();
        $this->bulk_actions = array(
            'delete' => array(
                'text' => $this->l('Delete selected'),
                'icon' => 'icon-trash',
                'confirm' => $this->l('Delete selected items on Etsy ?')
            )
        );
        $this->fields_list = array(
            'shipping_template_id'       => array(
                'title' => 'Shipping Template ID',
                'type'  => 'text',
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ),
            'title'     => array(
                'title' => 'Shipping Title',
                'type'  => 'text',
            ),
            'processing_days_display_label'     => array(
                'title' => 'Display Lable',
                'type'  => 'text',
            ),
        );

        if (Tools::getIsset('method') && 
            (trim(Tools::getValue('method'))) == 'fetchShippingTemplate'
        ) {
            $result = $this->CedEtsyShippingTemplate->getAllShippingTemplates();
            if(isset($result) && !empty($result)){
                $this->confirmations[] = 'Shipping Template fetched successfully';
            } else {
                $this->errors[] = 'Error while fetching Shipping Templates';
            }
        }
        if (Tools::isSubmit('submitShippingSave')) {
            $this->saveShipping();
        }
        if (Tools::getIsset('created') && Tools::getValue('created')) {
            $this->confirmations[] = "Shipping Template created successfully";
        }
        if (Tools::getIsset('updated') && Tools::getValue('updated')) {
            $this->confirmations[] = "Shipping Template updated successfully";
        }

        if (Tools::getIsset('method') && 
            (trim(Tools::getValue('method'))) == 'deleteShippingTemplate'
        ) {
            $result = $this->CedEtsyShippingTemplate->deleteShippingTemplate();
            if(isset($result['success']) && $result['success'] == true){
                $this->confirmations[] = $result['message'];
            } else {
                $this->errors[] = $result['message'];
            }
        }
       
    }

    public function initPageHeaderToolbar()
    {
        if (empty($this->display)) {
            $this->page_header_toolbar_btn['fetch_shipping_template'] = array(
                'href' => self::$currentIndex . '&method=fetchShippingTemplate&token=' . $this->token,
                'desc' => $this->l('Fetch Shipping Template', null, null, false),
                'icon' => 'process-icon-download'
            );

            $this->page_header_toolbar_btn['add_shipping_template'] = array(
                'href' => self::$currentIndex . '&addcedetsy_shipping_template&token=' . $this->token,
                'desc' => $this->l('Add New Shipping Template', null, null, false),
                'icon' => 'process-icon-new'
            );

            $this->page_header_toolbar_btn['delete_shipping_template'] = array(
                'href' => self::$currentIndex . '&method=deleteShippingTemplate&token=' . $this->token,
                'desc' => $this->l('Delete All Templates', null, null, false),
                'icon' => 'process-icon-delete'
            );
        } elseif ($this->display == 'edit' || $this->display == 'add') {
            $this->page_header_toolbar_btn['backtolist'] = array(
                'href' => self::$currentIndex . '&token=' . $this->token,
                'desc' => $this->l('Back To List', null, null, false),
                'icon' => 'process-icon-back'
            );
        }
        parent::initPageHeaderToolbar();
    }

    public function postProcess()
    {
        if (Tools::getIsset('deleteShipping') && Tools::getValue('deleteShipping')) {
            $id = Tools::getValue('deleteShipping');
            $res = $this->deleteShipping($id);
            if ($res) {
                $this->confirmations[] = "Shipping Template ".$id." deleted successfully";
            } else {
                $this->errors[] = "Failed to delete Shipping Template ".$id;
            }
        }
        parent::postProcess();
    }

    public function displayDeleteMappingLink($token = null, $id = null)
    {
        $tpl = $this->createTemplate('helpers/list/list_action_delete.tpl');
        if (!array_key_exists('Delete', self::$cache_lang)) {
            self::$cache_lang['Delete'] = 'Delete';
        }

        $tpl->assign(array(
            'href' => self::$currentIndex.'&'.$this->identifier.'='.$id.'&deleteShipping='.$id.
                '&token='.($token != null ? $token : $this->token),
            'action' => self::$cache_lang['Delete'],
            'id' => $id
        ));
        return $tpl->fetch();
    }

    public function processBulkDelete()
    {
        $shippingIds = $this->boxes;
        // echo '<pre>'; print_r($shippingIds); die;
        if(isset($shippingIds) && !empty($shippingIds))
        {
            try
            {
                $success = '';
                $failure = '';
                foreach($shippingIds as $key => $shippingId)
                {
                    if ($this->CedEtsyHelper->getRequestAuthorization()) 
                    {
                        $params = array('params' =>array('shipping_template_id' => $shippingId));
                        $result = $this->CedEtsyHelper->getRequestAuthorization()->deleteShippingTemplate($params);
                        // echo '<pre>'; print_r($result); die;
                        if(!$result['count'])
                        {
                            $res = $this->deleteShipping($shippingId);
                        }
                        if($res){
                            $success .=  $shippingId . ',';
                        } else {
                            $failure .=  $shippingId . ',';
                        }
                    }
                }
                if(!empty($success)){
                    $this->confirmations[] = 'Shipping Template ' . rtrim($success, ',') . ' deleted successfully';
                } else {
                    $this->errors[] = 'Error while deleting Shipping Template '. rtrim($failure, ',') ;
                }
            } catch (\Exception $e) {
                $this->CedEtsyHelper->log(
                    'AdminCedEtsyShippingTemplateController:: processBulkDelete', 
                    'POST',
                    'Exception',
                    Tools::jsonEncode($e->getMessage()),
                    true
                );
                $this->errors[] = $e->getMessage();
            } catch (Etsy\EtsyRequestException $e) {
              $this->CedEtsyHelper->log(
                'AdminCedEtsyShippingTemplateController:: processBulkDelete', 
                'POST',
                'EtsyRequestException',
                Tools::jsonEncode($e->getMessage()),
                true
                );
              
              $this->errors[] = $e->getMessage();
            } catch (Etsy\OAuthException $e) {
              $this->CedEtsyHelper->log(
                'AdminCedEtsyShippingTemplateController:: processBulkDelete', 
                'POST',
                'OAuthException',
                Tools::jsonEncode($e->getMessage()),
                true
                );
              
              $this->errors[] = $e->getMessage();
            }
        } else {
            $this->errors[] = 'Please select Shipping Templates';
        }
    }

    public function deleteShipping($id)
    {
        if (!empty($id)) {
            $res = $this->db->delete(
                'cedetsy_shipping_template',
                'shipping_template_id='.(int)$id
            );
            if ($res) {
                return true;
            }
        }
        return false;
    }

    public function renderForm()
    {
        $countries = array();
        $idShipping = '';

        $countries = $this->CedEtsyHelper->getCountries();
        $idShipping = Tools::getValue('shipping_template_id');

        if (!empty($idShipping)) 
        {
            $shippingData = $this->CedEtsyShippingTemplate->getShippingDataById($idShipping);

            $this->context->smarty->assign(array(
                'shipping_title' => $shippingData['title'],
                'origin_country' => $shippingData['origin_country_id'],
                'primary_cost' => $shippingData['primary_cost'],
                'secondary_cost' => $shippingData['secondary_cost'],
                'destination_country' => $shippingData['destination_country_id'],
                'destination_region' => $shippingData['destination_region_id'],
                'min_processing_days' => $shippingData['min_processing_days'],
                'max_processing_days' => $shippingData['max_processing_days']
            ));
        }

        $this->context->smarty->assign(array('shippingId' => $idShipping));
        $this->context->smarty->assign(array(
            'controllerUrl' => $this->context->link->getAdminLink('AdminCedEtsyShippingTemplate'),
            'token' => $this->token,
            'countries' => $countries
        ));

        $shippingTemplate = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ . 'cedetsy/views/templates/admin/shipping_template/shipping_template_form.tpl'
        );
        parent::renderForm();
        return $shippingTemplate;
    }

    public function saveShipping()
    {
        $db = Db::getInstance();
        $getData = Tools::getAllValues();
        $data = array();
     
        $shippingId = Tools::getValue('id');
       // echo '<pre>'; print_r(Tools::getAllValues()); die;
       
        try {
            if (!empty($shippingId)) {
                $data['origin_country_id'] = isset($getData['origin_country']) ? (int) Tools::getValue('origin_country') : 0;
                $data['min_processing_days'] = isset($getData['min_processing_days']) ? (int) Tools::getValue('min_processing_days') : 0;
                    $data['max_processing_days'] = isset($getData['max_processing_days']) ? (int) Tools::getValue('max_processing_days') : 0;
                $params = array('params' => array('shipping_template_id' => $shippingId), 'data' => $data);
                if ($this->CedEtsyHelper->getRequestAuthorization()) {
                    $result = $this->CedEtsyHelper->getRequestAuthorization()->updateShippingTemplate($params);
                    if (isset($result['results']) && !empty($result['results'])) {
                        foreach ($result['results'] as $key => $shipping) {
                            
                            if(isset($shipping['Entries'])){
                                $Entries = end($shipping['Entries']);
                                $shipping = array_merge($shipping,$Entries);
                            }
                            $res = $db->update(
                                'cedetsy_shipping_template',
                                array(
                                   'shipping_template_id' => pSQL($shipping['shipping_template_id']),
                                   'title' => pSQL($shipping['title']),
                                   'user_id' => pSQL($shipping['user_id']),
                                   'min_processing_days' => pSQL($shipping['min_processing_days']),
                                   'max_processing_days' => pSQL($shipping['max_processing_days']),
                                   'processing_days_display_label' => pSQL($shipping['processing_days_display_label']),
                                   'origin_country_id' => pSQL($shipping['origin_country_id']),
                                   'destination_country_id' => pSQL($shipping['destination_country_id']),
                                   'secondary_cost' => pSQL($shipping['secondary_cost']),
                                   'primary_cost' => pSQL($shipping['primary_cost'])
                                ),
                                'shipping_template_id=' . (int)$shippingId
                            );  
                            if ($res) {
                                $link = new LinkCore();
                                $controller_link = $link->getAdminLink('AdminCedEtsyShippingTemplate').'&updated=1';
                                Tools::redirectAdmin($controller_link);
                                $this->confirmations[] = "Shipping template updated successfully";
                            }
                        }
                        $this->errors[] = 'No Response From Etsy';
                    } else {
                        $this->errors[] = 'No Response From Etsy';
                    }
                }
            } else {
                   $data['title'] = isset($getData['shipping_title']) ? Tools::getValue('shipping_title') : '';
                    $data['origin_country_id'] = isset($getData['origin_country']) ? (int) Tools::getValue('origin_country') : 0;
                    $data['primary_cost'] = isset($getData['primary_cost']) ? (float) Tools::getValue('primary_cost') : 0;
                    $data['secondary_cost'] = isset($getData['secondary_cost']) ? (float) Tools::getValue('secondary_cost') : 0;
                    $data['destination_country_id'] = isset($getData['destination_country']) ? (int) Tools::getValue('destination_country') : 0;
                    $data['destination_region_id'] = isset($getData['destination_region']) ? (int) Tools::getValue('destination_region') : 0;
                    $data['min_processing_days'] = isset($getData['min_processing_days']) ? (int) Tools::getValue('min_processing_days') : 0;
                    $data['max_processing_days'] = isset($getData['max_processing_days']) ? (int) Tools::getValue('max_processing_days') : 0;
                // echo '<pre>'; print_r($data); die;
                $params = array('data' => $data);
                if ($this->CedEtsyHelper->getRequestAuthorization()) {
                    $result = $this->CedEtsyHelper->getRequestAuthorization()->createShippingTemplate($params);
                    
                    if (isset($result['results']) && !empty($result['results'])) {
                        
                        foreach ($result['results'] as $key => $category) 
                        {
                            if(isset($category['Entries'])){
                                    $Entries = end($category['Entries']);
                                    $category = array_merge($category,$Entries);
                                }
                            $res = $this->CedEtsyHelper->prepareShippingTemplates($category);
                            if ($res) {
                                $link = new LinkCore();
                                $controller_link = $link->getAdminLink('AdminCedEtsyShippingTemplate').'&created=1';
                                Tools::redirectAdmin($controller_link);
                                $this->confirmations[] = "Shipping template created successfully";
                            }
                        }
                        $this->errors[] = 'No Response From Etsy';
                    } else {
                        $this->errors[] = 'No Response From Etsy';
                    }
                }
            }
        } catch (\Exception $e) {
            $this->CedEtsyHelper->log(
                'AdminCedEtsyShippingTemplateController:: saveShipping', 
                'POST',
                'Exception',
                Tools::jsonEncode($e->getMessage()),
                true
            );
            $this->errors[] = $e->getMessage();
        } catch (Etsy\EtsyRequestException $e) {
          $this->CedEtsyHelper->log(
            'AdminCedEtsyShippingTemplateController:: saveShipping', 
            'POST',
            'EtsyRequestException',
            Tools::jsonEncode($e->getMessage()),
            true
            );
          
          $this->errors[] = $e->getMessage();
        } catch (Etsy\OAuthException $e) {
          $this->CedEtsyHelper->log(
            'AdminCedEtsyShippingTemplateController:: saveShipping', 
            'POST',
            'OAuthException',
            Tools::jsonEncode($e->getMessage()),
            true
            );
          
          $this->errors[] = $e->getMessage();
        } 
    }

}