<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedEtsy
 */

include_once(_PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyHelper.php');

class CedEtsyOrder
{
	public function __construct()
    {
        $this->db = Db::getInstance();
        $this->CedEtsyHelper = new CedEtsyHelper;
        $this->lang = ((int)Configuration::get('CEDETSY_LANGUAGE_STORE')) ? (int)Configuration::get('CEDETSY_LANGUAGE_STORE') : (int)Configuration::get('PS_LANG_DEFAULT');
    }

	public function fetchOrder()
    {
    	$ced_etsy_shop_name = Configuration::get('CEDETSY_SHOP_NAME');
        $params = array('params' => array('shop_id' => $ced_etsy_shop_name, 'status' => 'open'));
        try {
        	if($this->CedEtsyHelper->getRequestAuthorization()) 
        	{
        		$response = $this->CedEtsyHelper->getRequestAuthorization()->findAllShopReceiptsByStatus($params);
        		$this->CedEtsyHelper->log(
		        	'CedEtsyOrder::fetchedOrders',
		        	'GET',
		        	'EtsyRequestException Fetch Order Response',
		        	Tools::jsonEncode($response),
		        	true
		        );
        		$response = array( 'results' => array(unserialize('a:48:{s:10:"receipt_id";i:1234931330;s:12:"receipt_type";i:0;s:8:"order_id";i:563405866;s:14:"seller_user_id";i:110813817;s:13:"buyer_user_id";i:122622638;s:12:"creation_tsz";i:1507265692;s:17:"last_modified_tsz";i:1507265743;s:4:"name";s:12:"Sheila Welch";s:10:"first_line";s:15:"4338 Meadow ave";s:11:"second_line";s:0:"";s:4:"city";s:6:"Newton";s:5:"state";s:2:"IA";s:3:"zip";i:50208;s:17:"formatted_address";s:0:"";s:10:"country_id";i:209;s:14:"payment_method";s:2:"cc";s:13:"payment_email";s:0:"";s:19:"message_from_seller";s:0:"";s:18:"message_from_buyer";s:0:"";s:8:"was_paid";i:1;s:14:"total_tax_cost";d:0;s:14:"total_vat_cost";d:0;s:11:"total_price";d:28.969999999999998863131622783839702606201171875;s:19:"total_shipping_cost";d:6.95000000000000017763568394002504646778106689453125;s:13:"currency_code";s:3:"USD";s:20:"message_from_payment";s:0:"";s:11:"was_shipped";s:0:"";s:11:"buyer_email";s:21:"welchs31717@gmail.com";s:12:"seller_email";s:19:"cornelio@arteza.com";s:7:"is_gift";s:0:"";s:15:"needs_gift_wrap";s:0:"";s:12:"gift_message";s:0:"";s:15:"gift_wrap_price";i:0;s:12:"discount_amt";d:20.280000000000001136868377216160297393798828125;s:8:"subtotal";d:8.6899999999999995026200849679298698902130126953125;s:10:"grandtotal";d:15.6400000000000005684341886080801486968994140625;s:19:"adjusted_grandtotal";d:15.6400000000000005684341886080801486968994140625;s:22:"shipping_tracking_code";s:0:"";s:21:"shipping_tracking_url";s:0:"";s:16:"shipping_carrier";s:0:"";s:13:"shipping_note";s:0:"";s:26:"shipping_notification_date";s:0:"";s:9:"shipments";a:0:{}s:16:"shipping_details";a:6:{s:19:"can_mark_as_shipped";i:1;s:11:"was_shipped";s:0:"";s:18:"is_future_shipment";i:1;s:26:"has_free_shipping_discount";s:0:"";s:25:"not_shipped_state_display";s:11:"Not Shipped";s:15:"shipping_method";s:17:"Standard Shipping";}s:25:"transparent_price_message";s:0:"";s:18:"show_channel_badge";s:0:"";s:27:"channel_badge_suffix_string";s:0:"";s:5:"items";a:1:{i:0;a:26:{s:14:"transaction_id";i:1338547397;s:5:"title";s:63:"Arteza Detail Paint Brush - Hand Made - Taklon Hair (Set of 15)";s:11:"description";s:34:"MINIATURE & DETAIL PAINT BRUSH SET";s:14:"seller_user_id";i:110813817;s:13:"buyer_user_id";i:122622638;s:12:"creation_tsz";i:1507265692;s:8:"paid_tsz";i:1507265705;s:11:"shipped_tsz";s:0:"";s:5:"price";d:28.969999999999998863131622783839702606201171875;s:13:"currency_code";s:3:"USD";s:8:"quantity";i:1;s:4:"tags";a:0:{}s:9:"materials";a:0:{}s:16:"image_listing_id";i:1175307680;s:10:"receipt_id";i:1234931330;s:13:"shipping_cost";d:0;s:10:"is_digital";s:0:"";s:9:"file_data";s:0:"";s:10:"listing_id";i:509275814;s:13:"is_quick_sale";s:0:"";s:18:"seller_feedback_id";s:0:"";s:17:"buyer_feedback_id";s:0:"";s:16:"transaction_type";s:7:"listing";s:3:"url";s:43:"https://www.etsy.com/transaction/1338547397";s:10:"variations";a:0:{}s:12:"product_data";a:5:{s:10:"product_id";i:1190676925;s:3:"sku";s:7:"demo_13";s:15:"property_values";a:0:{}s:9:"offerings";a:1:{i:0;a:5:{s:11:"offering_id";i:1372705468;s:5:"price";a:6:{s:6:"amount";i:2897;s:7:"divisor";i:100;s:13:"currency_code";s:3:"USD";s:24:"currency_formatted_short";s:6:"$28.97";s:23:"currency_formatted_long";s:10:"$28.97 USD";s:22:"currency_formatted_raw";d:28.969999999999998863131622783839702606201171875;}s:8:"quantity";i:936;s:10:"is_enabled";i:1;s:10:"is_deleted";i:0;}}s:10:"is_deleted";i:0;}}}}'))); 

                if ($response && isset($response['results']['0']) && !empty($response['results']['0'])) 
                {
                	$order_ids = array();
                	foreach ($response['results'] as $key => $order) 
                	{
                		$isOrderExists = false;
                        if(isset($order['order_id']) && $order['order_id'])
                        {
                            $isOrderExists = $this->isEtsyOrderIdExist($order['order_id']);
                            if($isOrderExists)
	                        {
	                        	continue;
	                        } else {
	                        	if(count($order) > 0 && isset($order['order_id']) && !$isOrderExists)
		                        {
		                        	$order_ids[] = $this->prepareOrderData($order);
		                        }
	                        }
                        }
                	}
	                if (count($order_ids) == 0) 
	                {
	                    return array('success' => true, 'message' => 'No new order found.');
	                } else {
	                    return array('success' => true, 'message' => $order_ids );
	                }
                } else {
                    return array('success' => true, 'message' => 'No new order found.');
                }
        	}
        } catch (Etsy\OAuthException $e) {
            $this->CedEtsyHelper->log(
            	'CedEtsyOrder::fetchedOrders',
            	'GET',
            	'OAuthException Fetch Order',
            	Tools::jsonEncode($e->getMessage()),
            	true
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
        catch (Etsy\EtsyRequestException $e) {
        	$this->CedEtsyHelper->log(
            	'CedEtsyOrder::fetchedOrders',
            	'GET',
            	'EtsyRequestException Fetch Order',
            	Tools::jsonEncode($e->getLastResponse()),
            	true
            );
            return array('success' => false, 'message' => $e->getLastResponse());
        }
        catch (Etsy\EtsyResponseException $e) {
        	$this->CedEtsyHelper->log(
            	'CedEtsyOrder::fetchedOrders',
            	'GET',
            	'EtsyRequestException Fetch Order',
            	Tools::jsonEncode($e->getResponse()),
            	true
            );
            return array('success' => false, 'message' => $e->getResponse());
        } catch (Exception $e) {
        	$this->CedEtsyHelper->log(
            	'CedEtsyOrder::fetchedOrders',
            	'GET',
            	'Exception Fetch Order',
            	Tools::jsonEncode($e->getMessage()),
            	true
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
    }

    public function isEtsyOrderIdExist($etsy_order_id = 0)
    {
        $isExist = false;
        if ($etsy_order_id) {
            $sql = "SELECT `id` FROM `" . _DB_PREFIX_ . "cedetsy_order` 
            WHERE `order_id` = '" . pSQL($etsy_order_id) . "'";
            $result = $this->db->ExecuteS($sql);
            if (is_array($result) && count($result)) {
                $isExist = true;
            }
        }
        return $isExist;
    }

    public function prepareOrderData($data = array())
    {
        if ($data) {
            if (!$this->isEtsyOrderIdExist($data['order_id'])) {
                $id = $this->createPrestashopOrder($data);
                if ($id) {
                    $prestashop_order_id = $id;
                    $this->db->insert(
                        'cedetsy_order',
                        array(
                        	'order_id' => pSQL($data['order_id']),
                            'prestashop_order_id' => (int)$prestashop_order_id,
                            'status' => pSQL('Created'),
                            'order_data' => pSQL(Tools::jsonEncode($data)),
                        )
                    );
                    return $id;
                }
            }
        }
        return null;
    }

    public function createPrestashopOrder($data)
    {
    	$firstname = '';
    	$lastname = '';
    	// echo '<pre>'; print_r($data); die;
        $contexts = Context::getContext();
        $prestashop_order_id = '';
        $etsy_order_id = $data['order_id'];
        if(isset($data['name']) && $data['name']!='') 
        {
            $name = explode(' ',$data['name']);

            if(isset($name['0']) && $name['0']!="") {
                $firstname = $name['0'];
            }

            if(isset($name['1']) && $name['1']!="") {
                $lastname = $name['1'];
            }
        }
        
        $email = isset($data['buyer_email']) ? $data['buyer_email'] : $data['order_id'] . '@etsycustomer.com';
        $phone = '';
        $id_lang = $contexts->language->id;
        $id_customer = 0;
        if ((int)Configuration::get('CEDETSY_CUSTOMER_ID')) {
            $config_id_customer = (int)Configuration::get('CEDETSY_CUSTOMER_ID');
            $customer = new Customer($config_id_customer);
            if (isset($customer->id) && $customer->id) {
                $id_customer = (int)$customer->id;
            }
        } elseif (Customer::customerExists($email)) {
            $customer = Customer::getCustomersByEmail($email);
            if (isset($customer[0]) && isset($customer[0]['id_customer']) && $customer[0]['id_customer']) {
                $id_customer = (int)$customer[0]['id_customer'];
            }
        }
        if (!$id_customer) {
            $new_customer = new Customer();
            $new_customer->email = $email;
            $new_customer->lastname = $lastname;
            $new_customer->firstname = $firstname;
            $new_customer->passwd = 'etsy@123';
            $new_customer->add();
            $id_customer = (int)$new_customer->id;
        }
        $contexts->customer = new Customer($id_customer);
        $state = isset($data['state']) ? $data['state'] : '';
        $id_country = $data['country_id'];
        $getLocalizationDetails = $this->getLocalizationDetails($state, $id_country);
        $id_state = $getLocalizationDetails['zone_id'];

        $address_shipping = new Address();
        $address_shipping->id_customer = $id_customer;
        $address_shipping->id_country = $id_country;
        $address_shipping->alias = $firstname . ' ' . time();
        $address_shipping->firstname = $firstname;
        $address_shipping->lastname = $lastname;
        $address_shipping->id_state = $id_state;
        $address_shipping->address1 = isset($data['first_line']) ? $data['first_line'] : '';
        $address_shipping->address2 = isset($data['second_line']) ? $data['second_line'] : '';
        $address_shipping->postcode = isset($data['zip']) ? $data['zip'] : '';
        $address_shipping->city = isset($data['city']) ? $data['city'] : '';
        if ($phone && Validate::isPhoneNumber($phone)) {
            $address_shipping->phone = $phone;
        }
        $address_shipping->add();
        $address_id_shipping = $address_shipping->id;

        $address_invoice = new Address();
        $address_invoice->id_customer = $id_customer;
        $address_invoice->id_country = $id_country;
        $address_invoice->alias = $firstname . ' ' . time();
        $address_invoice->firstname = $firstname;
        $address_invoice->lastname = $lastname;
        $address_invoice->id_state = $id_state;
        $address_invoice->address1 = isset($data['first_line']) ? $data['first_line'] : '';
        $address_invoice->address2 = isset($data['second_line']) ? $data['second_line'] : '';
        $address_invoice->postcode = isset($data['zip']) ? $data['zip'] : '';
        $address_invoice->city = isset($data['city']) ? $data['city'] : '';
        if ($phone && Validate::isPhoneNumber($phone)) {
            $address_invoice->phone = $phone;
        }
        $address_invoice->add();
        $address_id_invoice = $address_invoice->id;

        $payment_module = isset($data['payment_method']) ? $data['payment_method'] : Configuration::get('CEDETSY_ORDER_PAYMENT');
        $module_id = 0;
        $sql = 'SELECT DISTINCT m.`id_module`, h.`id_hook`, m.`name`, hm.`position` 
                FROM `' . _DB_PREFIX_ . 'module` m LEFT JOIN `' . _DB_PREFIX_ . 'hook_module` hm 
                ON hm.`id_module` = m.`id_module` LEFT JOIN `' . _DB_PREFIX_ . 'hook` h 
                ON hm.`id_hook` = h.`id_hook` GROUP BY hm.id_hook, hm.id_module 
                ORDER BY hm.`position`, m.`name` DESC';
        $modules_list = $this->db->executeS($sql);
        foreach ($modules_list as $module) {
            $module_obj = ModuleCore::getInstanceById($module['id_module']);
            if (isset($module_obj->name) && $module_obj->name == $payment_module) {
                $module_id = $module['id_module'];
                break;
            }
        }
        $context = (array)$contexts;
        $currency = isset($context['currency']) ? (array)$context['currency'] : array();

        if (Configuration::get('PS_CURRENCY_DEFAULT')) {
            $id_currency = Configuration::get('PS_CURRENCY_DEFAULT');
        } else {
            $id_currency = isset($currency['id']) ? $currency['id'] : '0';
        }

        if (!$id_currency) {
            $currency_id = $this->db->executeS('SELECT `id_currency` FROM `' . _DB_PREFIX_ . 'module_currency` 
            WHERE `id_module` = ' . (int)$module_id);
            $id_currency = isset($currency_id['0']['id_currency']) ? $currency_id['0']['id_currency'] : 0;
        }
        if(!empty(Configuration::get('CEDETSY_CARRIER_ID'))){
        	$order_carrier = Configuration::get('CEDETSY_CARRIER_ID');
        } elseif(!empty($data['shipping_carrier'])) {
            $order_carrier = $data['shipping_carrier'];
        } else {
        	$order_carrier = 0;
        }
        
        $cart = new Cart();
        $cart->id_customer = $id_customer;
        $cart->id_address_delivery = $address_id_shipping;
        $cart->id_address_invoice = $address_id_invoice;
        $cart->id_currency = (int)$id_currency;
        $cart->id_carrier = $order_carrier;
        $cart->recyclable = 0;
        $cart->gift = 0;
        $cart->add();
        $cart_id = (int)($cart->id);
        $order_total = 0;

        $final_shipping_cost = isset($data['total_shipping_cost']) ? $data['total_shipping_cost'] : 0;
        $shipping_cost_vat = 0;

        $order_total += $final_shipping_cost;
        if (isset($data['items']) && count($data['items']))
        {
            $order_items = $data['items'];
            $final_item_cost = 0;
            $total_vat = 0;
            $productArray = array();
            foreach ($order_items as $orderLine => $item) 
            {
                $cancelQty = 0;
                $sku = isset($item['product_data']['sku']) ? $item['product_data']['sku'] : '';
                $etsyProductId = isset($item['product_data']['product_id']) ? $item['product_data']['product_id'] : '';

                $id_product = $this->getProductIdByReference($sku);
                if (!$id_product) {
                    $id_product = $this->getVariantProductIdByReference($sku);
                }
                $id_product_attribute = $this->getProductAttributeIdByReference($sku);
                $qty = isset($item['quantity']) ? $item['quantity'] : '0';
                $producToAdd = new Product((int)($id_product), true, (int)($id_lang));
                if ((!$producToAdd->id)) {
                    $this->orderErrorInformation(
                        $sku,
                        $etsy_order_id,
                        "PRODUCT ID" . $id_product . " DOES NOT EXIST",
                        $data
                    );
                    continue;
                }
                if (!$producToAdd->active) {
                    $this->orderErrorInformation(
                        $sku,
                        $etsy_order_id,
                        "PRODUCT STATUS IS DISABLED WITH ID " . $id_product . "",
                        $data
                    );
                    continue;
                }
                if (!$producToAdd->checkQty((int)$qty)) 
                {
                    $availableQuantity = StockAvailable::getQuantityAvailableByProduct($id_product, $id_product_attribute);
                    if ($qty > $availableQuantity) 
                    {
                        $this->orderErrorInformation(
                            $sku,
                            $etsy_order_id,
                            "REQUESTED QUANTITY FOR PRODUCT ID " . $id_product . " IS NOT AVAILABLE",
                            $orderData
                        );
                        return false;
                    }
                }
                $cart->updateQty((int)($qty), (int)($id_product), (int)$id_product_attribute);
                $cart->update();

                $item_cost = isset($item['price']) ? (float)$item['price'] : 0;
                $item_vat = 0;
                $productArray[$id_product] = array(
                    'reference' => $sku,
                    'id_product' => $id_product,
                    'price_tax_included' => $item_cost,
                    'price_tax_excluded' => $item_cost - $item_vat,
                    'quantity' => $qty
                );
                $total_cost = $item_cost * (int)$qty;
                $total_vat += $item_vat * (int)$qty;
                $final_item_cost += (float)$total_cost;
            }
            $order_total += $final_item_cost;
            if (count($productArray)) {
                $extra_vars = array();
                $extra_vars['item_shipping_cost'] = $final_shipping_cost;
                $extra_vars['total_paid'] = $order_total;
                $extra_vars['total_item_cost'] = $final_item_cost;
                $extra_vars['total_item_tax'] = $total_vat;
                $extra_vars['item_shipping_tax'] = $shipping_cost_vat;
                $extra_vars['merchant_order_id'] = $etsy_order_id;
                $extra_vars['customer_reference_order_id'] = $etsy_order_id;
                $secure_key = false;
                $id_shop = (int)Context::getContext()->shop->id;
                $shop = new Shop($id_shop);
            }
            if (!empty($productArray)) {
                $prestashop_order_id = $this->addOrderInPrestashop(
                    $cart_id,
                    $id_customer,
                    $address_id_shipping,
                    $address_id_invoice,
                    $order_carrier,
                    $id_currency,
                    $extra_vars,
                    $productArray,
                    $secure_key,
                    $contexts,
                    $shop,
                    $payment_module
                );
                if (!empty($prestashop_order_id)) {
                    return $prestashop_order_id;
                }
            } else {
                return false;
            }
            return false;
        }
    }

    public function addOrderInPrestashop(
        $id_cart,
        $id_customer,
        $id_address_delivery,
        $id_address_invoice,
        $id_carrier,
        $id_currency,
        $extra_vars,
        $products,
        $secure_key,
        $context,
        $shop,
        $payment_module
    ) {
        $context->cart = new Cart($id_cart);
        $newOrder = new Order();
        $carrier = new Carrier($id_carrier, $context->cart->id_lang);
        $newOrder->id_address_delivery = $id_address_delivery;
        $newOrder->id_address_invoice = $id_address_invoice;
        $newOrder->id_shop_group = $shop->id_shop_group;
        $newOrder->id_shop = isset($shop->id) ? $shop->id: '';
        $newOrder->id_cart = $id_cart;
        $newOrder->id_currency = $id_currency;
        $newOrder->id_lang = $context->language->id;
        $newOrder->id_customer = $id_customer;
        $newOrder->id_carrier = $id_carrier;
        $newOrder->current_state = Configuration::get('CEDETSY_ORDER_STATE');
        $newOrder->secure_key = (
        $secure_key ? pSQL($secure_key) : pSQL($context->customer->secure_key)
        );
        $newOrder->payment = $payment_module ? $payment_module : 'Cedetsy Payment';
        $newOrder->module = 'cedetsy';
        $newOrder->conversion_rate = $context->currency->conversion_rate;
        $newOrder->recyclable = $context->cart->recyclable;
        $newOrder->gift = (int)$context->cart->gift;
        $newOrder->gift_message = $context->cart->gift_message;
        $newOrder->mobile_theme = $context->cart->mobile_theme;
        $newOrder->total_discounts = 0;
        $newOrder->total_discounts_tax_incl = 0;
        $newOrder->total_discounts_tax_excl = 0;
        $newOrder->total_paid = $extra_vars['total_paid'];
        $newOrder->total_paid_tax_incl = $extra_vars['total_paid'];
        $newOrder->total_paid_tax_excl = $extra_vars['total_paid'];
        $newOrder->total_paid_real = $extra_vars['total_paid'];
        $newOrder->total_products = $extra_vars['total_item_cost'];
        $newOrder->total_products_wt = $extra_vars['total_item_cost'];
        $newOrder->total_shipping = $extra_vars['item_shipping_cost'];
        $newOrder->total_shipping_tax_incl = $extra_vars['item_shipping_cost'];
        $newOrder->total_shipping_tax_excl = $extra_vars['item_shipping_cost'] - $extra_vars['item_shipping_tax'];
        if (!is_null($carrier) && Validate::isLoadedObject($carrier)) 
        {
            $newOrder->carrier_tax_rate = $carrier->getTaxesRate(
                new Address($context->cart->{Configuration::get('PS_TAX_ADDRESS_TYPE')})
            );
        }
        $newOrder->total_wrapping = 0;
        $newOrder->total_wrapping_tax_incl = 0;
        $newOrder->total_wrapping_tax_excl = 0;
        $newOrder->invoice_date = '0000-00-00 00:00:00';
        $newOrder->delivery_date = '0000-00-00 00:00:00';
        $newOrder->valid = true;
        do {
            $reference = Order::generateReference();
        } while (Order::getByReference($reference)->count());
        $newOrder->reference = $reference;
        $newOrder->round_mode = Configuration::get('PS_PRICE_ROUND_MODE');
        $packageList = $context->cart->getProducts(true);
        foreach ($packageList as &$product) {
            if (array_key_exists($product['id_product'], $products)) {
                $product['price'] = $products[$product['id_product']]['price_tax_excluded'];
                $product['price_wt'] = $products[$product['id_product']]['price_tax_included'];
                $product['total'] = $products[$product['id_product']]['price_tax_excluded'] *
                    $products[$product['id_product']]['quantity'];
                $product['total_wt'] = $products[$product['id_product']]['price_tax_included'] *
                    $products[$product['id_product']]['quantity'];
            }
        }
                $orderItems = $packageList;
        $newOrder->product_list = $orderItems;
        $res = $newOrder->add(true, false);
        if (!$res) {
            PrestaShopLogger::addLog(
                'Order cannot be created',
                3,
                null,
                'Cart',
                (int)$id_cart,
                true
            );
            throw new PrestaShopException('Can\'t add Order');
        }
        if ($newOrder->id_carrier) {
            $newOrderCarrier = new OrderCarrier();
            $newOrderCarrier->id_order = (int)$newOrder->id;
            $newOrderCarrier->id_carrier = (int)$newOrder->id_carrier;
            $newOrderCarrier->weight = (float)$newOrder->getTotalWeight();
            $newOrderCarrier->shipping_cost_tax_excl = $newOrder->total_shipping_tax_excl;
            $newOrderCarrier->shipping_cost_tax_incl = $newOrder->total_shipping_tax_incl;
            $newOrderCarrier->add();
        }
        if (isset($newOrder->product_list) && count($newOrder->product_list)) {
            foreach ($newOrder->product_list as $productLine) {
                $order_detail = new OrderDetail();
                $order_detail->id_order = (int)$newOrder->id;
                $order_detail->id_order_invoice = $productLine['id_address_delivery'];
                $order_detail->product_id = $productLine['id_product'];
                $order_detail->id_shop = $productLine['id_shop'];
                $order_detail->id_warehouse = 0;
                $order_detail->product_attribute_id = $productLine['id_product_attribute'];
                $order_detail->product_name = $productLine['name'];
                $order_detail->product_quantity = $productLine['cart_quantity'];
                $order_detail->product_quantity_in_stock = $productLine['quantity_available'];
                $order_detail->product_price = $productLine['price'];
                $order_detail->unit_price_tax_incl = $productLine['price_wt'];
                $order_detail->unit_price_tax_excl = $productLine['price'];
                $order_detail->total_price_tax_incl = $productLine['total_wt'];
                $order_detail->total_price_tax_excl = $productLine['total'];
                $order_detail->product_ean13 = $productLine['ean13'];
                $order_detail->product_upc = $productLine['upc'];
                $order_detail->product_reference = $productLine['reference'];
                $order_detail->product_supplier_reference = $productLine['supplier_reference'];
                $order_detail->product_weight = $productLine['weight'];
                $order_detail->ecotax = $productLine['ecotax'];
                $order_detail->discount_quantity_applied = $productLine['quantity_discount_applies'];
                $o_res = $order_detail->add();
                if (!$o_res) {
                    $newOrder->delete();
                    PrestaShopLogger::addLog(
                        'Order details cannot be created',
                        3,
                        null,
                        'Cart',
                        (int)$id_cart,
                        true
                    );
                    throw new PrestaShopException('Can\'t add Order details');
                }
            }
            Hook::exec(
                'actionValidateOrder',
                array(
                    'cart' => $context->cart,
                    'order' => $newOrder,
                    'customer' => $context->customer,
                    'currency' => $context->currency,
                    'orderStatus' => Configuration::get('CEDETSY_ORDER_STATE')
                )
            );

            $order_status = new OrderState(
                (int)Configuration::get('CEDETSY_ORDER_STATE'),
                (int)$context->language->id
            );
            foreach ($context->cart->getProducts() as $product) {
                if ($order_status->logable) {
                    ProductSale::addProductSale(
                        (int)$product['id_product'],
                        (int)$product['cart_quantity']
                    );
                }
            }

            // Set the order status
            $new_history = new OrderHistory();
            $new_history->id_order = (int)$newOrder->id;
            $new_history->changeIdOrderState((int)Configuration::get('CEDETSY_ORDER_STATE'), $newOrder, true);
            $new_history->add(true, $extra_vars);

            // Switch to back order if needed
            if (Configuration::get('PS_STOCK_MANAGEMENT') && $order_detail->getStockState()) {
                $history = new OrderHistory();
                $history->id_order = (int)$newOrder->id;
                $history->changeIdOrderState(
                    Configuration::get(
                        $newOrder->valid ? 'PS_OS_OUTOFSTOCK_PAID' : 'PS_OS_OUTOFSTOCK_UNPAID'
                    ),
                    $newOrder,
                    true
                );
                $history->add();
            }


            // Order is reloaded because the status just changed

            // Send an e-mail to customer (one order = one email)

            //  updates stock in shops
            $product_list = $newOrder->getProducts();
            foreach ($product_list as $product) {
                $idProd = $product['product_id'];
                $idProdAttr = $product['product_attribute_id'];
                $qtyToReduce = (int)$product['product_quantity']*-1;
                StockAvailable::updateQuantity($idProd, $idProdAttr, $qtyToReduce, $newOrder->id_shop);
            }
            if (isset($newOrder->id) && $newOrder->id) {
                return $newOrder->id;
            }
        }
        return false;
    }

     public function getLocalizationDetails($Statecode, $country_id)
    {
        // $sql = "SELECT c.id_country, cl.name FROM `" . _DB_PREFIX_ . "country` c
        //  LEFT JOIN `" . _DB_PREFIX_ . "country_lang` cl on (c.id_country =cl.id_country)
        //   WHERE `iso_code` LIKE '" . pSQL($countryCode) . "' AND cl.id_lang ='" . (int)$this->lang . "'";
         $Execute = $this->db->ExecuteS("SELECT `name` FROM `" . _DB_PREFIX_ . "cedetsy_country` WHERE `country_id` = '" . pSQL($country_id) . "' ");
        if (is_array($Execute) && count($Execute) && isset($Execute['0'])) {
            $country_name = '';
            if (isset($Execute['0']['name']) && $Execute['0']['name']) {
                $country_name = $Execute['0']['name'];
            }
            if ($country_id) {
                $Execute = $this->db->ExecuteS("SELECT `id_state`,`name` FROM 
                 `" . _DB_PREFIX_ . "state` WHERE `iso_code`='" . $Statecode . "'");
                if (is_array($Execute) && count($Execute)) 
                {
                    if (isset($Execute['0']['id_state']) && isset($Execute['0']['name'])) {
                        return array(
                            'zone_id' => $Execute['0']['id_state'],
                            'name' => $Execute['0']['name'],
                            'country_name' => $country_name
                        );
                    };
                } else {
                    return array(
                        'zone_id' => '',
                        'name' => '',
                        'country_name' => $country_name
                    );
                }
            } else {
                return array(
                    'zone_id' => '',
                    'name' => '',
                    'country_name' => ''
                );
            }
        } else {
            return array(
                'zone_id' => '',
                'name' => '',
                'country_name' => ''
            );
        }
    }

    public function getProductIdByReference($merchant_sku)
    {
    	$product_id = '';
        $product_id = Db::getInstance()->getValue(
            'Select `id_product` FROM `' . _DB_PREFIX_ . 'product` 
            WHERE `reference`="' . pSQL($merchant_sku) . '"'
        );
        return $product_id;
    }

    public function getVariantProductIdByReference($merchant_sku)
    {
    	$variant_product_id = '';
        $variant_product_id =  Db::getInstance()->getValue(
            'Select `id_product` FROM `' . _DB_PREFIX_ . 'product_attribute` 
            WHERE `reference`="' . pSQL($merchant_sku) . '"'
        );
        return $variant_product_id;
    }

    public static function getProductAttributeIdByReference($merchant_sku)
    {
    	$attribute_id = '';
        $attribute_id = Db::getInstance()->getValue(
            'Select `id_product_attribute` FROM `'._DB_PREFIX_.'product_attribute` WHERE `reference`="'.
            pSQL($merchant_sku).'"'
        );
        return $attribute_id;
    }

    public function orderErrorInformation($sku, $etsyOrderId, $reason, $orderData)
    {
        $sql_check_already_exists = "SELECT * FROM `" . _DB_PREFIX_ . "cedetsy_order_error` 
        WHERE `sku`='" . pSQL($sku) . "' AND `order_id`='" . pSQL($etsyOrderId) . "'";
        $Execute_check_already_exists = $this->db->ExecuteS($sql_check_already_exists);
        if (count($Execute_check_already_exists) == 0) 
        {
            $sql_insert = "INSERT INTO `" . _DB_PREFIX_ . "cedetsy_order_error` (
            `sku`,`order_id`,`error_message`,`order_data`)
            VALUES('" . pSQL($sku) . "','" . pSQL($etsyOrderId) . "','" . pSQL($reason) . "',
            '" . pSQL(Tools::jsonEncode($orderData)) . "')";
            $result = $this->db->Execute($sql_insert);
        }
    }

    public function addTracking($receipt_id, $shop_id, $params) {
        try {
            if($this->CedEtsyHelper->getRequestAuthorization()) {
                $tracking_response = $this->CedEtsyHelper->getRequestAuthorization()->submitTracking(array('data' => $params, 'params' => array('receipt_id' => (int)$receipt_id,'shop_id' => $shop_id )));
                return $tracking_response;
            }
        } catch (Etsy\OAuthException $e) {
            $this->CedEtsyHelper->log(
            	'CedEtsyOrder::addTracking',
            	'POST',
            	'OAuthException Add Tracking',
            	Tools::jsonEncode($e->getMessage()),
            	true
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
        catch (Etsy\EtsyRequestException $e) {
        	$this->CedEtsyHelper->log(
            	'CedEtsyOrder::addTracking',
            	'POST',
            	'EtsyRequestException Add Tracking',
            	Tools::jsonEncode($e->getLastResponse()),
            	true
            );
            return array('success' => false, 'message' => $e->getLastResponse());
        }
        catch (Etsy\EtsyResponseException $e) {
        	$this->CedEtsyHelper->log(
            	'CedEtsyOrder::addTracking',
            	'POST',
            	'EtsyRequestException Add Tracking',
            	Tools::jsonEncode($e->getResponse()),
            	true
            );
            return array('success' => false, 'message' => $e->getResponse());
        } catch (Exception $e) {
        	$this->CedEtsyHelper->log(
            	'CedEtsyOrder::addTracking',
            	'POST',
            	'Exception Add Tracking',
            	Tools::jsonEncode($e->getMessage()),
            	true
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
    }

    public function updateReceipt($receipt_id, $shop_id, $params) 
    {
        try {
            if($this->CedEtsyHelper->getRequestAuthorization()) {
            	$params = array();
                $tracking_response = $this->CedEtsyHelper->getRequestAuthorization()->updateReceipt(array('data' => $params, 'params' => array('receipt_id' => (int)$receipt_id,'shop_id' => $shop_id )));
                return $tracking_response;
            }
        } catch (Etsy\OAuthException $e) {
            $this->CedEtsyHelper->log(
            	'CedEtsyOrder::updateReceipt',
            	'POST',
            	'OAuthException Update Receipt',
            	Tools::jsonEncode($e->getMessage()),
            	true
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
        catch (Etsy\EtsyRequestException $e) {
        	$this->CedEtsyHelper->log(
            	'CedEtsyOrder::updateReceipt',
            	'POST',
            	'EtsyRequestException Update Receipt',
            	Tools::jsonEncode($e->getLastResponse()),
            	true
            );
            return array('success' => false, 'message' => $e->getLastResponse());
        }
        catch (Etsy\EtsyResponseException $e) {
        	$this->CedEtsyHelper->log(
            	'CedEtsyOrder::updateReceipt',
            	'POST',
            	'EtsyRequestException Update Receipt',
            	Tools::jsonEncode($e->getResponse()),
            	true
            );
            return array('success' => false, 'message' => $e->getResponse());
        } catch (Exception $e) {
        	$this->CedEtsyHelper->log(
            	'CedEtsyOrder::updateReceipt',
            	'POST',
            	'Exception Update Receipt',
            	Tools::jsonEncode($e->getMessage()),
            	true
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
	
}