<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedEtsy
 */

include_once(_PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyHelper.php');
include_once(_PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyOrder.php');

class AdminCedEtsyOrderController extends ModuleAdminController
{
	public $toolbar_title;

    protected $statuses_array = array();
    protected $bulk_actions;
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'order';
        $this->className = 'Order';
        $this->lang = false;
        $this->addRowAction('view');
        $this->addRowAction('acknowledge');
        $this->addRowAction('reject');
        
        $this->explicitSelect = true;
        $this->allow_export = true;
        $this->deleted = false;
        $this->context = Context::getContext();
        $this->db = Db::getInstance();
        $this->CedEtsyHelper = new CedEtsyHelper;
        $this->CedEtsyOrder = new CedEtsyOrder;

        $this->_select = '
        a.id_currency,
        a.id_order AS id_pdf,
        CONCAT(LEFT(c.`firstname`, 1), \'. \', c.`lastname`) AS `customer`,
        osl.`name` AS `osname`,
        os.`color`,
        IF((SELECT so.id_order FROM `'._DB_PREFIX_.'orders` so WHERE so.id_customer = a.id_customer
         AND so.id_order < a.id_order LIMIT 1) > 0, 0, 1) as new,
        country_lang.name as cname,
        IF(a.valid, 1, 0) badge_success';

        $this->_join = '
        LEFT JOIN `'._DB_PREFIX_.'customer` c ON (c.`id_customer` = a.`id_customer`)
        JOIN `'._DB_PREFIX_.'cedetsy_order` wo ON (wo.`prestashop_order_id` = a.`id_order`)
        LEFT JOIN `'._DB_PREFIX_.'address` address ON address.id_address = a.id_address_delivery
        LEFT JOIN `'._DB_PREFIX_.'country` country ON address.id_country = country.id_country
        LEFT JOIN `'._DB_PREFIX_.'country_lang` country_lang 
        ON (country.`id_country` = country_lang.`id_country` 
        AND country_lang.`id_lang` = '.(int)$this->context->language->id.')
        LEFT JOIN `'._DB_PREFIX_.'order_state` os 
        ON (os.`id_order_state` = a.`current_state`)
        LEFT JOIN `'._DB_PREFIX_.'order_state_lang` osl 
        ON (os.`id_order_state` = osl.`id_order_state` 
        AND osl.`id_lang` = '.(int)$this->context->language->id.')';
        $this->_orderBy = 'id_order';
        $this->_orderWay = 'DESC';
        $this->_use_found_rows = true;

        $statuses = OrderState::getOrderStates((int)$this->context->language->id);
        foreach ($statuses as $status) {
            $this->statuses_array[$status['id_order_state']] = $status['name'];
        }

        $this->fields_list = array(
            'id_order' => array(
                'title' => 'ID',
                'align' => 'text-center',
                'class' => 'fixed-width-xs'
            ),
            'order_id' => array(
                'title' => 'Purchase Order ID',
                'align' => 'text-center',
                'class' => 'fixed-width-xs'
            ),
            'reference' => array(
                'title' => 'Reference'
            ),
            'customer' => array(
                'title' => 'Customer',
                'havingFilter' => true,
            ),
        );

        $this->fields_list = array_merge($this->fields_list, array(
            'total_paid_tax_incl' => array(
                'title' => 'Total',
                'align' => 'text-right',
                'type' => 'price',
                'currency' => true,
                'callback' => 'setOrderCurrency',
                'badge_success' => true
            ),
            'payment' => array(
                'title' => 'Payment'
            ),
            'osname' => array(
                'title' => 'Status',
                'type' => 'select',
                'color' => 'color',
                'list' => $this->statuses_array,
                'filter_key' => 'os!id_order_state',
                'filter_type' => 'int',
                'order_key' => 'osname'
            ),
            'date_add' => array(
                'title' => 'Date',
                'align' => 'text-right',
                'type' => 'datetime',
                'filter_key' => 'a!date_add'
            )
            
        ));

            $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->ExecuteS('
            SELECT DISTINCT c.id_country, cl.`name`
            FROM `'._DB_PREFIX_.'orders` o
            '.Shop::addSqlAssociation('orders', 'o').'
            INNER JOIN `'._DB_PREFIX_.'address` a ON a.id_address = o.id_address_delivery
            INNER JOIN `'._DB_PREFIX_.'country` c ON a.id_country = c.id_country
            INNER JOIN `'._DB_PREFIX_.'country_lang` cl 
            ON (c.`id_country` = cl.`id_country` 
            AND cl.`id_lang` = '.(int)$this->context->language->id.')
            ORDER BY cl.name ASC');

            $country_array = array();
        foreach ($result as $row) {
            $country_array[$row['id_country']] = $row['name'];
        }

            $part1 = array_slice($this->fields_list, 0, 3);
            $part2 = array_slice($this->fields_list, 3);
            $part1['cname'] = array(
                'title' => 'Delivery',
                'type' => 'select',
                'list' => $country_array,
                'filter_key' => 'country!id_country',
                'filter_type' => 'int',
                'order_key' => 'cname'
            );
            $this->fields_list = array_merge($part1, $part2);

        $this->shopLinkType = 'shop';
        $this->shopShareDatas = Shop::SHARE_ORDER;

        if (Tools::isSubmit('id_order')) {
            $order = new Order((int)Tools::getValue('id_order'));
            $this->context->cart = new Cart($order->id_cart);
            $this->context->customer = new Customer($order->id_customer);
        }

        $this->bulk_actions = array(
            'accept' => array('text' => 'Accept Order', 'icon' => 'icon-refresh'),
            'cancal' => array('text' => 'Cancel Order', 'icon' => 'icon-trash'),
        );
        parent::__construct();
    }

    public static function setOrderCurrency($echo, $tr)
    {
        $order = new Order($tr['id_order']);
        return Tools::displayPrice($echo, (int)$order->id_currency);
    }
    // public function initContent()
    // {
    //     parent::initContent();
    // }

    public function initPageHeaderToolbar()
    {
        if (empty($this->display)) {
            $this->page_header_toolbar_btn['new_order'] = array(
                'href' => self::$currentIndex.'&fetchOrder&token='.$this->token,
                'desc' => 'Fetch Order',
                'icon' => 'process-icon-new'
            );
        }
        parent::initPageHeaderToolbar();
    }

    public function initToolbar()
    {
        if ($this->display == 'view') {
            /** @var Order $order */
            $order = $this->loadObject();
            $customer = $this->context->customer;

            if (!Validate::isLoadedObject($order)) {
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminCedEtsyOrder'));
            }
            $this->toolbar_title[] = sprintf(
                'Order %1$s from %2$s %3$s',
                $order->reference,
                $customer->firstname,
                $customer->lastname
            );
            $this->addMetaTitle($this->toolbar_title[count($this->toolbar_title) - 1]);
        }
    }

    public function renderList()
    {
        if (Tools::isSubmit('submitBulkacceptorder'.$this->table)) {
            if (Tools::getIsset('cancel')) {
                Tools::redirectAdmin(self::$currentIndex.'&token='.$this->token);
            }

            $this->tpl_list_vars['updateOrderStatus_mode'] = true;
            $this->tpl_list_vars['order_statuses'] = $this->statuses_array;
            $this->tpl_list_vars['REQUEST_URI'] = $_SERVER['REQUEST_URI'];
            $this->tpl_list_vars['POST'] = $_POST;
        }
        if (Tools::getIsset('fetchOrder')) {
            try {
                    $order_data = $this->CedEtsyOrder->fetchOrder();
                    if (isset($order_data['success']) && $order_data['success']) 
                    {
                        $this->confirmations[] = Tools::jsonEncode($order_data['message']);
                    } elseif (isset($order_data['message'])) {
                        $this->errors[] = $order_data['message']; 
                    } else {
                        $this->errors[] = 'Can not fetch Order';
                    }
            } catch (\Exception $e) {
                $this->CedEtsyHelper->log(
                    'AdminCedEtsyOrderController::FetchOrder',
                    'GET',
                    'Exception',
                    Tools::jsonEncode($e->getMessage()),
                    true
                );
            }
        }
        return parent::renderList();
    }

    public function renderView()
    {
        $order = $this->loadObject();
        $order_data = (array)$order;
        $id_order = 0;
        if (isset($order_data['id']) && $order_data['id']) {
            $id_order = $order_data['id'];
        }
        if ($id_order) {
            $sql = "SELECT `order_data` FROM `"._DB_PREFIX_."cedetsy_order` 
            WHERE `prestashop_order_id` = '".(int)$id_order."'";
            $db = Db::getInstance();
            $result = $db->ExecuteS($sql);
            
            if (is_array($result) && !empty($result) && isset($result['0']['order_data'])) 
            {
                if (Tools::stripslashes($result['0']['order_data'])) 
                {
                    $order_data = Tools::jsonDecode(Tools::stripslashes(trim($result['0']['order_data'], '"')), true);
                    // echo '<pre>'; print_r($order_data); die;

                    $this->context->smarty->assign(array('order_info' => array()));
                    if ($order_data) 
                    {
                      // Order Info

                        $order_info['OrderID'] = $order_data['order_id'];
                        $order_info['ReceiptID'] = $order_data['receipt_id'];
                        $order_info['OrderCreateDate'] = date('d-m-Y H:i:s', $order_data['creation_tsz']);
                        $order_info['TotalPrice'] = $order_data['total_price'];
                        $order_info['TotalShippingCost'] = $order_data['total_shipping_cost'];
                        $order_info['PaymentMethod'] = $order_data['payment_method'];
                        $order_info['ShippingCarrier'] = $order_data['shipping_carrier'];

                        $this->context->smarty->assign(array('order_info'  => $order_info));

                        // Customer Info

                        $customer_info = array();
                        $stateCountry = $this->CedEtsyOrder->getLocalizationDetails($order_data['state'], $order_data['country_id']);

                        $customer_info = array(
                        	'Name' => $order_data['name'],
                        	'Email' => $order_data['buyer_email'],
                        	'Address' => $order_data['first_line'] . ' ' . $order_data['second_line'],
                        	'City' => $order_data['city'],
                        	'State' => $stateCountry['name'],
                        	'ZipCode' => $order_data['zip'],
                        	'Country' => $stateCountry['country_name'],
                        	);

                        $this->context->smarty->assign(array('customer_info'  => $customer_info));

                        // Payment Info

                        $payment_info = array();

                        $payment_info = array(
                        	'Name' => $order_data['name'],
                        	'Email' => $order_data['payment_email'],
                        	'Address' => $order_data['first_line'] . ' ' . $order_data['second_line'],
                        	'CityZip' => $order_data['city'] . ' - ' . $order_data['zip'],
                        	'StateCountry' => $stateCountry['name'] . ' , ' . $stateCountry['country_name'],
                        	'PaymentMethod' => $order_data['payment_method'],
                        	);

                        $this->context->smarty->assign(array('payment_info'  => $payment_info));

                        // Shipping Info

                        $shipping_info = array();

                        $shipping_info = array(
                        	'Name' => $order_data['name'],
                        	'Address' => $order_data['first_line'] . ' ' . $order_data['second_line'],
                        	'CityZip' => $order_data['city'] . ' - ' . $order_data['zip'],
                        	'StateCountry' => $stateCountry['name'] . ' , ' . $stateCountry['country_name'],
                        	'ShippingMethod' => $order_data['shipping_details']['shipping_method'],
                        	'Status' => $order_data['shipping_details']['not_shipped_state_display'],
                        	'ShippingCarrier' => $order_data['shipping_carrier']
                        	);

                        $this->context->smarty->assign(array('shipping_info'  => $shipping_info));

                        // Product Info

                        $orderLines = array();
                        $subTotal = '0';
                        $total = '0';
                        foreach($order_data['items'] as $key => $value)
                        {
                        	$total = $value['price'] * $value['quantity'];
                        	$orderLines[$key] = array(
                        		'sku' => $value['product_data']['sku'],
                        		'title' => $value['title'],
                        		'quantity' => $value['quantity'],
								'price' => $value['price'],
								'total' => $total
                        		);
                        	$subTotal += $total;
                        }
                        unset($order_data['items']);

                        $this->context->smarty->assign(array(
                        	'orderLines'  => $orderLines,
                        	'subtotal' => $subTotal,
                        	'total_shipping_cost' => $order_data['total_shipping_cost'],
                        	'total_price' => $subTotal + $order_data['total_shipping_cost'],
                        	));

                        // Ship Whole Order

                        $this->context->smarty->assign(array(
                        	'trackingUrl'  => $order_data['shipping_tracking_url'],
                        	'shipping_tracking_code' => $order_data['shipping_tracking_code'],
                        	'shipping_carrier' => $order_data['shipping_carrier'],
                        	));
                    }
                   
                    $this->context->smarty->assign('id_order', $id_order);
                    $this->context->smarty->assign('token', $this->token);
                    $parent = $this->context->smarty->fetch(
                        _PS_MODULE_DIR_ .'cedetsy/views/templates/admin/order/form.tpl'
                    );
                    parent::renderForm();
                    return $parent;
                }
            }
        }
    }

    public function ajaxProcessShipOrder()
    {
    	$post_data = Tools::getAllValues();

    	$receipt_id = 0;
    	if(isset($post_data['receipt_id'])) {
    		$receipt_id = (int)$post_data['receipt_id'];
    		unset($post_data['receipt_id']);
    	}
    	if(!$receipt_id) {
    		die(Tools::jsonEncode(array('success' => false, 'message' => 'Receipt ID not found!')));
    	}

    	$shop_id = Configuration::get('CEDETSY_SHOP_NAME');
    	if(!$shop_id) {
    		die(Tools::jsonEncode(array('success' => false, 'message' => 'Shop ID not found!')));
    	}
    	$result = $this->CedEtsyOrder->addTracking($receipt_id, $shop_id, array('tracking_code' => (string)$post_data['tracking_code'], 'carrier_name' => (string)$post_data['carrier_name'], 'send_bcc' => (boolean)$post_data['send_bcc']));
    	
    	if(isset($result['success']) && $result['success']) {
			die(Tools::jsonEncode(array('success' => true, 'message' => 'Updated Successfully.')));
		} else {
			die(Tools::jsonEncode($result));
		}
    	
    }

    public function ajaxProcessUpdateReceipt()
    {
    	$post_data = Tools::getAllValues();
    	
    	$receipt_id = 0;
    	if(isset($post_data['receipt_id'])) {
    		$receipt_id = (int)$post_data['receipt_id'];
    		unset($post_data['receipt_id']);
    	}
    	if(!$receipt_id) {
    		die(Tools::jsonEncode(array('success' => false, 'message' => 'Receipt ID not found!')));
    	}

    	$shop_id = Configuration::get('CEDETSY_SHOP_NAME');
    	if(!$shop_id) {
    		die(Tools::jsonEncode(array('success' => false, 'message' => 'Shop ID not found!')));
    	}
    	$result = $this->CedEtsyOrder->updateReceipt($receipt_id, $shop_id, array('was_paid' => (boolean)$post_data['was_paid'], 'was_shipped' => (boolean)$post_data['was_shipped']));

    	if(isset($result['success']) && $result['success']) {
			die(Tools::jsonEncode(array('success' => true, 'message' => 'Updated Successfully.')));
		} else {
			die(Tools::jsonEncode($result));
		}
    }

}