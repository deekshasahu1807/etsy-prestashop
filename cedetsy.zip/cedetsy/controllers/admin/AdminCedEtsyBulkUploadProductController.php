<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedEtsy
 */

include_once _PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyHelper.php';
include_once _PS_MODULE_DIR_.'cedetsy/classes/CedEtsyProduct.php';

class AdminCedEtsyBulkUploadProductController extends ModuleAdminController
{
	public function __construct()
    {
        // die('ok');
        $this->bootstrap = true;
        $this->db = Db::getInstance();
        $this->CedEtsyProduct = new CedEtsyProduct;
        $this->CedEtsyHelper = new CedEtsyHelper;
        parent::__construct();
    }

    public function initContent()
    {
        //die('jk');
        parent::initContent();
        $smarty = $this->context->smarty;

        $productIds = array();
        $query = $this->db->ExecuteS("SELECT `store_category` FROM `" . _DB_PREFIX_ . "cedetsy_category_mapping` WHERE `store_category` != '' ORDER BY `store_category` DESC");
                
        if (is_array($query) && count($query)) {
            foreach ($query as $value) {
                if (isset($value['store_category']) && $value['store_category']) {
                    $value['store_category'] = Tools::jsonDecode($value['store_category'], true);

                    $query = $this->db->ExecuteS("SELECT cp.`id_product` 
                            FROM `" . _DB_PREFIX_ . "category_product` cp
                            JOIN `"._DB_PREFIX_."product` p ON (p.id_product = cp.`id_product`)
                            WHERE  `id_category` IN (" . implode(',', (array)$value['store_category']) . ")");
                    if (is_array($query) && count($query)) {
                        foreach ($query as $val) {
                            if (isset($val['id_product']) && $val['id_product']) {
                                $product_ids[] = $val['id_product'];
                            }
                        }
                    }
                }
            }
        }
        $product_ids = array_unique($product_ids);
       
        $this->context->smarty->assign(array(
            'upload_array' => addslashes(json_encode($productIds))
        ));
        $link = new LinkCore();
        $controllerUrl = $link->getAdminLink('AdminCedEtsyBulkUploadProduct') . '&bulkUpload=true';
        $token = $this->token;
        $this->context->smarty->assign(array('controllerUrl' => $controllerUrl));
        $this->context->smarty->assign(array('token' => $token));

        $total_product = count($product_ids);
        $array_chunk_count = ceil($total_product/10);
        $product_ids = array_chunk($product_ids, $array_chunk_count);

        $content = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ . 'cedetsy/views/templates/admin/product/bulk_upload.tpl'
        );
        $this->context->smarty->assign(array(
            'content' => $this->content . $content
        ));
    }

    public function ajaxProcessBulkUpload()
    {
    	try 
    	{
	        if (is_array(Tools::getValue('selected')) && count(Tools::getValue('selected'))) 
	        {
	            $product_ids = Tools::getValue('selected');
	            $errors = array();
	            $successes = array();
	            //foreach ($ids as $id) {
	                $response = $this->CedEtsyProduct->uploadProducts($product_ids);
	                
	                if (isset($response) && is_array($response)) {
	                	if (isset($response['success']) && $response['success'] == true) {
	                		$successes[] = $response['message'].'<br>';
	                	} else {
	                		$errors[] = $response['message'];
	                	}
	                    // foreach ($response as $rep) {
	                    //     if (isset($rep['success']) && $rep['success'] == true) {
	                    //         $successes[] = $rep['message'].'<br>';
	                    //     } elseif (isset($rep['error']) && is_array($rep['error'])) {
	                    //         foreach ($rep['error'] as $err) {
	                    //             $errors[] = $err;
	                    //         }
	                    //     } else {
	                    //         $errors[] = $rep['message'];
	                    //     }
	                    // }
	                }
	            //}
	            die(Tools::jsonEncode(
	                array(
	                   'status' => true,
	                   'response' => array(
	                       'success' => $successes,
	                       'errors' => $errors,
	                   )
	                )
	            ));
	        }
        } catch(\Exception $e) {
        	$this->CedEtsyHelper->log(
                'AdminCedEtsyBulkUploadProductController::UploadAll',
                'POST',
                'Exception Product Bulk Upload',
                $e->getMessage(),
                true
            );
            die(Tools::jsonEncode(array(
                'status' => false,
                'message' => $e->getMessage()
            )));
        }
    }
}