<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedEtsy
 */

include_once _PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyHelper.php';
include_once _PS_MODULE_DIR_.'cedetsy/classes/CedEtsyProduct.php';

class AdminCedEtsyProductController extends ModuleAdminController
{
	/**
     * @var string name of the tab to display
     */
    protected $tab_display;

    protected $object;

    protected $product_attributes;

    protected $position_identifier = 'id_product';

    protected $submitted_tabs;

    protected $id_current_category;

    public function __construct()
    {
        $this->context = Context::getContext();
        $this->bootstrap = true;
        $this->table = 'product';
        $this->className = 'Product';
        $this->lang = false;
        $this->list_no_link = true;
        $this->explicitSelect = true;
        $this->CedEtsyProduct = new CedEtsyProduct;
        $this->bulk_actions = array(
            'upload' => array(
                'text' => ('Upload Selected'),
                'icon' => 'icon-upload',
            ),
            'enable' => array(
                'text' => ('Enable Selected'),
                'icon' => 'icon-refresh',
            ),
            'disable' => array(
                'text' => ('Disable Selected'),
                'icon' => 'icon-refresh',
            ),
            'remove' => array(
                'text' => ('Remove From Etsy'),
                'icon' => 'icon-trash',
            )
        );
        if (!Tools::getValue('id_product')) {
            $this->multishop_context_group = false;
        }

        parent::__construct();
         /* Join categories table */
        if ($id_category = (int)Tools::getValue('productFilter_cl!name')) {
            $this->_category = new Category((int)$id_category);
            $_POST['productFilter_cl!name'] = $this->_category->name[$this->context->language->id];
        } else {
            if ($id_category = (int)Tools::getValue('id_category')) {
                $this->id_current_category = $id_category;
                $this->context->cookie->id_category_products_filter = $id_category;
            } elseif ($id_category = $this->context->cookie->id_category_products_filter) {
                $this->id_current_category = $id_category;
            }
            if ($this->id_current_category) {
                $this->_category = new Category((int)$this->id_current_category);
            } else {
                $this->_category = new Category();
            }
        }
        $this->_join .= '
        LEFT JOIN `'._DB_PREFIX_.'stock_available` sav ON (sav.`id_product` = a.`id_product` 
        AND sav.`id_product_attribute` = 0
        '.StockAvailable::addSqlShopRestriction(null, null, 'sav').') ';

        $alias = 'sa';
        $alias_image = 'image_shop';

        $id_shop = Shop::isFeatureActive() && Shop::getContext() == Shop::CONTEXT_SHOP ?
            (int)$this->context->shop->id : 'a.id_shop_default';

        $catgories =array();
        
            $CedEtsyProduct = new CedEtsyProduct;
            $mapped_categories = $CedEtsyProduct->getMappedCategoryIds();
            $mapped_categories = array_unique($mapped_categories);

            if (is_array($mapped_categories) && count($mapped_categories)) {
                $catgories = $mapped_categories;
                if (count($catgories)) {
                    $this->_join .= ' JOIN `'._DB_PREFIX_.'product_shop` sa ON (a.`id_product` = sa.`id_product` AND sa.id_shop = '.$id_shop.')

                LEFT JOIN `'._DB_PREFIX_.'product_lang` b ON (a.`id_product` = b.id_product 
                AND b.id_shop = '.$id_shop.' AND b.`id_lang`="'.(int)$this->context->language->id.'")

                LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON ('.$alias.'.`id_category_default` = cl.`id_category` 
                AND b.`id_lang` = cl.`id_lang` AND cl.id_shop = '.$id_shop.')
                LEFT JOIN `'._DB_PREFIX_.'shop` shop ON (shop.id_shop = '.$id_shop.')
                LEFT JOIN `'._DB_PREFIX_.'cedetsy_product` wp ON (wp.product_id = a.`id_product`)
                LEFT JOIN `'._DB_PREFIX_.'image_shop` image_shop ON (image_shop.`id_product` = a.`id_product` 
                AND image_shop.`cover` = 1 AND image_shop.id_shop = '.$id_shop.')
                LEFT JOIN `'._DB_PREFIX_.'image` i ON (i.`id_image` = image_shop.`id_image`)
                LEFT JOIN `'._DB_PREFIX_.'product_download` pd ON (pd.`id_product` = a.`id_product` 
                AND pd.`active` = 1)';
                }
            } else {
                $this->_join .= ' JOIN `'._DB_PREFIX_.'product_shop` sa ON (a.`id_product` = sa.`id_product` AND sa.id_shop = '.$id_shop.')

                LEFT JOIN `'._DB_PREFIX_.'product_lang` b ON (a.`id_product` = b.id_product 
                AND b.id_shop = '.$id_shop.' AND b.`id_lang`="'.(int)$this->context->language->id.'")

                LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON ('.$alias.'.`id_category_default` = cl.`id_category` 
                AND b.`id_lang` = cl.`id_lang` AND cl.id_shop = '.$id_shop.')
                LEFT JOIN `'._DB_PREFIX_.'shop` shop ON (shop.id_shop = '.$id_shop.')
                JOIN `'._DB_PREFIX_.'cedetsy_product` wp ON (wp.product_id = a.`id_product`)
                LEFT JOIN `'._DB_PREFIX_.'image_shop` image_shop ON (image_shop.`id_product` = a.`id_product` 
                AND image_shop.`cover` = 1 AND image_shop.id_shop = '.$id_shop.')
                LEFT JOIN `'._DB_PREFIX_.'image` i ON (i.`id_image` = image_shop.`id_image`)
                LEFT JOIN `'._DB_PREFIX_.'product_download` pd ON (pd.`id_product` = a.`id_product` 
                AND pd.`active` = 1)';
            }

        $this->_select .= 'shop.`name` AS `shopname`, a.`id_shop_default`, ';
        
        $this->_select .= $alias_image.'.`id_image` AS `id_image`, a.`id_product` as `id_temp`, cl.`name` 
        AS `name_category`, '.$alias.'.`price`, 0 
        AS `price_final`, a.`is_virtual`, pd.`nb_downloadable`, sav.`quantity` 
        AS `sav_quantity`, '.$alias.'.`active`, IF(sav.`quantity`<=0, 1, 0) AS `badge_danger`';

        if (count($catgories)) {
            $this->_where = 'AND cl.`id_category` IN ('.implode(',', (array)$catgories).')';
        }
        $this->_use_found_rows = true;

        $this->fields_list = array();
        $this->fields_list['id_product'] = array(
            'title' => $this->l('ID'),
            'align' => 'center',
            'class' => 'fixed-width-xs',
            'type' => 'int'
        );
        $this->fields_list['image'] = array(
            'title' => $this->l('Image'),
            'align' => 'center',
            'image' => 'p',
            'orderby' => false,
            'filter' => false,
            'search' => false
        );
        $this->fields_list['name'] = array(
            'title' => $this->l('Name'),
            'filter_key' => 'b!name',
            'class' => 'fixed-width-sm',
        );
        $this->fields_list['reference'] = array(
            'title' => $this->l('Reference'),
            'align' => 'left',
        );

        $this->fields_list['price'] = array(
            'title' => $this->l('Base price'),
            'type' => 'price',
            'align' => 'text-right',
            'filter_key' => 'a!price'
        );
        $this->fields_list['price_final'] = array(
            'title' => $this->l('Final price'),
            'type' => 'price',
            'align' => 'text-right',
            'havingFilter' => true,
            'orderby' => false,
            'search' => false
        );
       
        if (Configuration::get('PS_STOCK_MANAGEMENT')) {
            $this->fields_list['sav_quantity'] = array(
                'title' => $this->l('Quantity'),
                'type' => 'int',
                'align' => 'text-right',
                'filter_key' => 'sav!quantity',
                'orderby' => true,
                'badge_danger' => true,
                'hint' => ('This is the quantity available in the current shop/group.'),
            );
        }

        $this->fields_list['active'] = array(
            'title' => $this->l('Status'),
            'active' => 'status',
            'filter_key' => $alias.'!active',
            'align' => 'text-center',
            'type' => 'bool',
            'class' => 'fixed-width-sm',
            'orderby' => false
        );
        
        // $this->fields_list['state'] = array(
        //     'title' => $this->l('Etsy Status'),
        //     'type' => 'text',
        //     'align' => 'text-right',
        //     'havingFilter' => true,
        //     'orderby' => true,
        //     'class' => 'fixed-width-xs',
        //     'search' => true

        // );
        $this->fields_list['listing_id'] = array(
            'title' => $this->l('Etsy Listing ID'),
            'type' => 'text',
            'align' => 'text-right',
            'havingFilter' => true,
            'orderby' => true,
            'class' => 'fixed-width-xs',
            'search' => true
        );

        // $this->fields_list['error_message'] = array(
        //     'title' => $this->l('View Details'),
        //     'align' =>'text-left',
        //     'search' => false,
        //     'class' => 'fixed-width-xs',
        //     'callback' => 'viewDetailsButton',
        // );
    }

    public function getList(
        $id_lang,
        $orderBy = null,
        $orderWay = null,
        $start = 0,
        $limit = null,
        $id_lang_shop = false
    ) {
        $orderByPriceFinal = (empty($orderBy) ? ($this->context->cookie->__get($this->table.'Orderby') ?
            $this->context->cookie->__get($this->table.'Orderby') :
            'id_'.$this->table) : $orderBy);
        $orderWayPriceFinal = (empty($orderWay) ? ($this->context->cookie->__get($this->table.'Orderway') ?
            $this->context->cookie->__get($this->table.'Orderby') :
            'ASC') : $orderWay);
        if ($orderByPriceFinal == 'price_final') {
            $orderBy = 'id_'.$this->table;
            $orderWay = 'ASC';
        }
        parent::getList($id_lang, $orderBy, $orderWay, $start, $limit, $id_lang_shop);
        $nothing = null;
        /* update product quantity with attributes ...*/
        $nb = count($this->_list);
        if ($this->_list) {
            $context = $this->context->cloneContext();
            $context->shop = clone($context->shop);
            /* update product final price */
            for ($i = 0; $i < $nb; $i++) {
                if (Context::getContext()->shop->getContext() != Shop::CONTEXT_SHOP) {
                    $context->shop = new Shop((int)$this->_list[$i]['id_shop_default']);
                }

                // convert price with the currency from context
                $this->_list[$i]['price'] = Tools::convertPrice(
                    $this->_list[$i]['price'],
                    $this->context->currency,
                    true,
                    $this->context
                );
                $this->_list[$i]['price_tmp'] = Product::getPriceStatic(
                    $this->_list[$i]['id_product'],
                    true,
                    null,
                    (int)Configuration::get('PS_PRICE_DISPLAY_PRECISION'),
                    null,
                    false,
                    true,
                    1,
                    true,
                    null,
                    null,
                    null,
                    $nothing,
                    true,
                    true,
                    $context
                );
            }
        }

        if ($orderByPriceFinal == 'price_final') {
            if (Tools::strtolower($orderWayPriceFinal) == 'desc') {
                uasort($this->_list, 'cmpPriceDesc');
            } else {
                uasort($this->_list, 'cmpPriceAsc');
            }
        }
        for ($i = 0; $this->_list && $i < $nb; $i++) {
            $this->_list[$i]['price_final'] = $this->_list[$i]['price_tmp'];
            unset($this->_list[$i]['price_tmp']);
        }
    }


    // public function initProcess()
    // {
    //     if (Tools::isSubmit('submitProductFormAndStay')
    //         || Tools::isSubmit('submitProductForm')) {
    //         $this->id_object = (int)Tools::getValue('id_product');
    //         $this->object = new Product($this->id_object);
    //         $this->tab_display = Tools::getValue('currentTab');
    //     }
    //     if (!$this->action) {
    //         parent::initProcess();
    //     } else {
    //         $this->id_object = (int)Tools::getValue($this->identifier);
    //     }
    // }

    /**
     * postProcess handle every checks before saving products information
     *
     * @return void
     */
    public function postProcess()
    {
        try {
            if (Tools::getIsset('submitBulkuploadproduct')) {
                if (Tools::getIsset('productBox')
                    &&  count(Tools::getValue('productBox'))) {
                    $result = $this->processBulkUpload(Tools::getValue('productBox'));

                    if (isset($result['error']) && $result['error']) {
                        $this->errors[] = implode(',', $result['error']);
                    }
                    if (isset($result['success']) && $result['success']) {
                        $this->confirmations[] = $result['success'];
                    }
                } else {
                    $this->errors[] = 'Please Select Product';
                }
            }
        } catch (PrestaShopException $e) {
            $this->errors[] = $e;
        }
        parent::postProcess();
    }

    // protected function isTabSubmitted($tab_name)
    // {
    //     if (!is_array($this->submitted_tabs)) {
    //         $this->submitted_tabs = Tools::getValue('submitted_tabs');
    //     }

    //     if (is_array($this->submitted_tabs) && in_array($tab_name, $this->submitted_tabs)) {
    //         return true;
    //     }

    //     return false;
    // }

    // public function renderList()
    // {
    //     $feed_url = Configuration::get('CEDFRUUGO_FEED_URL');
    //     $this->context->smarty->assign(array(
    //         'feed_url' => $feed_url
    //     ));
    //     $this->addRowAction('edit');
    //     $parent = $this->context->smarty->fetch(
    //         _PS_MODULE_DIR_ .'cedfruugo/views/templates/admin/product/product_list.tpl'
    //     );
    //     return $parent.parent::renderList();
    // }


    public function initPageHeaderToolbar()
    {
        if (empty($this->display)) {
                $this->page_header_toolbar_btn['upload_all'] = array(
                    'href' => $this->context->link->getAdminLink('AdminCedEtsyBulkUploadProduct'),
                    'desc' => 'Upload All',
                    'icon' => 'process-icon-upload'
                );
                $this->page_header_toolbar_btn['bulk_enable'] = array(
                    'href' => $this->context->link->getAdminLink('AdminCedEtsyProduct').'&method=bulk_enable',
                    'desc' => 'Bulk Enable',
                    'icon' => 'process-icon-refresh'
                );
                $this->page_header_toolbar_btn['bulk_disable'] = array(
                    'href' => $this->context->link->getAdminLink('AdminCedEtsyProduct').'&method=bulk_disable',
                    'desc' => 'Bulk Disable',
                    'icon' => 'process-icon-refresh'
                );
                $this->page_header_toolbar_btn['bulk_delete'] = array(
                    'href' => $this->context->link->getAdminLink('AdminCedEtsyProduct').'&method=bulk_delete',
                    'desc' => 'Bulk Delete',
                    'icon' => 'process-icon-delete'
                );
        }
        parent::initPageHeaderToolbar();
    }

    protected function processBulkUpload($product_ids = array())
    {
        if (is_array($product_ids) && count($product_ids)) {
            $result = $this->CedEtsyProduct->uploadProducts($product_ids);
            if (isset($result['success']) && $result['success']) {
                $this->confirmations[] = $result['message'];
            } else {
                $this->errors[] = $result['message'];
            }
        }
    }

    public function processBulkEnable()
    {
        $product_ids = array();
        if (Tools::getIsset('productBox') && Tools::getValue('productBox')) {
            $product_ids = Tools::getValue('productBox');
        }
        if (is_array($product_ids) && count($product_ids)) {
            $result = $this->CedEtsyProduct->enableProducts($product_ids);
            if (isset($result['success']) && $result['success']) {
                $this->confirmations[] = $result['message'];
            } else {
                $this->errors[] = $result['message'];
            }
        }
    }

    public function processBulkDisable()
    {
        $product_ids = array();
        if (Tools::getIsset('productBox') && Tools::getValue('productBox')) {
            $product_ids = Tools::getValue('productBox');
        }
        if (is_array($product_ids) && !empty($product_ids)) {
            $result = $this->CedEtsyProduct->disableProducts($product_ids);
            if (isset($result['success']) && $result['success']) {
                $this->confirmations[] = $result['message'];
            } else {
                $this->errors[] = $result['message'];
            }
        }
    }

    public function processBulkRemove()
    {
        $product_ids = array();
        if (Tools::getIsset('productBox') && Tools::getValue('productBox')) {
            $product_ids = Tools::getValue('productBox');
        }
        if (is_array($product_ids) && count($product_ids)) {
            $result = $this->CedEtsyProduct->deleteProducts($product_ids);
            if (isset($result['success']) && $result['success']) {
                $this->confirmations[] = $result['message'];
            } else {
                $this->errors[] = $result['message'];
            }
        }
    }
}