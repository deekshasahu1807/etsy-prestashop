<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedEtsy
 */

include_once _PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyHelper.php';

class CedEtsyCategory
{
	public function fetchEtsyCategory() 
    {
    	$response = array();
        $CedEtsyHelper = new CedEtsyHelper;
        $db = Db::getInstance();
        $categories = $db->ExecuteS("SELECT * FROM `". _DB_PREFIX_ ."cedetsy_category`");
        if(isset($categories) && !empty($categories)){
        	$response = $categories;
        } else {
        	try {
	            if ($CedEtsyHelper->getRequestAuthorization()) {
	                $result = $CedEtsyHelper->getRequestAuthorization()->getSellerTaxonomy();
	                
	                if (isset($result['results']) && !empty($result['results'])) {
	                    foreach ($result['results'] as $key => $category) {
	                        $this->prepareTaxonomy($category);
	                    }
	                } else {

	                }
	            } else {
	                $response = 'Unable to fetch category';
	            }
	        } catch (Etsy\EtsyRequestException $e) {
	            $response = 'Unable to fetch category';
	        }
        }
        return $response;
    }

    public function prepareTaxonomy($category)
	{
		Db::getInstance()->insert(
			'cedetsy_category',
			array(
				'name' => pSQL($category['name']), 
				'children_ids' => pSQL(Tools::jsonEncode($category['children_ids'])), 
				'path' => pSQL($category['path']), 
				'level' => pSQL($category['level']), 
				'parent_id' => pSQL($category['parent_id']), 
				'category_id' => pSQL($category['category_id']), 
				'children_id' => pSQL($category['id'])
			)
		 );
		if (isset($category['children']) && !empty($category['children'])) {
			foreach ($category['children'] as $key => $children) {
				 $this->prepareTaxonomy($children);
			}
		}
	}

	public function deleteEtsyCategory()
	{
		$res = Db::getInstance()->delete('cedetsy_category');
		if($res){
			return true;
		} else {
			return false;
		}
	}

	public function attributes()
	{
		return array(
			array(
				'id' => 'name',
				'name' => 'Name',
			),
			array(
				'id' => 'quantity',
				'name' => 'Quantity',
			),
			array(
				'id' => 'description',
				'name' => 'Description',
			),
			array(
				'id' => 'price',
				'name' => 'Price',
			),
			array(
				'id' => 'manufacturer',
				'name' => 'Manufacturer',
			),
			array(
				'id' => 'model',
				'name' => 'Model',
			),
		);
	}

	public function getMappingDataById($mappingId)
	{
		$mapping_data = array(
			'etsy_category' => array(),
			'store_category' => array(),
			'mapped_fields' => array(),
			'default_values' => array(),
			'extrs' => array(),
			);

		if(!empty($mappingId))
		{
			$mapped_category_data = Db::getInstance()->ExecuteS("SELECT * FROM `". _DB_PREFIX_ ."cedetsy_category_mapping` WHERE `id` = '". (int) $mappingId ."' ");

			if(isset($mapped_category_data) && !empty($mapped_category_data))
			{
				$result = $mapped_category_data[0];

				$mapping_data['etsy_category'] = Tools::jsonDecode($result['etsy_category'], true);
				$mapping_data['store_category'] = Tools::jsonDecode($result['store_category'], true);
				$mapping_data['mapped_fields'] = Tools::jsonDecode($result['mapped_fields'], true);
				$mapping_data['default_values'] = Tools::jsonDecode($result['default_values'], true);
				$mapping_data['extrs'] = $result['extrs'];
			}
		}

		return $mapping_data;
	}

	public function getEtsyCategoryByLevelParent($level = 0, $category_id = 0)
	{
		$category_data = Db::getInstance()->ExecuteS("SELECT * FROM `". _DB_PREFIX_ ."cedetsy_category` WHERE `parent_id` = '". (int) $category_id ."' ");

		if(isset($category_data) && !empty($category_data)){
			return $category_data;
		} else {
			return array();
		}
	}

	public function deleteAllCategoryMapping()
	{
		$db = Db::getInstance();
		$res = $db->delete('cedetsy_category_mapping');
		if($res)
		{
			$result = $db->delete('cedetsy_category_properties');
			if($result) 
			{
				$resp = $db->delete('cedetsy_option_mapping');
				if($resp)
				{
					return true;
				} 
			}
		}
		return false;
	}

	public function getAllPropertySets($etsyCategory, $mappedId)
	{
		$CedEtsyHelper = new CedEtsyHelper;
		$db = Db::getInstance();
		$length = count($etsyCategory);
		$taxonomy_id = $etsyCategory['select-level-'.(int)($length)];
		$category_id = 0;
		
		if(!empty($taxonomy_id))
		{
	        $category_id = $db->getValue("SELECT `category_id` FROM `"._DB_PREFIX_."cedetsy_category` WHERE `children_id`='".(int)$taxonomy_id."'");
      	}

      	$shipping_templates_collection = array();
      	try {
  			if ($CedEtsyHelper->getRequestAuthorization()) 
  			{
				$params = array('params' => array('category_id' => $category_id, 'taxonomy_id' => $taxonomy_id, 'recipient_id' => 'TestShopByDeveloper'));
				 $result = $CedEtsyHelper->getRequestAuthorization()->findPropertySet($params);
                 // echo'<pre>'; print_r($result); die;
				if (isset($result['results']) && !empty($result['results'])) 
				{
					foreach ($result['results'] as $key => $properties) {
						$db->delete(
							'cedetsy_category_properties',
							'property_set_id=' . pSQL($properties['property_set_id']) . '&category_id=' . pSQL($category_id) . '&taxonomy_id=' . pSQL($taxonomy_id) . '&mapping_id=' . pSQL($mappedId)
						);
						$this->prepareCategoryProperties($properties, $category_id, $taxonomy_id, $mappedId);	
					}
					$shipping_templates_collection = $result['results'];
				} else {
					$shipping_templates_collection = 'Unable to fetch category';
				}
			} else {
				$shipping_templates_collection = 'Unable to fetch category';
			}
      	} catch (Etsy\EtsyRequestException $e) {
			 $CedEtsyHelper->log(
	                'CedEtsyCategoryClass:: getAllPropertySets', 
	                'GET',
	                'EtsyRequestException',
	                Tools::jsonEncode($e->getMessage()),
	                true
	            );
			$shipping_templates_collection = $e->getMessage();
		}
		return $shipping_templates_collection;
	}

	public function prepareCategoryProperties($properties, $category_id, $taxonomy_id, $mappedId)
	{
		$db = Db::getInstance();
		$db->insert(
			'cedetsy_category_properties',
			array(
				'qualifying_properties' => pSQL(Tools::jsonEncode($properties['qualifying_properties'])),
				'options' => pSQL(Tools::jsonEncode($properties['options'])),
				'properties' => pSQL(Tools::jsonEncode($properties['properties'])),
				'qualifiers' => pSQL(Tools::jsonEncode($properties['qualifiers'])),
				'property_set_id' => pSQL($properties['property_set_id']),
				'category_id' => pSQL($category_id),
				'taxonomy_id' => pSQL($taxonomy_id),
				'mapping_id' => pSQL($mappedId)
			)
		);
	}

	public function getAllPropertyNodes($etsyCategory, $mappedId)
	{
		$CedEtsyHelper = new CedEtsyHelper;
		$db = Db::getInstance();
		$length = count($etsyCategory);
		$taxonomy_id = $etsyCategory['select-level-'.(int)($length)];
		$category_id = 0;
		
		if(!empty($taxonomy_id))
		{
	        $category_id = $db->getValue("SELECT `category_id` FROM `"._DB_PREFIX_."cedetsy_category` WHERE `children_id`='".(int)$taxonomy_id."'");
      	}

      	$shipping_templates_collection = array();
      	try {
  			if ($CedEtsyHelper->getRequestAuthorization()) 
  			{
				$params = array('params' => array('taxonomy_id' => $taxonomy_id));
				 $result = $CedEtsyHelper->getRequestAuthorization()->getTaxonomyNodeProperties($params);
                 //echo'<pre>'; print_r($result); die;
				if (isset($result['results']) && !empty($result['results'])) 
				{
					foreach ($result['results'] as $key => $properties) {
						$db->delete(
							'cedetsy_category_node_properties',
							'category_id=' . pSQL($category_id) . '&taxonomy_id=' . pSQL($taxonomy_id) . '&mapping_id=' . pSQL($mappedId)
						); 
						$this->prepareCategoryNodeProperties($properties, $category_id, $taxonomy_id, $mappedId);	
					}
					$shipping_templates_collection = $result['results'];
				} else {
					$shipping_templates_collection = 'Unable to fetch category';
				}
			} else {
				$shipping_templates_collection = 'Unable to fetch category';
			}
      	} catch (Etsy\EtsyRequestException $e) {
			 $CedEtsyHelper->log(
	                'CedEtsyCategoryClass:: getAllPropertySets', 
	                'GET',
	                'EtsyRequestException',
	                Tools::jsonEncode($e->getMessage()),
	                true
	            );
			$shipping_templates_collection = $e->getMessage();
		}
		return $shipping_templates_collection;
	}

	public function prepareCategoryNodeProperties($properties, $category_id, $taxonomy_id, $mappedId)
	{
		$db = Db::getInstance();
		$db->insert(
			'cedetsy_category_node_properties',
			array(
				'property_id' => pSQL($properties['property_id']),
				'name' => pSQL($properties['name']),
				'display_name' => pSQL($properties['display_name']),
				'is_required' => (int) $properties['is_required'],
				'supports_attributes' => (int) $properties['supports_attributes'],
				'supports_variations' => (int) $properties['supports_variations'],
				'is_multivalued' => (int) $properties['is_multivalued'],
				'scales' => pSQL(Tools::jsonEncode($properties['scales'])),
				'possible_values' => pSQL(Tools::jsonEncode($properties['possible_values'])),
				'selected_values' => pSQL(Tools::jsonEncode($properties['selected_values'])),
				'category_id' => pSQL($category_id),
				'taxonomy_id' => pSQL($taxonomy_id),
				'mapping_id' => pSQL($mappedId)
			)
		);
	}

	public function getCategoryNodesProperty($mapping_id) 
	{
		$option_data = array();
		$db = Db::getInstance();
		$category_property_data = $db->ExecuteS("SELECT * FROM `" . _DB_PREFIX_ . "cedetsy_category_node_properties` WHERE `mapping_id` = '" . (int)$mapping_id . "'");
		if(is_array($category_property_data['0']) && !empty($category_property_data['0']))
		{
			return $category_property_data['0'];
		} else {
			return array();
		}
	}

	public function storeOptions()
    {
        $db = Db::getInstance();
        $options = array();
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
        // AS `option_id`
        $sql = "SELECT agl.`id_attribute_group`, agl.`name`, agl.`id_lang`, ag.`group_type`, ag.`position` FROM `"._DB_PREFIX_."attribute_group_lang` AS agl LEFT JOIN `"._DB_PREFIX_."attribute_group` AS ag ON (agl.id_attribute_group = ag.id_attribute_group) WHERE agl.`id_lang` = '". (int)$default_lang ."' ";
        $options = $db->executeS($sql);
        $option_value_data = array();
        $store_options = Attribute::getAttributes($default_lang,false);
        if(!empty($options))
        {
           foreach($options as $option)
            {
                foreach($store_options as $key => $value)
                { 
                    if($option['id_attribute_group'] == $value['id_attribute_group'])
                    {
                        $option_value_data[$option['id_attribute_group']][] = array(
                        'id_attribute' => $value['id_attribute'],
                        'name' => $value['name']
                        );
                    }
                }
            }
        }
        return array('options' => $options, 'option_values' => $option_value_data);
        //return $options; 
    }

    public function getEtsyCategoryName($etsyCatMapping)
    {
    	$db = Db::getInstance();
        $etsyCatMappedName = '';
        if(isset($etsyCatMapping) && !empty($etsyCatMapping))
        {
            $no_of_level = count($etsyCatMapping);
            for($i = '1'; $i <= $no_of_level; $i++)
            {
                $children_id = $etsyCatMapping['select-level-'.$i];
                $etsyCatName = $db->getValue("SELECT `name` FROM `". _DB_PREFIX_."cedetsy_category` WHERE `children_id` = '". (int) $children_id ."' ");
                
                if(isset($etsyCatMappedName) && empty($etsyCatMappedName))
                {
                    $etsyCatMappedName .= $etsyCatName;
                } else {
                    $etsyCatMappedName .= ' > ' . $etsyCatName;
                }
            }
        }
        return $etsyCatMappedName;
    }

    public function getStoreCategoryName($store_category_id, $defaultLanguage)
    {
    	$db = Db::getInstance();
        $storeCatMappedName = '';
        if(isset($store_category_id) && !empty($store_category_id))
        {
            foreach($store_category_id as $key => $category_id)
            {
                $storeCategoryName = $db->getValue("SELECT `name` FROM `". _DB_PREFIX_."category_lang` WHERE `id_lang` = '". (int) $defaultLanguage."' AND `id_category` = '". (int) $category_id ."' ");

                if(isset($storeCatMappedName) && empty($storeCatMappedName))
                {
                    $storeCatMappedName .= $storeCategoryName;
                } else {
                    $storeCatMappedName .= ' , ' . $storeCategoryName;
                }
            }
        }
       return $storeCatMappedName;
    }

    public function getPropertiesMapping($mapping_id) 
    {
    	$db = Db::getInstance();
		$options_mapping_data = $db->ExecuteS("SELECT `mapped_attribute` FROM `" . _DB_PREFIX_ . "cedetsy_category_mapping` WHERE `id` = '".$mapping_id."'");
		
		if(isset($options_mapping_data['0']['mapped_attribute']) && !empty($options_mapping_data['0']['mapped_attribute']))
		{
			$mapped_attribute = Tools::jsonDecode($options_mapping_data['0']['mapped_attribute'], true);
			return $mapped_attribute;
		} else {
			return array();
		}
	}

	public function deleteMapping($id)
    {
        if (!empty($id)) {
            $res = $this->db->delete(
                'cedetsy_category_mapping',
                'id='.(int)$id
            );
            if($res)
            {
                $result = $this->db->delete(
                    'cedetsy_category_properties',
                    'mapping_id='.(int)$id
                    );
                if($result) 
                {
                    $resp = $this->db->delete(
                        'cedetsy_option_mapping',
                        'mapping_id='.(int)$id
                        );
                    if($resp)
                    {
                        return true;
                    } 
                }
            }
        }
        return false;
    }

    public function getAttributesByCategory($category_id, $taxonomy_id)
    {
        $db = Db::getInstance();
        
        if ($category_id) {
            $sql = "SELECT * FROM `". _DB_PREFIX_ ."cedetsy_category_node_properties` WHERE `category_id` = '". (int)$category_id ."' AND `taxonomy_id` = '". (int)$taxonomy_id ."' ";
            $result = $db->executeS($sql);
            
            if (is_array($result) && isset($result['0']) && !empty($result['0'])) {
                return $result;
            } else {
            	$mappedId = $db->getValue("SELECT `mapping_id` FROM `". _DB_PREFIX_ ."cedetsy_category_node_properties` WHERE `category_id` = '". (int)$category_id ."' AND `taxonomy_id` = '". (int)$taxonomy_id ."' ");
            	if(!empty($mappedId))
            	{
            		$etsy_category = $db->getValue("SELECT `etsy_category` FROM `". _DB_PREFIX_ ."cedetsy_category_mapping` WHERE `id` = '". (int)$mappedId ."' ");
            		$etsy_category = Tools::jsonEncode($etsy_category, true);
            		$result = $this->getAllPropertyNodes($etsy_category, $mappedId);
                
                    return $result;
            	}
            	
                
            }
        } else {
            return array();
        }
    }

    public static function getManufacturers($data = array())
    {
        $db = Db::getInstance();
        $sql = "SELECT * FROM `". _DB_PREFIX_ ."manufacturer`";
        if (!empty($data['filter_name'])) {
            $sql .= " WHERE name LIKE '" . pSQL($data['filter_name']) . "%'";
        }
        $result = $db->executeS($sql);
        if (is_array($result) && count($result)) {
            return $result;
        }
    }

    public function getStoreOptions($catId, $attribute_group_id, $brandName)
    {
        $db = Db::getInstance();
        $option_value_data = array();
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
        $sql = "SELECT al.`id_attribute`, al.`name`, a.`position` FROM `"._DB_PREFIX_."attribute` AS a LEFT JOIN `"._DB_PREFIX_."attribute_lang` AS al ON (al.id_attribute = a.id_attribute) WHERE a.`id_attribute_group` = '". (int)$attribute_group_id ."' AND al.`id_lang` = '". (int)$default_lang ."' AND al.`name` LIKE '%". pSQL($brandName) ."%' ORDER BY a.`position` ASC";
        $option_value_query = $db->executeS($sql);

        foreach ($option_value_query as $option_value) {
            $option_value_data[] = array(
                'option_value_id' => $option_value['id_attribute'],
                'name'            => $option_value['name'],
                'sort_order'      => $option_value['position']
            );
        }
        return $option_value_data;
    }

    public function getBrands($catId, $attribute_id, $brandName)
    {
        $db = Db::getInstance();
        $brandArray = array();
        $results = $db->ExecuteS("SELECT * FROM `". _DB_PREFIX_ ."cedetsy_category_node_properties` WHERE `category_id` = '".$catId."' AND `property_id` = '".$attribute_id."'");
        foreach ($results as $res) 
        {
        	$possible_values = Tools::jsonDecode($res['possible_values'],true);
        	$possible_value_name_array = array();
        	foreach ($possible_values as $key => $possible_value) 
        	{
        		$possible_value_name_array[$key] = $possible_value['name']; 
        	} 
        	$brandArray = array_merge_recursive($brandArray, $possible_value_name_array);
        }

        $input = preg_quote($brandName, '~');
        $result = preg_grep('~' . $input . '~', $brandArray);

        return $result;
    }

    public function getEtsyAttributeName($taxonomy_id, $property_id, $mapping_id, $option_id)
    {
    	$db = Db::getInstance();
        if($taxonomy_id != '0')
        {
        	$possible_value_data = $db->ExecuteS("SELECT `possible_values` FROM `". _DB_PREFIX_ ."cedetsy_category_nodes_properties` WHERE `taxonomy_id` = '". (int)$taxonomy_id ."' AND `property_id` = '". (int)$property_id ."' AND `mapping_id` = '". (int)$mapping_id ."' ");
	        if(isset($possible_value_data) && !empty($possible_value_data))
	        {
	            $possible_value_data = Tools::jsonDecode($possible_value_data['0']['possible_values'], true);
	            foreach($possible_value_data as $key => $value)
	            {
	                if($value['value_id'] == $option_id)
	                {
	                    return $value['name'];
	                }
	            }
	        } else {
	            return '';
	        }
        } else {
        	$etsy_category = $db->getValue("SELECT `etsy_category` FROM `". _DB_PREFIX_ ."cedetsy_category_mapping` WHERE `id` = '". (int)$mapping_id ."' ");
        	$etsyCategory = Tools::jsonDecode($etsy_category, true);

        	$length = count($etsyCategory);
		    $taxonomy_id = $etsyCategory['select-level-'.(int)($length)];

        	$possible_value_data = $db->ExecuteS("SELECT `possible_values` FROM `". _DB_PREFIX_ ."cedetsy_category_node_properties` WHERE `taxonomy_id` = '". (int)$taxonomy_id ."' AND `property_id` = '". (int)$property_id ."' AND `mapping_id` = '". (int)$mapping_id ."' ");
	        if(isset($possible_value_data) && !empty($possible_value_data))
	        {
	            $possible_value_data = Tools::jsonDecode($possible_value_data['0']['possible_values'], true);
	            foreach($possible_value_data as $key => $value)
	            {
	                if($value['value_id'] == $option_id)
	                {
	                    return $value['name'];
	                }
	            }
	        } else {
	            return '';
	        }
        }
    }

    public function getEtsyAttributeID($property_id, $mapping_id, $option_name)
    {
    	$db = Db::getInstance();
    	$etsy_category = $db->getValue("SELECT `etsy_category` FROM `". _DB_PREFIX_ ."cedetsy_category_mapping` WHERE `id` = '". (int)$mapping_id ."' ");
    	$etsyCategory = Tools::jsonDecode($etsy_category, true);

    	$length = count($etsyCategory);
	    $taxonomy_id = $etsyCategory['select-level-'.(int)($length)];

    	$possible_value_data = $db->ExecuteS("SELECT `possible_values` FROM `". _DB_PREFIX_ ."cedetsy_category_node_properties` WHERE `taxonomy_id` = '". (int)$taxonomy_id ."' AND `property_id` = '". (int)$property_id ."' AND `mapping_id` = '". (int)$mapping_id ."' ");
        if(isset($possible_value_data) && !empty($possible_value_data))
        {
            $possible_value_data = Tools::jsonDecode($possible_value_data['0']['possible_values'], true);
            foreach($possible_value_data as $key => $value)
            {
                if($value['name'] == $option_name)
                {
                    return $value['value_id'];
                }
            }
        } else {
            return '';
        }
    }
}