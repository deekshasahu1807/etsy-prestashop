<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedEtsy
 */

$db = Db::getInstance();
$sql_queries = array();

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "cedetsy_category` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `name` longtext NOT NULL,
      `children_ids` longtext NOT NULL,
      `path` longtext NOT NULL,
      `level` int(11) NOT NULL,
      `parent_id` int(11) NOT NULL,
      `category_id` bigint(20) NOT NULL,
      `children_id` int(11) NOT NULL,
      PRIMARY KEY (`id`)
    )";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "cedetsy_category_mapping` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `etsy_category` longtext NOT NULL,
      `store_category` longtext NOT NULL,
      `mapped_fields` longtext NOT NULL,
      `default_values` longtext NOT NULL,
      `extrs` longtext NOT NULL,
      PRIMARY KEY (`id`)
    )";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "cedetsy_category_properties` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `qualifying_properties` longtext NOT NULL,
      `options` longtext NOT NULL,
      `properties` longtext NOT NULL,
      `qualifiers` longtext NOT NULL,
      `property_set_id` longtext NOT NULL,
      `category_id` bigint(20) NOT NULL,
      `mapping_id` int(11) NOT NULL,
      `taxonomy_id` bigint(20) NOT NULL,
      `mapping_data` longtext NOT NULL,
      PRIMARY KEY (`id`)
    )";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "cedetsy_category_node_properties` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `property_id` text NOT NULL,
      `name` text NOT NULL,
      `display_name` text NOT NULL,
      `is_required` boolean NOT NULL,
      `supports_attributes` boolean NOT NULL,
      `supports_variations` boolean NOT NULL,
      `is_multivalued` boolean NOT NULL,
      `scales` longtext NOT NULL,
      `possible_values` longtext NOT NULL,
      `selected_values` longtext NOT NULL,
      `category_id` bigint(20) NOT NULL,
      `mapping_id` int(11) NOT NULL,
      `taxonomy_id` bigint(20) NOT NULL,
      PRIMARY KEY (`id`)
    )";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "cedetsy_country` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `country_id` int(11) NOT NULL,
      `iso_country_code` text NOT NULL,
      `world_bank_country_code` text NOT NULL,
      `name` text NOT NULL,
      `slug` text NOT NULL,
      `lat` double NOT NULL,
      `lon` double NOT NULL,
      PRIMARY KEY (`id`)
    )";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "cedetsy_option_mapping` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `mapping_id` int(11) NOT NULL,
      `property_id` text NOT NULL,
      `etsy_attribute_id` text NOT NULL,
      `store_attribute_id` int(11) NOT NULL,
      `store_attribute_group` text NOT NULL,
      `scale_id` int(15) NOT NULL,
      `mapped_options` text NOT NULL,
      PRIMARY KEY (`id`)
    )";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "cedetsy_order` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `order_id` bigint(20) NOT NULL,
      `prestashop_order_id` bigint(20) NOT NULL,
      `status` text NOT NULL,
      `order_data` longtext NOT NULL,
      PRIMARY KEY (`id`)
    )";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "cedetsy_order_error` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `sku` text NOT NULL,
      `order_data` longtext NOT NULL,
      `error_message` text NOT NULL,
      `order_id` bigint(20) NOT NULL,
      PRIMARY KEY (`id`)
    )";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "cedetsy_product` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `listing_id` bigint(20) NOT NULL,
      `shop_section_id` bigint(20) NOT NULL,
      `num_favorers` int(11) NOT NULL,
      `url` longtext NOT NULL,
      `views` int(11) NOT NULL,
      `state` text NOT NULL,
      `image_ids` longtext NOT NULL,
      `featured_rank` int(11) NOT NULL,
      `product_id` int(11) NOT NULL,
      PRIMARY KEY (`id`)
    )";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "cedetsy_product_image` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `listing_id` bigint(20) NOT NULL,
      `image_listing_id` bigint(20) NOT NULL,
      `rank` int(11) NOT NULL,
      `overwrite` tinyint(1) NOT NULL,
      `is_watermarked` tinyint(1) NOT NULL,
      `extra` text NOT NULL,
      `image_id` int(11) NOT NULL,
      `product_id` int(11) NOT NULL,
      PRIMARY KEY (`id`)
    )";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "cedetsy_shipping_template` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `title` text NOT NULL,
      `origin_country_id` int(11) NOT NULL,
      `destination_country_id` int(11) NOT NULL,
      `primary_cost` int(11) NOT NULL,
      `secondary_cost` int(11) NOT NULL,
      `destination_region_id` int(11) NOT NULL,
      `min_processing_days` int(11) NOT NULL,
      `max_processing_days` int(11) NOT NULL,
      `processing_days_display_label` text NOT NULL,
      `user_id` bigint(20) NOT NULL,
      `shipping_template_id` bigint(20) NOT NULL,
      PRIMARY KEY (`id`)
    )";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "cedetsy_shop_sections` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `shop_section_id` bigint(20) NOT NULL,
      `title` text NOT NULL,
      `user_id` bigint(20) NOT NULL,
      `rank` int(11) NOT NULL,
      `active_listing_count` int(11) NOT NULL,
      `extra` text NOT NULL,
      PRIMARY KEY (`id`)
    )";

$sql_queries[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "cedetsy_logs` (
      `id` int(15) NOT NULL AUTO_INCREMENT,
      `method` text NOT NULL,   
      `type` varchar(150) NOT NULL,
      `message` text NOT NULL,   
      `data` longtext NOT NULL,   
      `created_at` datetime default current_timestamp,   
     PRIMARY KEY (`id`)
    )";

foreach ($sql_queries as $sql) {
    if (!$db->execute($sql)) {
        return false;
    }
}
