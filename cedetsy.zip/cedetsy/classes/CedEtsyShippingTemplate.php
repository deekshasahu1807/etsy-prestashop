<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedEtsy
 */
include_once _PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyHelper.php';

class CedEtsyShippingTemplate
{

    public function getAllShippingTemplates()
    {
        $CedEtsyHelper = new CedEtsyHelper;
        $shipping_templates_collection = array();
        $db = Db::getInstance();
        $shipping_templates = $db->ExecuteS("SELECT * FROM `". _DB_PREFIX_ ."cedetsy_shipping_template`");
        
        if (isset($shipping_templates) && !empty($shipping_templates)) {
            $shipping_templates_collection = $shipping_templates;
        } else {
            try {
                if ($CedEtsyHelper->getRequestAuthorization()) {
                    $params = array('params' => array('user_id' => '__SELF__'));
                    $result = $CedEtsyHelper->getRequestAuthorization()->findAllUserShippingProfiles($params);
                    
                    if (isset($result['results']) && count($result['results'])) {
                        foreach ($result['results'] as $key => $category) {
                            if(isset($category['Entries'])){
                                $Entries = end($category['Entries']);
                                $category = array_merge($category,$Entries);
                            }

                            $this->prepareShippingTemplates($category); 
                        }
                        $shipping_templates_collection = $result['results'];
                    } else {
                        $shipping_templates_collection = 'Unable to fetch category';
                    }
                } else {
                    $shipping_templates_collection = 'Unable to fetch category';
                }
            } catch (Etsy\EtsyRequestException $e) {
                $shipping_templates_collection = $e->getMessage();
                $CedEtsyHelper->log(
                    'CedEtsyShippingTemplate::getAllShippingTemplates',
                     'GET', 
                     'Error while getting shipping templates', 
                     $shipping_templates_collection, 
                     true
                );
            }
        }
        return $shipping_templates_collection;
    }

    public function prepareShippingTemplates($data)
    {
        $db = Db::getInstance();

        if(!isset($data['secondary_cost']))
            $data['secondary_cost']='';
        if(!isset($data['primary_cost']))
            $data['primary_cost']='';
        if(!isset($data['destination_country_id']))
            $data['destination_country_id']='';

        $db->insert(
            'cedetsy_shipping_template',
            array(
                'shipping_template_id' => pSQL($data['shipping_template_id']), 
                'title' => pSQL($data['title']), 
                'user_id' => pSQL($data['user_id']), 
                'min_processing_days' => pSQL($data['min_processing_days']), 
                'max_processing_days' => pSQL($data['max_processing_days']), 
                'processing_days_display_label' => pSQL($data['processing_days_display_label']),
                'origin_country_id' => pSQL($data['origin_country_id']),
                'destination_country_id' => pSQL($data['destination_country_id']),
                'secondary_cost' => pSQL($data['secondary_cost']),
                'primary_cost' => pSQL($data['primary_cost'])
            )
        );
    }

	public function getShippingDataById($idShipping)
    {
        $db = Db::getInstance();
        $shipping_template_data = $db->ExecuteS("SELECT * FROM `". _DB_PREFIX_ ."cedetsy_shipping_template` WHERE `shipping_template_id` = '". $idShipping ."' ");
        if(isset($shipping_template_data) && is_array($shipping_template_data) && !empty($shipping_template_data))
        {
            return $shipping_template_data[0];
        } else {
            return array();
        }
    }

    public function deleteShippingTemplate()
    {
        $CedEtsyHelper = new CedEtsyHelper;
    	$response = array();
        $shippingIds = Db::getInstance()->ExecuteS("SELECT `shipping_template_id` FROM `". _DB_PREFIX_ ."cedetsy_shipping_template` ");
        // echo '<pre>'; print_r($shippingIds); die;
        if(isset($shippingIds) && !empty($shippingIds))
        {
            try
            {
                $success = '';
                $failure = '';
                foreach($shippingIds as $key => $shippingId)
                {
                    if ($CedEtsyHelper->getRequestAuthorization()) 
                    {
                        $params = array('params' =>array('shipping_template_id' => $shippingId['shipping_template_id']));
                        $result = $CedEtsyHelper->getRequestAuthorization()->deleteShippingTemplate($params);
                        if(!$result['count'])
                        {
                            $res = $this->deleteShipping($shippingId['shipping_template_id']);
                        }
                        if($res){
                            $success .=  $shippingId['shipping_template_id'] . ',';
                        } else {
                            $failure .=  $shippingId['shipping_template_id'] . ',';
                        }
                    }
                }
                if(!empty($success)){
                	$response['success'] = true;
                    $response['message'] = 'Shipping Template ' . rtrim($success, ',') . ' deleted successfully';
                } else {
                	$response['success'] = false;
                    $response['message'] = 'Error while deleting Shipping Template '. rtrim($failure, ',') ;
                }
            } catch (\Exception $e) {
                $CedEtsyHelper->log(
                    'CedEtsyShippingTemplate:: deleteShippingTemplate', 
                    'POST',
                    'Exception',
                    Tools::jsonEncode($e->getMessage()),
                    true
                );
                $response['success'] = false;
                $response['message'] = $e->getMessage();
            } catch (Etsy\EtsyRequestException $e) {
              $CedEtsyHelper->log(
                'CedEtsyShippingTemplate:: deleteShippingTemplate', 
                'POST',
                'EtsyRequestException',
                Tools::jsonEncode($e->getMessage()),
                true
                );
              $response['success'] = false;
              $response['message'] = $e->getMessage();
            } catch (Etsy\OAuthException $e) {
              $CedEtsyHelper->log(
                'CedEtsyShippingTemplate:: deleteShippingTemplate', 
                'POST',
                'OAuthException',
                Tools::jsonEncode($e->getMessage()),
                true
                );
              $response['success'] = false;
              $response['message'] = $e->getMessage();
            }
        } else {
        	$response['success'] = false;
            $response['message'] = 'Can\'t fetch Shipping Templates';
        }
        return $response;
    }

    public function deleteShipping($id)
    {
        $db = Db::getInstance();
        if (!empty($id)) {
            $res = $db->delete(
                'cedetsy_shipping_template',
                'shipping_template_id='.(int)$id
            );
            if ($res) {
                return true;
            }
        }
        return false;
    }
	
}