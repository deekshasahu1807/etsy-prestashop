<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedEtsy
 */

if (!defined('_PS_VERSION_')) {
    exit;
}
if (!function_exists('curl_version')) {
    exit;
}
include_once(_PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyHelper.php');
include_once(_PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyProduct.php');
include_once(_PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyOrder.php');
include_once(_PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyShippingTemplate.php');

class CedEtsy extends Module
{
    public $fields_form = array();

    public function __construct()
    {
        $this->name = 'cedetsy';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'CedCommerce';
        $this->bootstrap = true;
        $this->need_instance = 1;
        $this->module_key = '3912dc2255d08bb8db35a1236856b6e4';
        $this->db = Db::getInstance();

        $this->controllers = array('validation');
        $this->secure_key = Tools::encrypt($this->name);
        $this->is_eu_compatible = 1;
        $this->currencies = false;
        $this->displayName = $this->l('Etsy Integration');
        $this->description = $this->l('Allow merchants to integrate their Prestashop shop with Etsy marketplace.');
        $this->confirmUninstall = $this->l('Do you want to uninstall Etsy Integration?');

        $this->ps_versions_compliancy = array('min' => '1.6.0.0', 'max' => _PS_VERSION_);
        parent::__construct();

        if(Tools::getIsset('oauth_verifier') && Tools::getValue('oauth_verifier'))
        {
            $this->getAuthorizedCredentials(Tools::getValue('oauth_verifier'));
        }
    }

    /* install needed modules, tabs and hooks for etsy integration
    *
    */
    public function install()
    {
        require_once _PS_MODULE_DIR_ . 'cedetsy/sql/installTables.php';
        if (!parent::install()
            || !$this->installTab('AdminCedEtsy', 'Etsy Integration', 0)
            || !$this->installTab(
                'AdminCedEtsyCategory',
                'Etsy Category',
                (int)Tab::getIdFromClassName('AdminCedEtsy')
            )
            || !$this->installTab(
                'AdminCedEtsyCatMapping',
                'Etsy Category Mapping',
                (int)Tab::getIdFromClassName('AdminCedEtsy')
            )
            || !$this->installTab(
                'AdminCedEtsyProduct',
                'Etsy Products',
                (int)Tab::getIdFromClassName('AdminCedEtsy')
            )
            || !$this->installTab(
                'AdminCedEtsyBulkUploadProduct',
                'Etsy Bulk Process',
                (int)Tab::getIdFromClassName('AdminCedEtsy')
            )
            || !$this->installTab(
                'AdminCedEtsyOrder',
                'Etsy Orders',
                (int)Tab::getIdFromClassName('AdminCedEtsy')
            )
            || !$this->installTab(
                'AdminCedEtsyFailedOrder',
                'Etsy Failed Orders',
                (int)Tab::getIdFromClassName('AdminCedEtsy')
            )
            || !$this->installTab(
                'AdminCedEtsyLogs',
                'Etsy Logs',
                (int)Tab::getIdFromClassName('AdminCedEtsy')
            )
            || !$this->installTab(
                'AdminCedEtsyShippingTemplate',
                'Etsy Shipping Template',
                (int)Tab::getIdFromClassName('AdminCedEtsy')
            )
            || !$this->installTab(
                'AdminCedEtsyConfig',
                'Etsy Configuration',
                (int)Tab::getIdFromClassName('AdminCedEtsy')
            )
            || !$this->registerHook('actionProductUpdate')
            || !$this->registerHook('actionProductDelete')
            || !$this->registerHook('actionUploadProduct')
            || !$this->registerHook('displayBackOfficeHeader')
        ) {
            return false;
        }
        if (!Configuration::get('PS_ORDER_RETURN')) {
            Configuration::updateValue('PS_ORDER_RETURN', 1);
        }
        return true;
    }

    // uninstall etsy tabs and additional modules along with etsy integration module
    public function uninstall()
    {
        if (!parent::uninstall()
            || !$this->uninstallTab('AdminCedEtsyCategory')
            || !$this->uninstallTab('AdminCedEtsyCatMapping')
            || !$this->uninstallTab('AdminCedEtsyProduct')
            || !$this->uninstallTab('AdminCedEtsyBulkUploadProduct')
            || !$this->uninstallTab('AdminCedEtsyOrder')
            || !$this->uninstallTab('AdminCedEtsyFailedOrder')
            || !$this->uninstallTab('AdminCedEtsyLogs')
            || !$this->uninstallTab('AdminCedEtsyShippingTemplate')
            || !$this->uninstallTab('AdminCedEtsyConfig')
            || !$this->uninstallTab('AdminCedEtsy')
            || !$this->unregisterHook('displayBackOfficeHeader')
            || !$this->unregisterHook('actionProductUpdate')
            || !$this->unregisterHook('actionProductDelete')
            || !$this->unregisterHook('actionUploadProduct')
        ) {
            return false;
        }
        return true;
    }

    /* install tabs on basis of class name given
    * use tab name in frontend
    * install under the parent tab given
    */
    public function installTab($class_name, $tab_name, $parent)
    {
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = $class_name;
        $tab->name = array();
        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = $tab_name;
        }
        if ($parent == 0 && _PS_VERSION_ >= '1.7') {
            $tab->id_parent = (int)Tab::getIdFromClassName('SELL');
            $tab->icon = 'CE';
        } else {
            $tab->id_parent = $parent;
        }
        $tab->module = $this->name;
        return $tab->add();
    }

    /**
     * uninstall tabs created by module
     */
    public function uninstallTab($class_name)
    {
        $id_tab = (int)Tab::getIdFromClassName($class_name);
        if ($id_tab) {
            $tab = new Tab($id_tab);
            return $tab->delete();
        } else {
            return false;
        }
    }

    // save and display Configuration settings for jet integration
    public function getContent()
    {
        $output = null;
        if (Tools::isSubmit('submitgeneralsetting')) {
            $ced_api_url = trim(Tools::getValue('CEDETSY_API_URL'));
            $cedetsy_keystring = trim(Tools::getValue('CEDETSY_KEYSTRING'));
            $cedetsy_shared_secret = trim(Tools::getValue('CEDETSY_SHARED_SECRET'));
            $cedetsy_access_token_secret = trim(Tools::getValue('CEDETSY_API_ACCESS_TOKEN_SECRET'));
            $cedetsy_token = trim(Tools::getValue('CEDETSY_API_ACCESS_TOKEN'));
            $cedetsy_shop_name = trim(Tools::getValue('CEDETSY_SHOP_NAME'));
            $cedetsy_username = trim(Tools::getValue('CEDETSY_USERNAME'));
            $cedetsy_country = trim(Tools::getValue('CEDETSY_COUNTRY'));
            $cedetsy_store = trim(Tools::getValue('CEDETSY_STORE'));

            Configuration::updateValue('CEDETSY_API_URL', $ced_api_url);
            Configuration::updateValue('CEDETSY_KEYSTRING', $cedetsy_keystring);
            Configuration::updateValue('CEDETSY_SHARED_SECRET', $cedetsy_shared_secret);
            Configuration::updateValue('CEDETSY_API_ACCESS_TOKEN_SECRET', $cedetsy_access_token_secret);
            Configuration::updateValue('CEDETSY_API_ACCESS_TOKEN', $cedetsy_token);
            Configuration::updateValue('CEDETSY_SHOP_NAME', $cedetsy_shop_name);
            Configuration::updateValue('CEDETSY_USERNAME', $cedetsy_username);
            Configuration::updateValue('CEDETSY_COUNTRY', $cedetsy_country);
            Configuration::updateValue('CEDETSY_STORE', $cedetsy_store);

            if (empty($ced_api_url)
                || empty($cedetsy_keystring)
                || empty($cedetsy_shared_secret)
            ) {
                $output .= $this->displayError($this->l('Invalid Api credentials.'));
            } elseif (Tools::strlen($cedetsy_keystring) < 5 || Tools::strlen($cedetsy_shared_secret) < 5) {
                $output .= $this->displayError(
                    $this->l('The length of Keystring and Shared Secret must not less than 5')
                );
            } else {
                Configuration::updateValue('CEDETSY_API_URL', $ced_api_url);
                Configuration::updateValue('CEDETSY_KEYSTRING', $cedetsy_keystring);
                Configuration::updateValue('CEDETSY_SHARED_SECRET', $cedetsy_shared_secret);
                Configuration::updateValue('CEDETSY_API_ACCESS_TOKEN_SECRET', $cedetsy_access_token_secret);
                Configuration::updateValue('CEDETSY_API_ACCESS_TOKEN', $cedetsy_token);
                Configuration::updateValue('CEDETSY_SHOP_NAME', $cedetsy_shop_name);
                Configuration::updateValue('CEDETSY_USERNAME', $cedetsy_username);
                Configuration::updateValue('CEDETSY_COUNTRY', $cedetsy_country);
                Configuration::updateValue('CEDETSY_STORE', $cedetsy_store);
                $output .= $this->displayConfirmation(' General Settings saved successfully.');
            }
        }
        if (Tools::isSubmit('etsysettings')) {
            $form_values = $this->getConfigFormValues();
            foreach (array_keys($form_values) as $key) {
                if (Tools::getIsset($key)) {
                    $value = Tools::getValue($key);
                    // if ($key == 'CEDETSY_PRICING_RULE') {
                    //     $value = json_encode($value);
                    // }
                    $key = trim($key);
                    Configuration::updateValue($key, $value);
                }
            }
            // if (empty(Tools::getValue('CEDETSY_PRICING_RULE'))) {
            //     Configuration::updateValue('CEDETSY_PRICING_RULE', '');
            // }
            $price_type = Tools::getValue('CEDETSY_PRICE_VARIATION_TYPE');
            $customer_id = Tools::getValue('CEDETSY_CUSTOMER_ID');
            $order_email = Tools::getValue('CEDETSY_ORDER_EMAIL');
            if (isset($price_type)
                && ($price_type == 'increase_fixed' || $price_type == 'decrease_fixed')) {
                $fixed_price = Tools::getValue('CEDETSY_PRICE_VARIATION_FIXED');
                if (empty($fixed_price) || !Validate::isFloat($fixed_price)) {
                    $output .= $this->displayError($this->l('The fixed price should be a valid number'));
                }
            } elseif (isset($price_type)
                && ($price_type == 'increase_per' || $price_type == 'decrease_per')) {
                $fixed_per = Tools::getValue('CEDETSY_PRICE_VARIATION_PER');
                if (empty($fixed_per) || !Validate::isFloat($fixed_per)) {
                    $output .= $this->displayError($this->l('The fixed percentage should be a valid number'));
                }
            } elseif (!Validate::isEmail($order_email)) {
               $output .= $this->displayError($this->l('Order email is invalid'));
            } elseif (!empty($customer_id) && !Validate::isInt($customer_id)) {
                $output .= $this->displayError($this->l('Customer id is invalid'));
            } else {
                $ced_api_url = Configuration::get('CEDETSY_API_URL');
                $cedetsy_keystring = Configuration::get('CEDETSY_KEYSTRING');
                $cedetsy_shared_secret = Configuration::get('CEDETSY_SHARED_SECRET');

                if (empty($ced_api_url)
                    || empty($cedetsy_keystring)
                    || empty($cedetsy_shared_secret)
                ) {
                    $output .= $this->displayError($this->l('Invalid Api credentials. '));
                } elseif (Tools::strlen($cedetsy_keystring) < 5
                    || Tools::strlen($cedetsy_shared_secret) < 5
                ) {
                    $output .= $this->displayError(
                        $this->l('The length of Keystring and Shared Secret must not less than 5')
                    );
                } else {
                    $output .= $this->displayConfirmation("Etsy configuration saved successfully");
                }
            }
        }

        return $output . $this->getGeneralSettingForm() . $this->displaySettingForm();
    }

    // create settings form for basic credentials

    public function displaySettingForm()
    {
        $fields_form = array();
        $fields_form[0]['form'] = $this->getProductSettingForm();
        $fields_form[1]['form'] = $this->getOrderSettingForm();
        $fields_form[2]['form'] = $this->getDefaultSettingForm();
        $fields_form[3]['form'] = $this->getCronInfoForm();
        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get(
            'PS_BO_ALLOW_EMPLOYEE_FORM_LANG'
        ) ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'etsysettings';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false) .
            '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );
        return $helper->generateForm($fields_form);
    }

    public function getGeneralSettingForm()
    {
        $cedEtsyHelper = new CedEtsyHelper;
        $config_values = $this->getConfigFormValues();
        $this->context->smarty->assign($config_values);
        if(!empty(Configuration::get('CEDETSY_KEYSTRING')) && !empty(Configuration::get('CEDETSY_SHARED_SECRET'))){
            $countries = $cedEtsyHelper->getCountries();
        } else {
            $countries = array();
        }

        $Shops = Shop::getShops(true, false, false);
        $this->context->smarty->assign(array(
            'etsy_country' => $countries,
            'Shops' => $Shops
        ));
        $general_setting_form = $this->context->smarty
            ->fetch(_PS_MODULE_DIR_ . 'cedetsy/views/templates/admin/configuration/general_settings.tpl');
        return $general_setting_form;
    }

    public function getProductSettingForm()
    {
        // $pricingRule = array();
        // if (!empty(Configuration::get('CEDETSY_PRICING_RULE'))) {
        //     $pricingRule = json_decode(Configuration::get('CEDETSY_PRICING_RULE'), true);
        // }
        // $this->context->smarty->assign(array(
        //     'CEDETSY_PRICING_RULE' => $pricingRule,
        // ));
        $this->context->smarty->assign(array(
            'CEDETSY_PRICE_VARIATION_TYPE' => Configuration::get('CEDETSY_PRICE_VARIATION_TYPE')
        ));
        $price_variation_html = $this->context->smarty
            ->fetch(_PS_MODULE_DIR_ . 'cedetsy/views/templates/admin/configuration/price_variation.tpl');
        $store_languages = array();

        $store_languages_list = Language::getLanguages(true);

        foreach ($store_languages_list as $languages) {
            if (isset($languages['id_lang']) && $languages['id_lang']
                && isset($languages['name']) && $languages['name']
                && isset($languages['active']) && $languages['active']) {
                array_push($store_languages, array(
                    'id' => $languages['id_lang'],
                    'name' => $languages['name']));
            }
        }
        return array(
            'legend' => array(
                'title' => $this->l('Product Settings'),
                'icon' => 'icon-cogs'
            ),
            'input' => array(
                array(
                    'type' => 'switch',
                    'label' => $this->l('Debug Mode'),
                    'name' => 'CEDETSY_DEBUG_MODE',
                    'is_bool' => true,
                    'desc' => $this->l('If enable Error and info will be logged in db.'),
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->l('Yes')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('No')
                        )
                    ),
                ),
                array(
                    'type' => 'html',
                    'label' => $this->l('Pricing Variation'),
                    'name' => $price_variation_html,
                    'col' => 6,
                ),
                array(
                    'col' => 6,
                    'type' => 'text',
                    'id' => 'fixed_price',
                    'prefix' => '<i class="icon icon-money"></i>',
                    'desc' => $this->l('Enter the Fixed amount which is to be added 
                    in product default price while creating or updating product feed for Etsy.'),
                    'name' => 'CEDETSY_PRICE_VARIATION_FIXED',
                    'label' => $this->l(' Fixed Amount'),
                ),
                array(
                    'col' => 6,
                    'type' => 'text',
                    'id' => 'fixed_per',
                    'prefix' => '<i class="icon icon-money"></i>',
                    'desc' => $this->l('Enter the Fixed percent which is to be added 
                    in product default price while creating or updating product feed for Etsy. 
                    Do not include any symbol like "%" etc.'),
                    'name' => 'CEDETSY_PRICE_VARIATION_PER',
                    'label' => $this->l(' Fixed Percentage'),
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Store Language'),
                    'desc' => $this->l('Store Language In Which Data Process.'),
                    'name' => 'CEDETSY_LANGUAGE_STORE',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $store_languages,
                        'id' => 'id',
                        'name' => 'name',
                    )
                ),
                array(
                    'type' => 'switch',
                    'label' => $this->l('Update Product on Edit'),
                    'name' => 'CEDETSY_UPDATE_PRODUCT_EDIT',
                    'is_bool' => true,
                    'desc' => $this->l('If enable then Product on Etsy will be automatically Updated By Cron.'),
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->l('Yes')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('No')
                        )
                    ),
                ),
                array(
                    'type' => 'switch',
                    'label' => $this->l('Upload Product on Add'),
                    'name' => 'CEDETSY_UPLOAD_PRODUCT_ADD',
                    'is_bool' => true,
                    'desc' => $this->l('Upload product on etsy when you add product on store.'),
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->l('Yes')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('No')
                        )
                    ),
                ),
                array(
                    'type' => 'switch',
                    'label' => $this->l('Remove Product From Etsy On Delete'),
                    'name' => 'CEDETSY_AUTO_DELETE_PRODUCT',
                    'is_bool' => true,
                    'desc' => $this->l('Disable product on etsy when you delete product on store .'),
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->l('Yes')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('No')
                        )
                    ),
                ),
            )
        );
    }

    public function getOrderSettingForm()
    {
        $CedEtsyHelper = new CedEtsyHelper;
        $CedEtsyShippingTemplate = new CedEtsyShippingTemplate;
        $shipping_templates = array();
        $shipping_templates[] = array('id' => '','name' => '-- Shipping Template --');

        if(!empty(Configuration::get('CEDETSY_KEYSTRING')) && !empty(Configuration::get('CEDETSY_SHARED_SECRET'))){
            $shipping_templates_list = $CedEtsyShippingTemplate->getAllShippingTemplates();

            if(isset($shipping_templates_list) && is_array($shipping_templates_list) && !empty($shipping_templates_list))
            {
                foreach ($shipping_templates_list as $shipping_template) {
                    if (isset($shipping_template['shipping_template_id']) && $shipping_template['shipping_template_id']
                        && isset($shipping_template['title']) && $shipping_template['title']) {
                        array_push($shipping_templates, array(
                            'id' => $shipping_template['shipping_template_id'],
                            'name' => $shipping_template['title']));
                    }
                }
            }
        }
        
        $id_lang = ((int) Configuration::get('CEDETSY_LANGUAGE_STORE'))?
            (int) Configuration::get('CEDETSY_LANGUAGE_STORE'):
            (int) Configuration::get('PS_LANG_DEFAULT');

         $order_states = $this->db->ExecuteS("SELECT `id_order_state`,`name`  FROM `"._DB_PREFIX_."order_state_lang` WHERE `id_lang` = '".(int)$id_lang."'");

         $order_carriers = $this->db->ExecuteS("SELECT `id_carrier`,`name` 
        FROM `"._DB_PREFIX_."carrier` where `active` = '1' and `deleted` = '0'");

         $payment_methods = array();

        $modules_list = Module::getPaymentModules();

        foreach ($modules_list as $module) {
            $module_obj = Module::getInstanceById($module['id_module']);
            if ($module_obj) {
                array_push($payment_methods, array('id'=>$module_obj->name,'name'=>$module_obj->displayName));
            }
        }

        return array(
            'legend' => array(
                'title' => $this->l('Order Settings'),
                'icon' => 'icon-cogs'
            ),
            'input' => array(
                array(
                    'type' => 'text',
                    'prefix' => '<i class="icon icon-envelope"></i>',
                    'desc' => $this->l('Customer Id to create order on store which are imported from etsy.'),
                    'name' => 'CEDETSY_CUSTOMER_ID',
                    'label' => $this->l('Customer ID'),
                ),
                array(
                    'type' => 'text',
                    'prefix' => '<i class="icon icon-envelope"></i>',
                    'desc' => $this->l('Order email to create order on store which are imported from etsy.'),
                    'name' => 'CEDETSY_ORDER_EMAIL',
                    'label' => $this->l('Order Email'),
                ),
                array(
                    'type' => 'select',
                    'prefix' => '',
                    'desc' => $this->l(''),
                    'name' => 'CEDETSY_SHIPPING_TEMPLATE',
                    'label' => $this->l('Shipping Template'),
                    'default_value' => '',
                    'options' => array(
                        'query' => $shipping_templates,
                        'id' => 'id',
                        'name' => 'name',
                    )
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Order Import Status'),
                    'desc' => $this->l('Order Status when imported from Etsy.'),
                    'name' => 'CEDETSY_ORDER_STATE',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_states,
                        'id' => 'id_order_state',
                        'name' => 'name',
                    )
                ),
                 array(
                    'type' => 'select',
                    'label' => $this->l('Order Carrier'),
                    'desc' => $this->l('Carrier used to import Order from Etsy.'),
                    'name' => 'CEDETSY_CARRIER_ID',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_carriers,
                        'id' => 'id_carrier',
                        'name' => 'name',
                    )
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Order Payment'),
                    'desc' => $this->l('Payment method used to import Order from Etsy.'),
                    'name' => 'CEDETSY_ORDER_PAYMENT',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $payment_methods,
                        'id' => 'id',
                        'name' => 'name',
                    )
                ),
            ),
        );
    }

    public function getDefaultSettingForm()
    {
        $cedEtsyHelper = new CedEtsyHelper;
        $default_values = $cedEtsyHelper->getDefaultFormFields();
        $this->context->smarty->assign(array(
            'default_values' => $default_values
        ));
        $default_html = $this->display(
            __FILE__,
            'views/templates/admin/configuration/default_settings.tpl'
        );
        
        return array(
            'legend' => array(
                'title' => $this->l('Default Settings'),
                'icon' => 'icon-cogs',
            ),
            'input' => array(
                array(
                    'type' => 'html',
                    'col' => 12,
                    'label' => $this->l(''),
                    'name' => $default_html,
                ),
            )
        );
    }

    public function getCronInfoForm()
    {
        $this->context->smarty->assign(array(
            'base_url' => Context::getContext()->shop->getBaseURL(true),
            'cron_secure_key' => Configuration::get('CEDETSY_CRON_SECURE_KEY')
        ));
        $cron_html = $this->display(
            __FILE__,
            'views/templates/admin/configuration/cron_table.tpl'
        );
        return array(
            'legend' => array(
                'title' => $this->l('Cron Info'),
                'icon' => 'icon-cogs',
            ),
            'input' => array(
                array(
                    'col' => 6,
                    'type' => 'text',
                    'id' => 'CEDETSY_CRON_SECURE_KEY',
                    'required' => false,
                    'prefix' => '<i class="icon icon-envelope"></i>',
                    'name' => 'CEDETSY_CRON_SECURE_KEY',
                    'label' => $this->l(' Cron Secure Key'),
                    'desc' => $this->l('This cron secure key need to set in 
                    the parameters of following cron urls'),
                ),

                array(
                    'type' => 'html',
                    'col' => 12,
                    'label' => $this->l(''),
                    'name' => $cron_html,
                ),
            ),
            'submit' => array(
                'title' => $this->l('Save'),
            )
        );
    }

    public function hookActionUploadProduct($params)
    {
        //CEDETSY_UPLOAD_PRODUCT_ADD
        $cedEtsyProduct = new CedEtsyProduct();
        $cedEtsyHelper = new CedEtsyHelper();
        try {
            $idProduct = isset($params['id_product']) ? $params['id_product'] : null;
            if (!empty($idProduct)) {
                if (Configuration::get('CEDETSY_UPLOAD_PRODUCT_ADD')) {
                    $result = $cedEtsyProduct->uploadProduct(array($idProduct));
                    $cedEtsyHelper->log(
                        __METHOD__,
                        'Info',
                        'Hook Product Update ' . $idProduct,
                        json_encode(
                            array(
                                'response' => $result
                            )
                        )
                    );
                }
            }
        } catch (\Exception $e) {
            $cedEtsyHelper->log(
                __METHOD__,
                'Exception',
                $e->getMessage(),
                json_encode(
                    array(
                        'Message' => $e->getMessage()
                    )
                ),
                true
            );
        }
    }

    public function hookActionProductUpdate($params)
    {
        $cedEtsyProduct = new CedEtsyProduct();
        $cedEtsyHelper = new CedEtsyHelper();
        try {
            $idProduct = isset($params['id_product']) ? $params['id_product'] : null;
            if (!empty($idProduct)) {
                if (Configuration::get('CEDETSY_UPDATE_PRODUCT_EDIT')) {
                    $result = $cedEtsyProduct->uploadProduct(array($idProduct));
                    $cedEtsyHelper->log(
                        __METHOD__,
                        'Info',
                        'Hook Product Update ' . $idProduct,
                        json_encode(
                            array(
                                'response' => $result
                            )
                        )
                    );
                }
            }
        } catch (\Exception $e) {
            $cedEtsyHelper->log(
                __METHOD__,
                'Exception',
                $e->getMessage(),
                json_encode(
                    array(
                        'Message' => $e->getMessage()
                    )
                ),
                true
            );
        }
    }

    //hook to disable product at Etsy after product is deleted from shop
    public function hookActionProductDelete($params)
    {
        $cedEtsyProduct = new CedEtsyProduct();
        $cedEtsyHelper = new CedEtsyHelper();
        try {
            $idProduct = isset($params['id_product']) ? $params['id_product'] : null;
            if (!empty($idProduct)) {
                if (Configuration::get('CEDETSY_AUTO_DELETE_PRODUCT')) {
                    $result = $cedEtsyProduct->deleteProductAtEtsy(array($idProduct));
                    $cedEtsyHelper->log(
                        __METHOD__,
                        'Info',
                        'Hook Product Delete ' . $idProduct,
                        json_encode(
                            array(
                                'response' => $result
                            )
                        )
                    );
                }
            }
        } catch (\Exception $e) {
            $cedEtsyHelper->log(
                __METHOD__,
                'Exception',
                $e->getMessage(),
                json_encode(
                    array(
                        'Trace' => $e->getTraceAsString()
                    )
                ),
                true
            );
        }
    }

    public function hookDisplayBackOfficeHeader($params)
    {
        if (!Module::isEnabled($this->name)) {
            return false;
        }
        if (method_exists($this->context->controller, 'addCSS')) {
            $this->context->controller->addCSS($this->_path . 'views/css/tab.css');
        }
        if (method_exists($this->context->controller, 'addJquery')) {
            $this->context->controller->addJquery();
        }
    }

    public function getConfigFormValues()
    {
        $config_value = array(
            'CEDETSY_LIVE_MODE' => Configuration::get('CEDETSY_LIVE_MODE') ?
                Configuration::get('CEDETSY_LIVE_MODE') : '',
            'CEDETSY_API_URL' => Configuration::get('CEDETSY_API_URL') ?
                Configuration::get('CEDETSY_API_URL') : '',
            'CEDETSY_KEYSTRING' => Configuration::get('CEDETSY_KEYSTRING') ?
                Configuration::get('CEDETSY_KEYSTRING') : '',
            'CEDETSY_SHARED_SECRET' => Configuration::get('CEDETSY_SHARED_SECRET') ?
                Configuration::get('CEDETSY_SHARED_SECRET') : '',
            'CEDETSY_API_ACCESS_TOKEN_SECRET' => Configuration::get('CEDETSY_API_ACCESS_TOKEN_SECRET') ?
                Configuration::get('CEDETSY_API_ACCESS_TOKEN_SECRET') : '',
            'CEDETSY_API_ACCESS_TOKEN' => Configuration::get('CEDETSY_API_ACCESS_TOKEN') ?
                Configuration::get('CEDETSY_API_ACCESS_TOKEN') : '',
            'CEDETSY_SHOP_NAME' => Configuration::get('CEDETSY_SHOP_NAME') ?
                Configuration::get('CEDETSY_SHOP_NAME') : '',
            'CEDETSY_USERNAME' => Configuration::get('CEDETSY_USERNAME') ?
                Configuration::get('CEDETSY_USERNAME') : '',
            'CEDETSY_COUNTRY' => Configuration::get('CEDETSY_COUNTRY') ?
                Configuration::get('CEDETSY_COUNTRY') : '',
            'CEDETSY_STORE' => Configuration::get('CEDETSY_STORE') ?
                Configuration::get('CEDETSY_STORE') : '',
            'CEDETSY_DEBUG_MODE' => Configuration::get('CEDETSY_DEBUG_MODE') ?
                Configuration::get('CEDETSY_DEBUG_MODE') : 0,
            'CEDETSY_PRICE_VARIATION_TYPE' => Configuration::get('CEDETSY_PRICE_VARIATION_TYPE') ?
                Configuration::get('CEDETSY_PRICE_VARIATION_TYPE') : '',
            'CEDETSY_PRICE_VARIATION_FIXED' => Configuration::get('CEDETSY_PRICE_VARIATION_FIXED') ?
                Configuration::get('CEDETSY_PRICE_VARIATION_FIXED') : '',
            'CEDETSY_PRICE_VARIATION_PER' => Configuration::get('CEDETSY_PRICE_VARIATION_PER') ?
                Configuration::get('CEDETSY_PRICE_VARIATION_PER') : '',
            'CEDETSY_LANGUAGE_STORE' => Configuration::get('CEDETSY_LANGUAGE_STORE') ?
                Configuration::get('CEDETSY_LANGUAGE_STORE') : '',
            'CEDETSY_UPDATE_PRODUCT_EDIT' => Configuration::get('CEDETSY_UPDATE_PRODUCT_EDIT') ?
                Configuration::get('CEDETSY_UPDATE_PRODUCT_EDIT') : 0,
            'CEDETSY_UPLOAD_PRODUCT_ADD' => Configuration::get('CEDETSY_UPLOAD_PRODUCT_ADD') ?
                Configuration::get('CEDETSY_UPLOAD_PRODUCT_ADD') : 0,
            'CEDETSY_AUTO_DELETE_PRODUCT' => Configuration::get('CEDETSY_AUTO_DELETE_PRODUCT') ?
                Configuration::get('CEDETSY_AUTO_DELETE_PRODUCT') : 0,
            'CEDETSY_CUSTOMER_ID' => Configuration::get('CEDETSY_CUSTOMER_ID') ?
                Configuration::get('CEDETSY_CUSTOMER_ID') : '',
            'CEDETSY_ORDER_EMAIL' => Configuration::get('CEDETSY_ORDER_EMAIL') ?
                Configuration::get('CEDETSY_ORDER_EMAIL') : '',
            'CEDETSY_ORDER_STATE' => Configuration::get('CEDETSY_ORDER_STATE') ?
                Configuration::get('CEDETSY_ORDER_STATE'): null,
            'CEDETSY_CARRIER_ID' => Configuration::get('CEDETSY_CARRIER_ID') ?
                Configuration::get('CEDETSY_CARRIER_ID'): null,
            'CEDETSY_ORDER_PAYMENT' => Configuration::get('CEDETSY_ORDER_PAYMENT') ?
                Configuration::get('CEDETSY_ORDER_PAYMENT'): null,
            'CEDETSY_SHIPPING_TEMPLATE' => Configuration::get('CEDETSY_SHIPPING_TEMPLATE') ?
                Configuration::get('CEDETSY_SHIPPING_TEMPLATE') : '',
            'CEDETSY_CRON_SECURE_KEY' => Configuration::get('CEDETSY_CRON_SECURE_KEY') ?
                Configuration::get('CEDETSY_CRON_SECURE_KEY') : '',
            'CEDETSY_OAUTH_TOKEN' =>Configuration::get('CEDETSY_OAUTH_TOKEN') ?
                Configuration::get('CEDETSY_OAUTH_TOKEN') : '',
            'CEDETSY_OAUTH_TOKEN_SECRET' => Configuration::get('CEDETSY_OAUTH_TOKEN_SECRET') ?
                Configuration::get('CEDETSY_OAUTH_TOKEN_SECRET') : '',
            'CEDETSY_OAUTH_CONSUMER_KEY' => Configuration::get('CEDETSY_OAUTH_CONSUMER_KEY') ?
                Configuration::get('CEDETSY_OAUTH_CONSUMER_KEY') : '',
        );
        $CedEtsyHelper = new CedEtsyHelper;
        $default_values = $CedEtsyHelper->getDefaultFormFields();
        if(isset($default_values) && is_array($default_values) && !empty($default_values))
        {
            foreach($default_values as $default_value)
            {
                $config_value[$default_value['title']] = Configuration::get($default_value['title']) ? Configuration::get($default_value['title']) : '';
            }
        }
        
        return $config_value;
    }

    public function ajaxProcessValidateApi()
    {
        $response = array();
        $api_url = Configuration::get('CEDETSY_API_URL');
        $keystring = Configuration::get('CEDETSY_KEYSTRING');
        $shared_secret = Configuration::get('CEDETSY_SHARED_SECRET');
        
        if(!empty($api_url) && !empty($keystring) && !empty($shared_secret)) 
        {
            try {
                $oauth = new OAuth($keystring, $shared_secret);
                // $base_url = Context::getContext()->shop->getBaseURL(true);
                // $calback_url = $base_url . 'index.php?controller=AdminModules&configure=cedetsy&tab_module=administration&module_name=cedetsy&token='. $this->token;

                $calback_url = $this->context->link->getAdminLink('AdminModules', false) . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name . '&token=' . Tools::getAdminTokenLite('AdminModules');
                
                $calback_url = html_entity_decode($calback_url);

                $req_token = $oauth->getRequestToken($api_url . "oauth/request_token?scope=email_r%20listings_r%20listings_w%20listings_d%20transactions_r%20transactions_w%20billing_r%20profile_r%20profile_w%20address_r%20address_w%20favorites_rw%20shops_rw%20shops_rw%20cart_rw%20recommend_rw%20feedback_r%20treasury_r%20treasury_w", $calback_url,"GET");

                $oauth_token = trim($req_token['oauth_token']);
                $oauth_token_secret = trim($req_token['oauth_token_secret']);
                $oauth_consumer_key = trim($req_token['oauth_consumer_key']);

                Configuration::updateValue('CEDETSY_OAUTH_TOKEN', $oauth_token);
                Configuration::updateValue('CEDETSY_OAUTH_TOKEN_SECRET', $oauth_token_secret);
                Configuration::updateValue('CEDETSY_OAUTH_CONSUMER_KEY', $oauth_consumer_key);
                
                $response['success']['login_url'] = $req_token['login_url'];
            } catch(Etsy\OAuthException $e){
                $response['error'] = $e->getLastResponse();
            }
        } else {
            $response['error'] = 'Please fill Required Details.';
        }
        die(Tools::jsonEncode($response));
    }

    public function getAuthorizedCredentials($verifier)
    {
        $response = array();
        $api_url = Configuration::get('CEDETSY_API_URL');
        $keystring = Configuration::get('CEDETSY_KEYSTRING');
        $shared_secret = Configuration::get('CEDETSY_SHARED_SECRET');
        $oauth_token = Configuration::get('CEDETSY_OAUTH_TOKEN');
        $oauth_token_secret = Configuration::get('CEDETSY_OAUTH_TOKEN_SECRET');
        if(!empty($api_url) && !empty($keystring) && !empty($shared_secret) && !empty($oauth_token) && !empty($oauth_token_secret))
        {
            try{
                $oauth = new OAuth($keystring, $shared_secret);
                $oauth->setToken($oauth_token, $oauth_token_secret);
                $acc_token = $oauth->getAccessToken($api_url . "oauth/access_token", null, $verifier, "GET");

                $cedetsy_access_token_secret = $acc_token['oauth_token_secret'];
                $cedetsy_token = $acc_token['oauth_token'];

                Configuration::updateValue('CEDETSY_API_ACCESS_TOKEN_SECRET', $cedetsy_access_token_secret);
                Configuration::updateValue('CEDETSY_API_ACCESS_TOKEN', $cedetsy_token);

                $this->confirmations[] = 'Verified Successfully!';
            } catch(Etsy\OAuthException $e){
                $this->errors[] = $e->getLastResponse();
            }
        } else {
            $this->errors[] = 'Required Details is missing!';
        }
        
    }
}
