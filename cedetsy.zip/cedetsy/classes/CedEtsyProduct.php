<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedEtsy
 */

include_once(_PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyHelper.php');
include_once(_PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyCategory.php');

class CedEtsyProduct
{
    public function __construct()
    {
        $this->db = Db::getInstance();
        $this->CedEtsyHelper = new CedEtsyHelper;
        $this->CedEtsyCategory = new CedEtsyCategory;
        $this->lang = ((int)Configuration::get('CEDETSY_LANGUAGE_STORE')) ? (int)Configuration::get('CEDETSY_LANGUAGE_STORE') : (int)Configuration::get('PS_LANG_DEFAULT');
    }

    public function uploadProducts($product_ids = array())
    {
        if (is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if(count($product_ids)==0)
        {
            $product_ids = $this->getAllEtsyProducts();
        }
        if(count($product_ids)) {
            foreach ($product_ids as $key => $product_id) {
                try {
                    $product_data = $this->prepareEtsyProduct($product_id);
                    if(isset($product_data['error_message']) && $product_data['error_message'])
                        return array('success' => false, 'message' => $product_data['error_message']);
                    if(isset($product_data['description']))
                        $product_data['description'] = strip_tags($product_data['description']);

                    if(isset($product_data['listing_id']) && $product_data['listing_id']) 
                    {
                        $listing_id = $product_data['listing_id'];
                        $profile_id = $product_data['profile_id'];

                        unset($product_data['listing_id']);
                        unset($product_data['quantity']);
                        unset($product_data['price']);
                        unset($product_data['profile_id']);
                        $params = array('data' => $product_data , 'params' => array('listing_id' => $listing_id ));
                        $response = $this->CedEtsyHelper->getRequestAuthorization()->updateListing($params);
                    } else {
                        if($product_data['state'] == 'active') {
                            $product_data['state'] = 'draft';
                        }
                        $profile_id = $product_data['profile_id'];
                        unset($product_data['profile_id']);
                        $params = array('data' => $product_data);

                        if ($this->CedEtsyHelper->getRequestAuthorization()) {
                            $response = $this->CedEtsyHelper->getRequestAuthorization()->createListing($params);
                        }
                    }

                    if($response && isset($response['results']['0']) && !empty($response['results']['0'])) {
                        $data = $response['results']['0'];
                        $data['profile_id'] = $profile_id;
                        if(!isset($data['image_ids']))
                        {
                            $data['image_ids'] = array();
                        }

                        $responseafter = $this->processAfterUpload($data, $product_id);
                        // echo '<pre>'; print_r($response); die;
                        if(isset($responseafter['success']) && $responseafter['success']) {
                            return array('success' => true, 'message' => 'Product, Variation and Image Uploaded On Etsy.');
                        } else {
                            return array('success' => true, 'message' => 'Product uploaded on Etsy but variation or images are failed to upload.');
                        }
                    } else {
                        return array('success' => false, 'message' => 'Failed to Upload Product on Etsy');
                    }
                } catch (Etsy\OAuthException $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: uploadProducts', 
                        'POST',
                        'OAuthException Product Upload',
                        Tools::jsonEncode($e->getMessage()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getMessage());
                }
                catch (Etsy\EtsyRequestException $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: uploadProducts', 
                        'POST',
                        'EtsyRequestException Product Upload',
                        Tools::jsonEncode($e->getLastResponse()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getLastResponse());
                }
                catch (Etsy\EtsyResponseException $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: uploadProducts', 
                        'POST',
                        'EtsyResponseException Product Upload',
                        Tools::jsonEncode($e->getResponse()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getResponse());
                } catch (Exception $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: uploadProducts', 
                        'POST',
                        'Exception Product Upload',
                        Tools::jsonEncode($e->getMessage()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getMessage());
                }
            }
        }
    }

    public function prepareEtsyProduct($product_id)
    {
        if($product_id) 
        {
            $product_mapping_info = $this->getMappingDataByProduct($product_id);
            
            $product_data = array();
            $product_data["quantity"] = (int)$product_mapping_info['quantity'];
            if(count($product_mapping_info['quantity']) && ($product_mapping_info['quantity']>999))
                return array('error_message' => 'Product Qty can not be greater than 999.');
            $product_data["title"] = (string) $product_mapping_info['title'];
            $product_data["description"] = addslashes(strip_tags($product_mapping_info['description']));

            $product_data["price"] = (float) $this->getEtsyProductPrice($product_id);
            $product_data["materials"] =array((string)$product_mapping_info['title']) ;
            $product_data["shipping_template_id"] = (int)$product_mapping_info['shipping_template_id'];
            $product_data["shop_section_id"] = (int)$product_mapping_info['shop_section_id'];
            //$product_data["image_ids"] = $product_mapping_info['shipping_template_id'];
            //$product_data["is_customizable"] = (bool)$product_mapping_info['is_customizable'];
            //$product_data["image"] = '@'.DIR_IMAGE.$product_mapping_info['image'].';type=image/jpg';
            $product_data["non_taxable"] = (bool)$product_mapping_info['non_taxable'];
            $product_data["state"] =  (string) $product_mapping_info['state'];
            $product_data["processing_min"] = (int)$product_mapping_info['processing_min'];
            $product_data["processing_max"] = (int)$product_mapping_info['processing_max'];
            $product_data["category_id"] = (int)$product_mapping_info['category_id'];
            $product_data["taxonomy_id"] = (int)$product_mapping_info['taxonomy_id'];
            $product_data["tags"] = array($product_mapping_info['tags']);
            $product_data["who_made"] =(string)$product_mapping_info['who_made'];
            $product_data["is_supply"] = (bool)$product_mapping_info['is_supply'];
            $product_data["when_made"] =(string)$product_mapping_info['when_made'];
            $product_data["recipient"] =(string)$product_mapping_info['recipient'];
            $product_data["occasion"] =(string)$product_mapping_info['occasion'];
            $product_data["style"] =array((string)$product_mapping_info['style']);

            if(isset($product_mapping_info['listing_id']) && $product_mapping_info['listing_id'])
            {
                $product_data["listing_id"] =(int)$product_mapping_info['listing_id'];
            }
            $product_data['profile_id'] = (int)$product_mapping_info['profile_id'];

            if(!empty($product_data))
            {
                return $product_data;
            }
            return array('error_message' => 'Product Id Not Found.');
        }
        return array('error_message' => 'Product Id Not Found.');
    }

    public function getMappingDataByProduct($product_id)
    {
        $mapped_data = array();
        $is_etsy_product = false;
        $query = $this->db->ExecuteS("SELECT `id_category` FROM `". _DB_PREFIX_ ."category_product` WHERE `id_product` = '".(int) $product_id."'");
        $category_ids = array();
        if (is_array($query) && !empty($query)) {
            foreach ($query as $result) {
                $category_ids[] = $result['id_category'];
            }
        }

        if(!empty($category_ids)) 
        {
            $product_category_ids = array();
            foreach ($category_ids as $key => $value) {
                $product_category_ids[] = $value;
            }
            $store_category = $this->db->ExecuteS("SELECT * FROM `". _DB_PREFIX_ ."cedetsy_category_mapping`");

            if(is_array($store_category) && !empty($store_category)) {
                foreach ($store_category as $key => $store_cat) {

                    if(Tools::jsonDecode($store_cat['store_category'], true) && array_intersect(Tools::jsonDecode($store_cat['store_category'], true), $product_category_ids)) {
                        if($store_cat['etsy_category'] && Tools::jsonDecode($store_cat['etsy_category'], true)) 
                        {
                            $etsy_category =  Tools::jsonDecode($store_cat['etsy_category'], true);
                            $etsy_category = end($etsy_category);
                            $mapped_data['taxonomy_id'] = $etsy_category;
                            $mapped_data['profile_id'] = $store_cat['id'];
                            $is_etsy_product = true;
                        }
                        break;
                    }
                }
            }
        }
        
        if($is_etsy_product) {
            $product = (array)new Product($product_id, true, $this->lang);
            
            $mapped_fields = Tools::jsonDecode($store_cat['mapped_fields'], true );
            $default_values = Tools::jsonDecode($store_cat['default_values'], true );
            $mapped_fields['image'] = 'image';
            foreach ($mapped_fields as $key => $value) {
                if(isset($product[trim($value)]) && $product[trim($value)])
                {
                    $mapped_data[trim($key)] =  $product[trim($value)];
                } else if(in_array(trim($key), array('shipping_template_id','shop_section_id'))){
                    $mapped_data[trim($key)] =  trim($value);
                }
            }

            foreach ($default_values as $key => $value) {
                $mapped_data[trim($key)] =  trim($value);
            }
            if(isset($mapped_data['taxonomy_id'])){
                $category_id = $this->db->getValue("SELECT `category_id` FROM `". _DB_PREFIX_ ."cedetsy_category` WHERE `children_id`='".(int)$mapped_data['taxonomy_id']."'");
                if(!empty($category_id))
                {
                    $mapped_data['category_id'] = $category_id;
                }
            }

            $listing_id = $this->db->getValue("SELECT `listing_id` FROM `". _DB_PREFIX_ ."cedetsy_product` WHERE `product_id`='".(int)$product_id."'");
            if(!empty($listing_id)) {
                $mapped_data['listing_id'] = $listing_id;
            }

            // default values applications

            if((!isset($mapped_data['shipping_template_id']) || !$mapped_data['shipping_template_id']) && Configuration::get('CEDETSY_SHIPPING_TEMPLATE')){
                $mapped_data['shipping_template_id'] = Configuration::get('CEDETSY_SHIPPING_TEMPLATE');
            }

            if((!isset($mapped_data['materials']) || !$mapped_data['materials']) && Configuration::get('CEDETSY_MATERIALS')) {
                $mapped_data['materials'] = Configuration::get('CEDETSY_MATERIALS');
            }

            if((!isset($mapped_data['tags']) || !$mapped_data['tags']) && Configuration::get('CEDETSY_TAGS')){
                $mapped_data['tags'] = Configuration::get('CEDETSY_TAGS');
            }

            if((!isset($mapped_data['processing_min']) || !$mapped_data['processing_min']) && Configuration::get('CEDETSY_PROCESSING_MIN')){
                $mapped_data['processing_min'] = Configuration::get('CEDETSY_PROCESSING_MIN');
            }

            if((!isset($mapped_data['processing_max']) || !$mapped_data['processing_max']) && Configuration::get('CEDETSY_PROCESSING_MAX')){
                $mapped_data['processing_max'] = Configuration::get('CEDETSY_PROCESSING_MAX');
            }

            if((!isset($mapped_data['non_taxable']) || !$mapped_data['non_taxable']) && Configuration::get('CEDETSY_NON_TAXABLE')){
                $mapped_data['non_taxable'] = Configuration::get('CEDETSY_NON_TAXABLE');
            }

            if((!isset($mapped_data['is_supply']) || !$mapped_data['is_supply']) && Configuration::get('CEDETSY_IS_SUPPLY')){
                $mapped_data['is_supply'] = Configuration::get('CEDETSY_IS_SUPPLY');
            }

            if((!isset($mapped_data['state']) || !$mapped_data['state']) && Configuration::get('CEDETSY_STATE')){
                $mapped_data['state'] = Configuration::get('CEDETSY_STATE');
            }

            if((!isset($mapped_data['who_made']) || !$mapped_data['who_made']) && Configuration::get('CEDETSY_WHO_MADE')){
                $mapped_data['who_made'] = Configuration::get('CEDETSY_WHO_MADE');
            }

            if((!isset($mapped_data['when_made']) || !$mapped_data['when_made']) && Configuration::get('CEDETSY_WHEN_MADE')){
                $mapped_data['when_made'] = Configuration::get('CEDETSY_WHEN_MADE');
            }

            if((!isset($mapped_data['recipient']) || !$mapped_data['recipient']) && Configuration::get('CEDETSY_RECIPIENT')){
                $mapped_data['recipient'] = Configuration::get('CEDETSY_RECIPIENT');
            }

            if((!isset($mapped_data['occasion']) || !$mapped_data['occasion']) && Configuration::get('CEDETSY_OCCASION')){
                $mapped_data['occasion'] = Configuration::get('CEDETSY_OCCASION');
            }

            if((!isset($mapped_data['style']) || !$mapped_data['style']) && Configuration::get('CEDETSY_STYLE')){
                $mapped_data['style'] = Configuration::get('CEDETSY_STYLE');
            }

            return $mapped_data;
        }
    }

    public function getEtsyProductPrice($product_id)
    {
        if($product_id) 
        {
            $etsy_price = 0;
            $price = 0 ;
            $price_variation_type = Configuration::get('CEDETSY_PRICE_VARIATION_TYPE');

            if(!empty(Configuration::get('CEDETSY_PRICE_VARIATION_FIXED'))){
               $price_variation_type_amount = (float) Configuration::get('CEDETSY_PRICE_VARIATION_FIXED'); 
           } else {
            $price_variation_type_amount = (float) Configuration::get('CEDETSY_PRICE_VARIATION_PER');
           }
            $price = $this->db->getValue("SELECT `price` FROM " . _DB_PREFIX_ . "product WHERE `id_product` = '" . (int)$product_id . "'");
            // echo '<pre>'; print_r($price); die;
            switch ($price_variation_type) {
                case 'regular':
                    $etsy_price = $price;
                    break;

                // case 'special':
                //     $price = $this->db->getValue("SELECT `price` FROM " . _DB_PREFIX_ . "product_special WHERE `id_product` = '" . (int)$product_id . "' AND ((date_start = '0000-00-00' OR date_start < NOW()) AND (date_end = '0000-00-00' OR date_end > NOW())) ORDER BY priority ASC, price ASC");
                //     $etsy_price = $price;
                //     break;

                case 'increase_by_amount':
                    $etsy_price = $price + $price_variation_type_amount;
                    break;

                case 'increase_by_percent':
                    $etsy_price = $price + ($price * $price_variation_type_amount)/100;
                    break;

                case 'decrease_by_amount':
                    $etsy_price = $price - $price_variation_type_amount;
                    break;

                case 'decrease_by_percent':
                    $etsy_price = $price - ($price * $price_variation_type_amount)/100;
                    break;

                default:
                    $etsy_price = $price;
                    break;
            }
            return $etsy_price ;
        }
        return 0;
    }

    public function processAfterUpload($data, $product_id)
    {
        $existingProductId = $this->db->getValue("SELECT product_id FROM `". _DB_PREFIX_ ."cedetsy_product` WHERE `product_id` ='".(int)$product_id."'");
        if ($existingProductId) {
            $this->db->update(
                'cedetsy_product',
                array(
                    'shop_section_id' => pSQL($data['shop_section_id']), 
                    'listing_id' => pSQL($data['listing_id']), 
                    'state' => pSQL($data['state']), 
                    'url' => pSQL($data['url']), 
                    'views' => pSQL($data['views']), 
                    'num_favorers' => pSQL($data['num_favorers']), 
                    'image_ids' => pSQL(Tools::jsonEncode($data['image_ids'])), 
                    'featured_rank' => pSQL(Tools::jsonEncode($data['featured_rank']))
                    ),
                 'product_id='.(int)$product_id);
        } else {
            $this->db->insert(
                'cedetsy_product',
                array(
                    'shop_section_id' => pSQL($data['shop_section_id']), 
                    'listing_id' => pSQL($data['listing_id']), 
                    'state' => pSQL($data['state']), 
                    'url' => pSQL($data['url']), 
                    'views' => pSQL($data['views']), 
                    'num_favorers' => pSQL($data['num_favorers']), 
                    'image_ids' => pSQL(Tools::jsonEncode($data['image_ids'])), 
                    'featured_rank' => pSQL(Tools::jsonEncode($data['featured_rank'])),
                    'product_id' => (int)$product_id
                    )
                 );
        }
        $response = $this->uploadProductVariations($product_id, $data);
        $response = $this->uploadProductImages($product_id, $data['listing_id']);
        return $response;
    }

    public function uploadProductImages($product_id, $listing_id=0, $image_listing_id=0)
    {
         $product_images_data   = Image::getImages($this->lang, $product_id, '');
        // $product_images_data = $this->db->ExecuteS('SELECT * FROM `' . _DB_PREFIX_ . 'image` i LEFT JOIN `' . _DB_PREFIX_ . 'image_lang` il ON (i.`id_image` = il.`id_image`) WHERE i.`id_product` = ' . (int)$product_id . ' AND il.`id_lang` = ' . (int)$this->lang . ' ORDER BY i.`position` ASC');
        
        if(isset($product_images_data) && !empty($product_images_data)) 
        {
            // if (version_compare(_PS_VERSION_, '1.7', '>=') === true) {
            //     $type = ImageType::getFormattedName('thickbox');
            // } else {
            //     $type = ImageType::getFormatedName('thickbox');
            // }

            $product = new Product($product_id);
            $link = new Link;
            $product_images = array();
            foreach ($product_images_data as $image) 
            {
                $image_url = $link->getImageLink(
                    $product->link_rewrite[$this->lang],
                    $image['id_image'],
                    null
                );
                // $product_images[] = $image;

                if (isset($image['cover']) && $image['cover']) 
                {
                    $image['image'] = (Configuration::get('PS_SSL_ENABLED') ?
                            'https://' : 'http://') . $image_url;
                } else {
                    if (!isset($image['image'])) {
                        $image['image'] = (Configuration::get('PS_SSL_ENABLED') ?
                                'https://' : 'http://') . $image_url;
                    }
                    //  else {
                    //     $image['image'][] =
                    //         (Configuration::get('PS_SSL_ENABLED') ?
                    //             'https://' : 'http://') . $image_url;
                    // }
                }
            // }
            // echo '<pre>'; print_r($product_images);
            // foreach ($product_images as $image) 
            // {
                
                $etsy_image = array();
                $etsy_image['listing_id'] = (int) $listing_id;
                $mimetype = ImageManager::isRealImage($image['image'], null, null);
                $etsy_image['image'] = '@'.$image['image'].';type='.$mimetype;
                if($image_listing_id){
                    $etsy_image['image_listing_id'] = (int) $image_listing_id;
                }
                $etsy_image['rank'] =(int) $image['position'] ;
                $etsy_image['overwrite'] = (bool)true;
                $etsy_image['is_watermarked'] =(bool) false ;

                try {
                    $params = array('params'=> $etsy_image);

                    // $params = array('params'=> $etsy_image, 'data' => array('image' =>array('@'.$image['image'].';type='.$mimetype)));

                    if ($this->CedEtsyHelper->getRequestAuthorization()) 
                    {
                        $response = $this->CedEtsyHelper->getRequestAuthorization()->uploadListingImage($params);
                    }

                    if($response && isset($response['results']['0']) && !empty($response['results']['0'])) {
                        $data = $response['results']['0'];
                        if(!isset($data['image_ids'])){
                            $data['image_ids'] = array();
                        }
                        $this->db->insert(
                            'cedetsy_product_image',
                            array(
                                'image_listing_id' => pSQL($data['image_listing_id']), 
                                'listing_id' => pSQL($data['listing_id']), 
                                'rank' => pSQL($data['rank']), 
                                'overwrite' => pSQL($data['overwrite']), 
                                'is_watermarked' => pSQL($data['is_watermarked']), 
                                'image_id' => pSQL(Tools::jsonEncode($data['image_id'])), 
                                'product_id' => (int)$data['product_id']
                                )
                             );
                        return array('success' => true, 'message' => 'Image Uploaded On Etsy');
                    } else {
                        return array('success' => false, 'message' => 'No Response From Etsy');
                    }
                } catch (Etsy\OAuthException $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: uploadProductImages', 
                        'POST',
                        'OAuthException Image Upload',
                        Tools::jsonEncode($e->getMessage()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getMessage());
                }
                catch (Etsy\EtsyRequestException $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: uploadProductImages', 
                        'POST',
                        'EtsyRequestException Image Upload',
                        Tools::jsonEncode($e->getLastResponse()),
                        true
                    );
                }
                catch (Etsy\EtsyResponseException $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: uploadProductImages', 
                        'POST',
                        'EtsyRequestException Image Upload',
                        Tools::jsonEncode($e->getResponse()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getResponse());
                } catch (Exception $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: uploadProductImages', 
                        'POST',
                        'Exception Image Upload',
                        Tools::jsonEncode($e->getMessage()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getMessage());
                }
            }
        }
    }

    public function getOptionMappingData($mapping_id)
    {
        $option_mapping_data = $this->db->ExecuteS("SELECT * FROM `". _DB_PREFIX_ ."cedetsy_option_mapping` WHERE `mapping_id` = '". (int) $mapping_id ."' ");
        return $option_mapping_data;
    }

    public function uploadProductVariations($product_id, $data)
    {
        try {
            $listing_id  = $data['listing_id'];
            $mapping_id  = $data['profile_id'];
            $taxonomy_id = $data['taxonomy_id'];
            $category_id = $data['category_id'];

            $product_mapped_options = $this->getOptionMappingData($mapping_id);

            $property_ids = array();
            $variants     = array();
            $final_array  = array();

            if(isset($product_mapped_options) && !empty($product_mapped_options))
            {
                foreach($product_mapped_options as $key => $option_mapping)
                {
                    $store_attribute_detail = $this->getStoreAttributeDetails($option_mapping['store_attribute_group'], $option_mapping['store_attribute_id'], $product_id);

                    $property_ids[] = $option_mapping['property_id'];

                    $variants[] = array(
                        'property_values' => array($option_mapping['mapped_options']),
                        'sku' => (string) $store_attribute_detail['sku'],
                        'offerings' => array(
                            'price' =>  number_format((float)$store_attribute_detail['price'], 2),
                            'quantity' => (int) $store_attribute_detail['quantity'],
                            'is_enabled' => (int) true, 
                        ),
                    );
                }
            } else {
                return array('success' => false, 'message' => 'Attributes not mapped yet!');
            }

            if(!empty($property_ids)){
                $property_ids = array_unique($property_ids);
                $property_ids = implode(',', $property_ids);
            }
            $final_array['params']['listing_id'] = (int) $listing_id;
            $final_array['data']['listing_id'] = (int) $listing_id;
            $final_array['data']['products'] = ['json' => (string)Tools::jsonEncode($variants)];
            $final_array['data']['price_on_property'] = array($property_ids);
            $final_array['data']['quantity_on_property'] = array($property_ids) ;
            $final_array['data']['sku_on_property'] =  array($property_ids);

            if($this->CedEtsyHelper->getRequestAuthorization())
            {
                $responseInventory = $this->CedEtsyHelper->getRequestAuthorization()->updateInventory($final_array);

                if(isset($responseInventory['results']) && !empty($responseInventory['results']['0']))
                {
                    return array('success' => true, 'message' => 'Variations Uploaded On Etsy');
                } else {
                    return array('success' => true, 'message' => $responseInventory);
                }
            }
        } catch (Etsy\OAuthException $e) {
            $this->CedEtsyHelper->log(
                'CedEtsyProductClass:: uploadProductVariations', 
                'POST',
                'OAuthException Upload Product Variations',
                Tools::jsonEncode($e->getMessage()),
                true
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
        catch (Etsy\EtsyRequestException $e) {
            $this->CedEtsyHelper->log(
                'CedEtsyProductClass:: uploadProductVariations', 
                'POST',
                'EtsyRequestException Upload Product Variations',
                Tools::jsonEncode($e->getLastResponse()),
                true
            );
            return array('success' => false, 'message' => $e->getLastResponse());
        }
        catch (Etsy\EtsyResponseException $e) {
            $this->CedEtsyHelper->log(
                'CedEtsyProductClass:: uploadProductVariations', 
                'POST',
                'EtsyRequestException Upload Product Variations',
                Tools::jsonEncode($e->getResponse()),
                true
            );
            return array('success' => false, 'message' => $e->getResponse());
        } catch (Exception $e) {
            $this->CedEtsyHelper->log(
                'CedEtsyProductClass:: uploadProductVariations', 
                'POST',
                'Exception Upload Product Variations',
                Tools::jsonEncode($e->getMessage()),
                true
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
    }

    public function getStoreAttributeDetails($attribute_group, $store_attribute_id, $product_id)
    {
        $response = array();
        $specific_price_output = null;
        $price = Product::getPriceStatic(
            $product_id,
            false,
            null,
            2,
            null,
            false,
            true,
            1,
            false,
            null,
            null,
            null,
            $specific_price_output,
            true,
            true,
            null,
            true,
            null
            );

        $quantity = Product::getQuantity(
            $product_id,
            null,
            null,
            null,
            null
            );

        $attr_type = explode('-', $attribute_group);

        if($attr_type['0'] == 'option')
        {
            $option_values = $this->db->ExecuteS("SELECT pa.`reference`, pa.`price`, pa.`quantity` FROM `". _DB_PREFIX_ ."attribute_lang` AS al LEFT JOIN `". _DB_PREFIX_ ."attribute` AS a ON (a.`id_attribute` = al.`id_attribute` AND al.`id_lang` = '". (int) $this->lang ."' AND a.`id_attribute_group` = '". (int)$attr_type['1'] ."') LEFT JOIN `". _DB_PREFIX_ ."product_attribute_combination` AS pac ON (a.`id_attribute` = pac.`id_attribute`) LEFT JOIN `". _DB_PREFIX_ ."product_attribute` AS pa ON (pac.`id_product_attribute` = pa.`id_product_attribute` AND pa.`id_product` = '". (int) $product_id."') WHERE a.`id_attribute` = '". $store_attribute_id ."' ");

            $response['price'] = (float) $price;
            $response['quantity'] = (int) $quantity;
            foreach($option_values as $key => $option_value)
            {
                // $response['value'] = (string) $option_value['name'];
                $response['sku'] = (string) $option_value['reference'];
                if(!empty($option_value['price']) && $option_value['price'] != '0') {
                    $response['price'] = (float) $option_value['price'];
                }

                if(!empty($option_value['quantity'])) {
                    $response['quantity'] = (int) $option_value['quantity'];
                }
            }
            return $response;
        } else if($attr_type['0'] == 'attribute') 
        {
            $attribute_value = $this->db->ExecuteS("SELECT `value` FROM `". _DB_PREFIX_ ."feature_product` AS fp LEFT JOIN `". _DB_PREFIX_ ."feature_value_lang` AS fvl ON (fp.id_feature_value = fvl.id_feature_value AND id_lang = '". $this->lang ."') WHERE fp.`id_feature` = '". (int) $attr_type['1'] ."' AND `id_product` = '". (int) $product_id ."' ");
            //$response['value'] = (string) $attribute_value['0']['value'];
            $response['sku'] = (string) '';
            $response['price'] = (float) $price;
            $response['quantity'] = (int) $quantity;
            return $response;
        } else {
            $product_value = $this->db->ExecuteS("SELECT `".$attr_type['1']."`, `reference` FROM `". _DB_PREFIX_ ."product` WHERE `id_product` = '". $product_id ."' ");

            //$response['value'] = (string) $product_value['0'][$attr_type['1']];
            $response['sku'] = (string) $product_value['reference'];
            $response['price'] = (float) $price;
            if($attr_type['1'] == 'price')
            {
                $response['price'] = (float) $product_value['0']['price'];
            }

            $response['quantity'] = (int) $quantity;
            if($attr_type['1'] == 'quantity')
            {
                $response['quantity'] = (int) $product_value['0']['quantity'];
            }
            return $response;
        }
    }

	public function getAllEtsyProducts()
    {
        $result = $this->db->ExecuteS("SELECT `store_category` FROM `". _DB_PREFIX_ ."cedetsy_category_mapping`");
        if (is_array($result) && !empty($result)) {
            $product_ids = array();
            $categories_mapped = array();
            foreach ($result as $key => $store_category) {
                $categories_mapped = array_merge($categories_mapped, Tools::jsonDecode($store_category['store_category'], true));
            }
            if(count($categories_mapped)){
                $categories_mapped = array_unique($categories_mapped);
                $result = $this->db->ExecuteS("SELECT `product_id` FROM `"._DB_PREFIX_."category_product` WHERE category_id IN (".implode(',', $categories_mapped).")");
                if (is_array($result) && !empty($result)) {
                    foreach ($result as $key => $value) {
                        $product_ids[] =  $value['product_id'];
                    }
                }
                return $product_ids ;
            }
            return array();
        } else {
            return array();
        }
    }

	public function deleteProducts($product_ids = array())
    {
        if (is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if(count($product_ids)==0){
            $product_ids = $this->getAllEtsyProducts();
        }
        if(count($product_ids)) {
            foreach ($product_ids as $key => $product_id) {
                $response = array();
                try {
                    $product_data = $this->prepareEtsyProduct($product_id);
                    if(isset($product_data['listing_id']) && $product_data['listing_id']) 
                    {
                        $listing_id = $product_data['listing_id'];
                        $params = array('params' => array('listing_id' => $listing_id ));

                         $this->CedEtsyHelper->log(
                                'CedEtsyProductClass:: deleteProducts', 
                                'POST',
                                'deleteListing Params',
                                Tools::jsonEncode($params),
                                true
                            );
                         if($this->CedEtsyHelper->getRequestAuthorization())
                         {
                            $response = $this->CedEtsyHelper->getRequestAuthorization()->deleteListing($params);
                            $this->CedEtsyHelper->log(
                                'CedEtsyProductClass:: deleteProducts', 
                                'POST',
                                'deleteListing Response',
                                Tools::jsonEncode($response),
                                true
                            );
                         }
                    }
                    if($response && isset($response['count']) && ($response['count']==0)) {
                        Db::getInstance()->delete(
                            'cedetsy_product',
                            'product_id=' . (int) $product_id
                            );
                        return array('success' => true, 'message' => 'Product Deleted On Etsy');
                    } else {
                        return array('success' => false, 'message' => 'Failed to delete product on Etsy');
                    }
                } catch (Etsy\OAuthException $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: deleteProducts', 
                        'POST',
                        'OAuthException Delete Product',
                        Tools::jsonEncode($e->getMessage()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getMessage());
                }
                catch (Etsy\EtsyRequestException $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: deleteProducts', 
                        'POST',
                        'EtsyRequestException Delete Product',
                        Tools::jsonEncode($e->getLastResponse()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getLastResponse());
                }
                catch (Etsy\EtsyResponseException $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: deleteProducts', 
                        'POST',
                        'EtsyRequestException Delete Product',
                        Tools::jsonEncode($e->getResponse()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getResponse());
                } catch (Exception $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: deleteProducts', 
                        'POST',
                        'Exception Delete Product',
                        Tools::jsonEncode($e->getMessage()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getMessage());
                }
            }
        }
    }

    public function enableProducts($product_ids = array())
    {
        if (is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if(count($product_ids)==0){
            $product_ids = $this->getAllEtsyProducts();
        }
        if(count($product_ids)) {
            foreach ($product_ids as $key => $product_id) {
                try {
                    $product_data = $this->prepareEtsyProduct($product_id);
                    if(isset($product_data['listing_id']) && $product_data['listing_id']) 
                    {
                        $listing_id = $product_data['listing_id'];
                        $profile_id = $product_data['profile_id'];
                        unset($product_data['listing_id']);
                        unset($product_data['profile_id']);
                        if($product_data['state'] == 'draft'){
                            $product_data['state'] = 'active';
                        }
                        $params = array('data' => $product_data , 'params' => array('listing_id' => $listing_id ));
                        if($this->CedEtsyHelper->getRequestAuthorization()) {
                            $response = $this->CedEtsyHelper->getRequestAuthorization()->updateListing($params);
                        }
                    }
                    if($response && isset($response['count']) && ($response['count']==1)) {
                        Db::getInstance()->update(
                            'cedetsy_product',
                            array(
                                'state' => pSQL('active')
                                ),
                            'product_id=' . (int) $product_id
                            );
                        return array('success' => true, 'message' => 'Product Enabled On Etsy ');
                    } else {
                        return array('success' => false, 'message' => 'Failed to enable product on Etsy');
                    }
                } catch (Etsy\OAuthException $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: enableProducts', 
                        'POST',
                        'OAuthException Enable Product',
                        Tools::jsonEncode($e->getMessage()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getMessage());
                }
                catch (Etsy\EtsyRequestException $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: enableProducts', 
                        'POST',
                        'EtsyRequestException Enable Product',
                        Tools::jsonEncode($e->getLastResponse()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getLastResponse());
                }
                catch (Etsy\EtsyResponseException $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: enableProducts', 
                        'POST',
                        'EtsyRequestException Enable Product',
                        Tools::jsonEncode($e->getResponse()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getResponse());
                } catch (Exception $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: enableProducts', 
                        'POST',
                        'Exception Enable Product',
                        Tools::jsonEncode($e->getMessage()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getMessage());
                }
            }
        }
    }
    public function disableProducts($product_ids = array())
    {
        if (is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if(count($product_ids)==0){
            $product_ids = $this->getAllEtsyProducts();
        }
        if(count($product_ids)) {
            foreach ($product_ids as $key => $product_id) {
                try {
                    $product_data = $this->prepareEtsyProduct($product_id);
                    if(isset($product_data['listing_id']) && $product_data['listing_id']) 
                    {
                        $listing_id = $product_data['listing_id'];
                        $profile_id = $product_data['profile_id'];
                        unset($product_data['listing_id']);
                        unset($product_data['profile_id']);
                        if($product_data['state'] == 'active'){
                            $product_data['state'] = 'draft';
                        }
                        $params = array('data' => $product_data , 'params' => array('listing_id' => $listing_id ));
                        if($this->CedEtsyHelper->getRequestAuthorization()) 
                        {
                            $response = $this->CedEtsyHelper->getRequestAuthorization()->updateListing($params);
                        }
                    }
                    if($response && isset($response['count']) && ($response['count']==1)) {
                        Db::getInstance()->update(
                            'cedetsy_product',
                            array(
                                'state' => pSQL('draft')
                                ),
                            'product_id=' . (int) $product_id
                            );
                        return array('success' => true, 'message' => 'Product Disabled On Etsy');
                    } else {
                        return array('success' => false, 'message' => 'Failed to disable product on Etsy');
                    }
                } catch (Etsy\OAuthException $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: disableProducts', 
                        'POST',
                        'OAuthException Disable Product',
                        Tools::jsonEncode($e->getMessage()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getMessage());
                } catch (Etsy\EtsyRequestException $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: disableProducts', 
                        'POST',
                        'EtsyRequestException Disable Product',
                        Tools::jsonEncode($e->getLastResponse()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getLastResponse());
                } catch (Etsy\EtsyResponseException $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: disableProducts', 
                        'POST',
                        'EtsyRequestException Disable Product',
                        Tools::jsonEncode($e->getResponse()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getResponse());
                } catch (Exception $e) {
                    $this->CedEtsyHelper->log(
                        'CedEtsyProductClass:: disableProducts', 
                        'POST',
                        'Exception Disable Product',
                        Tools::jsonEncode($e->getMessage()),
                        true
                    );
                    return array('success' => false, 'message' => $e->getMessage());
                }
            }
        }
    }

    public function getMappedCategoryIds()
    {
        $store_category = Db::getInstance()->ExecuteS("SELECT * FROM `" . _DB_PREFIX_ . "cedetsy_category_mapping`");
        $categories = array();
        if (is_array($store_category) && !empty($store_category)) {
            foreach ($store_category as $key => $store_cat) 
            {
                if (Tools::jsonDecode($store_cat['store_category'], true)) 
                {
                    $store_category = Tools::jsonDecode($store_cat['store_category'], true);
                    $categories = array_merge($categories, $store_category);
                }
            }
            $categories = array_filter($categories);
            $categories = array_unique($categories);
        }
        return $categories;
    }
}