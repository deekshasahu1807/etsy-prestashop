<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedEtsy
 */

include_once _PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyHelper.php';
include_once _PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyCategory.php';
include_once(_PS_MODULE_DIR_ . 'cedetsy/classes/CedEtsyShippingTemplate.php');

class AdminCedEtsyCatMappingController extends ModuleAdminController
{
	public function __construct()
    {
        $this->db         = Db::getInstance();
        $this->CedEtsyHelper   = new CedEtsyHelper;
        $this->CedEtsyCategory = new CedEtsyCategory;
        $this->CedEtsyShippingTemplate = new CedEtsyShippingTemplate;
        $this->bootstrap  = true;
        $this->lang = (!isset($this->context->cookie) ||
            !is_object($this->context->cookie)) ?
            (int)Configuration::get('PS_LANG_DEFAULT') :
            (int)$this->context->cookie->id_lang;
        parent::__construct();
    }

    public function renderList()
    {
        if (Tools::isSubmit('submitMappingSave')) {
            $this->saveMapping();
        }
        if (Tools::getIsset('created') && Tools::getValue('created')) {
            $this->confirmations[] = "Category Mapping created successfully";
        }
        if (Tools::getIsset('updated') && Tools::getValue('updated')) {
            $this->confirmations[] = "Category Mapping updated successfully";
        }

        // Delete All Categories mapping
        if (Tools::getIsset('method') && 
            (trim(Tools::getValue('method'))) == 'deleteAllCategoryMapping'
        ) {
            $result = $this->CedEtsyCategory->deleteAllCategoryMapping();
            if(isset($result) && !empty($result)){
                $this->confirmations[] = 'Category Mapping deleted successfully';
            } else {
                $this->errors[] = 'Error while deleting Category Mapping';
            }
        }

        // Delete Single Category mapping
        if (Tools::getIsset('method') && 
            (trim(Tools::getValue('method'))) == 'deleteCategoryMapping'
        ) {
            $id = Tools::getValue('mapping_id');
            $res = $this->CedEtsyCategory->deleteMapping($id);
            if ($res) {
                $this->confirmations[] = "Mapping ".$id." deleted successfully";
            } else {
                $this->errors[] = "Failed to delete Mapping ".$id;
            }
        }

        if (Tools::isSubmit('submitMapOptions')) 
        {
            $res = $this->saveMappedOptions();
            if($res)
            {
                $this->confirmations[] = 'Options mapped successfully!';
            } else {
                $this->errors[] = 'Error while mapping options';
            }
        }

        if (Tools::isSubmit('submitAttributeMapping')) 
        {
            $res = $this->saveMappedAttributes();
            if($res)
            {
                $this->confirmations[] = 'Attributes mapped successfully!';
            } else {
                $this->errors[] = 'Error while mapping attributes';
            }
        }

        if(Tools::getIsset('method') && (Tools::getValue('method') == 'renderEditCatMapping'))
        {
            $etsyCategory = array();
            $storeCategory = array();
            $defaultAttributes = array();
            $attributes = array();
            $shippingTemplate = array();
            $shopSection = array();
            $idMapping = '';

            $etsyCategory = $this->CedEtsyCategory->fetchEtsyCategory();
            $defaultAttributes = $this->CedEtsyHelper->getDefaultFormFields();
            $shippingTemplate = $this->CedEtsyShippingTemplate->getAllShippingTemplates();
            $shopSection = $this->CedEtsyHelper->getAllShopSections();

            $attributes = $this->CedEtsyCategory->attributes();

            $idMapping = Tools::getValue('mapping_id');

            if (!empty($idMapping)) 
            {
                $mappingData = $this->CedEtsyCategory->getMappingDataById($idMapping);
                // echo '<pre>'; print_r($mappingData); die;
                $etsy_category = $mappingData['etsy_category'];
                $storeCategory = $mappingData['store_category'];
                $mapped_fields = $mappingData['mapped_fields'];
                $default_values = $mappingData['default_values'];
                $extrs = $mappingData['extrs'];

                $this->context->smarty->assign(array(
                    'etsy_category' => $etsy_category,
                    'mapped_fields' => $mapped_fields,
                    'mapped_default_values' => $default_values,
                    'extrs' => $extrs
                ));
            }

            $this->context->smarty->assign(array('mappingId' => $idMapping));

            if (method_exists($this->context->controller, 'addJS')) {
                $this->context->controller->addJS(Context::getContext()->shop->getBaseURL(true) . 'modules/cedetsy/views/js/mock.js');
            }

            if (method_exists($this->context->controller, 'addCSS')) {
                $this->context->controller->addCSS(Context::getContext()->shop->getBaseURL(true) . 'modules/cedetsy/views/css/jquery.dropdown.min.css');
            }

            if (method_exists($this->context->controller, 'addJS')) {
                $this->context->controller->addJS(Context::getContext()->shop->getBaseURL(true) . 'modules/cedetsy/views/js/jquery.dropdown.js');
            }

             $this->context->smarty->assign(array(
                'controllerUrl' => $this->context->link->getAdminLink('AdminCedEtsyCatMapping'),
                'cat_token' => $this->token, //Tools::getAdminTokenLite('AdminCedEtsyCatMapping')
                'etsy_category_list' => $etsyCategory,
                'default_attribute_list' => $defaultAttributes,
                'attribute_list' => $attributes,
                'shipping_template_list' => $shippingTemplate,
                'shop_section_list' => $shopSection
            ));

            if (version_compare(_PS_VERSION_, '1.6.0', '>=') === true) {
                $tree_categories_helper = new HelperTreeCategories('categories-treeview');
                $tree_categories_helper->setRootCategory((Shop::getContext() == Shop::CONTEXT_SHOP ?
                    Category::getRootCategory()->id_category : 0))
                    ->setUseCheckBox(true);
            } else {
                if (Shop::getContext() == Shop::CONTEXT_SHOP) {
                    $root_category = Category::getRootCategory();
                    $root_category = array(
                        'id_category' => $root_category->id_category,
                        'name' => $root_category->name);
                } else {
                    $root_category = array('id_category' => '0', 'name' => $this->l('Root'));
                }
                $tree_categories_helper = new Helper();
            }
            if (version_compare(_PS_VERSION_, '1.6.0', '>=') === true) {
                $tree_categories_helper->setUseSearch(true);
                $tree_categories_helper->setSelectedCategories($storeCategory);
                $this->context->smarty->assign(array(
                    'storeCategories' => $tree_categories_helper->render()));
            } else {
                $this->context->smarty->assign(array(
                    'storeCategories' => $tree_categories_helper->renderCategoryTree(
                        $root_category,
                        $storeCategory,
                        'categoryBox'
                    )
                ));
            }
            $categoryMappingTemplate = $this->context->smarty->fetch(
                _PS_MODULE_DIR_ . 'cedetsy/views/templates/admin/category/category_mapping_form.tpl'
            );
            return $categoryMappingTemplate;

        } elseif (Tools::getIsset('method') && (Tools::getValue('method') == 'renderMapOptions')) 
        {
            $mappedId = Tools::getValue('mapping_id');
            
            $properties = array();
            $systemAttributes = array();
            $systemOptions = array();
            $productFields = array();
            try
            {
                if($mappedId)
                {
                    $mappingData = $this->CedEtsyCategory->getOptionsMapping($mappedId);
                
                    if (isset($mappingData['properties']) && $mappingData['properties']) {
                        $properties = Tools::jsonDecode($mappingData['properties'], true);
                    }
                    $options = array();
                    if (isset($mappingData['options']) && $mappingData['options']) {
                        $options = Tools::jsonDecode($mappingData['options'], true);
                    }

                    if (isset($mappingData['qualifiers']) && $mappingData['qualifiers']) 
                    {
                        $qualifiers = Tools::jsonDecode($mappingData['qualifiers'], true);

                        foreach ($qualifiers as $key => $qualifier) {
                            $option_list = array();
                            foreach ($qualifier[0]['options'] as $value) {
                                $option_list[$value] = $options[$value];
                            }
                            $qualifiers[$key][0]['options'] = $option_list;
                        }
                        $qualifiers_list = $qualifiers;
                    }
                    $mapped_options = $this->CedEtsyCategory->getPropertiesMapping($mappedId);

                    $systemOptions = $this->CedEtsyCategory->storeOptions();
                    $systemAttributes = Feature::getFeatures($this->lang,true);

                    $columns = $this->db->ExecuteS("SHOW COLUMNS FROM `"._DB_PREFIX_."product`;");
                    if(isset($columns) && count($columns)) {
                        $productFields = $columns;
                    }
                    $this->array_sort_by_column($productFields, 'Field');
                    
                    if (method_exists($this->context->controller, 'addJS')) {
                        $this->context->controller->addJS(Context::getContext()->shop->getBaseURL(true) . 'modules/cedetsy/views/js/mock.js');
                    }

                    if (method_exists($this->context->controller, 'addCSS')) {
                        $this->context->controller->addCSS(Context::getContext()->shop->getBaseURL(true) . 'modules/cedetsy/views/css/jquery.dropdown.min.css');
                    }
                    if (method_exists($this->context->controller, 'addJS')) {
                        $this->context->controller->addJS(Context::getContext()->shop->getBaseURL(true) . 'modules/cedetsy/views/js/jquery.dropdown.js');
                    }

                    $this->context->smarty->assign(array(
                        'controllerUrl' => $this->context->link->getAdminLink('AdminCedEtsyCatMapping'),
                        'opt_token' => $this->token,
                        'mappedId' => $mappedId,
                        'properties' => $properties,
                        'qualifiers' => $qualifiers_list,
                        'mapped_options' => $mapped_options,
                        'product_option_query' => $systemOptions,
                        'product_fields' => $productFields,
                        'product_attributes' => $systemAttributes,
                    ));
                    
                }
            } catch(Exception $e) {
                echo $e->getMessage();die;
            }

            $map_options_template = $this->context->smarty->fetch(
                _PS_MODULE_DIR_ .'cedetsy/views/templates/admin/category/map_options.tpl'
            );
            return $map_options_template;

        } elseif( Tools::getIsset('method') && (Tools::getValue('method') == 'renderMapAttributes'))
        {
            $mappedId = Tools::getValue('mapping_id');
            
            $properties = array();
            $systemAttributes = array();
            $systemOptions = array();
            $productFields = array();
            try
            {
                if($mappedId)
                {
                    $mappingData = $this->CedEtsyCategory->getCategoryNodesProperty($mappedId);
                    $category_id = $mappingData['category_id'];
                    $taxonomy_id = $mappingData['taxonomy_id'];
                    // echo '<pre>'; print_r($mappingData); die;
                    // $properties = array();
                    // $scales = array();
                    // $possible_values = array();
                    // if (is_array($mappingData) && $mappingData) 
                    // {
                    //     foreach($mappingData as $key => $mapped_data)
                    //     {
                    //         // Properties
                    //         $properties[$key]['property_id'] = $mapped_data['property_id'];
                    //         $properties[$key]['name'] = $mapped_data['name'];

                    //         // Scales
                    //         if(isset($mapped_data['scales']) && !empty($mapped_data['scales']))
                    //         {
                    //             $scale_lists = Tools::jsonDecode($mapped_data['scales'], true);
                                
                    //             foreach($scale_lists as $scaleKey => $scale_list)
                    //             {
                    //                 $scales[$scaleKey]['scale_id'] = $scale_list['scale_id'];
                    //                 $scales[$scaleKey]['name'] = $scale_list['display_name'];
                    //             } 
                    //         }

                    //         // Possible Values
                    //         if(isset($mapped_data['possible_values']) && !empty($mapped_data['possible_values']))
                    //         {
                    //             $possible_value_lists = Tools::jsonDecode($mapped_data['possible_values'], true);
                                
                    //             foreach($possible_value_lists as $possibleKey => $possible_value_list)
                    //             {
                    //                 $possible_values[$possibleKey]['value_id'] = $possible_value_list['value_id'];
                    //                 $possible_values[$possibleKey]['name'] = $possible_value_list['name'];
                    //             } 
                    //         }
                    //     }
                    // }
                    //echo '<pre>'; print_r($possible_values); die;
                    //$options = array();
                    // if (isset($mappingData['options']) && $mappingData['options']) {
                    //     $options = Tools::jsonDecode($mappingData['options'], true);
                    // }

                    // if (isset($mappingData['qualifiers']) && $mappingData['qualifiers']) 
                    // {
                    //     $qualifiers = Tools::jsonDecode($mappingData['qualifiers'], true);

                    //     foreach ($qualifiers as $key => $qualifier) {
                    //         $option_list = array();
                    //         foreach ($qualifier[0]['options'] as $value) {
                    //             $option_list[$value] = $options[$value];
                    //         }
                    //         $qualifiers[$key][0]['options'] = $option_list;
                    //     }
                    //     $qualifiers_list = $qualifiers;
                    // }
                    // $mapped_options = $this->CedEtsyCategory->getPropertiesMapping($mappedId);

                    // $systemOptions = $this->CedEtsyCategory->storeOptions();
                    // $systemAttributes = Feature::getFeatures($this->lang,true);

                    // $columns = $this->db->ExecuteS("SHOW COLUMNS FROM `"._DB_PREFIX_."product`;");
                    // if(isset($columns) && count($columns)) {
                    //     $productFields = $columns;
                    // }
                    // $this->array_sort_by_column($productFields, 'Field');
                    
                    // if (method_exists($this->context->controller, 'addJS')) {
                    //     $this->context->controller->addJS(Context::getContext()->shop->getBaseURL(true) . 'modules/cedetsy/views/js/mock.js');
                    // }

                    // if (method_exists($this->context->controller, 'addCSS')) {
                    //     $this->context->controller->addCSS(Context::getContext()->shop->getBaseURL(true) . 'modules/cedetsy/views/css/jquery.dropdown.min.css');
                    // }
                    // if (method_exists($this->context->controller, 'addJS')) {
                    //     $this->context->controller->addJS(Context::getContext()->shop->getBaseURL(true) . 'modules/cedetsy/views/js/jquery.dropdown.js');
                    // }

                    $this->context->smarty->assign(array(
                        'controllerUrl' => $this->context->link->getAdminLink('AdminCedEtsyCatMapping'),
                        'opt_token' => $this->token,
                        'mappedId' => $mappedId,
                        'category_id' => $category_id,
                        'taxonomy_id' => $taxonomy_id,
                        //'properties' => $properties,
                        //'qualifiers' => $qualifiers_list,
                        //'mapped_options' => $mapped_options,
                        //'product_option_query' => $systemOptions,
                        //'product_fields' => $productFields,
                        //'product_attributes' => $systemAttributes,
                    ));
                    
                }
            } catch(Exception $e) {
                echo $e->getMessage();die;
            }

            $map_attributes_template = $this->context->smarty->fetch(
                _PS_MODULE_DIR_ .'cedetsy/views/templates/admin/category/map_attributes.tpl'
            );
            return $map_attributes_template;

        } else {
            $category_mapping_data = $this->db->ExecuteS("SELECT * FROM `". _DB_PREFIX_."cedetsy_category_mapping` ");
            
            $category_mapping_list = array();
            if(isset($category_mapping_data) && !empty($category_mapping_data))
            {
                foreach($category_mapping_data as $key => $category_mapping)
                {
                    if(isset($category_mapping['id']) && $category_mapping['id'])
                    {
                        $mappedId = $category_mapping['id'];
                    }

                    if(isset($category_mapping['etsy_category']) && $category_mapping['etsy_category'])
                    {
                        $etsyCatMapping = Tools::jsonDecode($category_mapping['etsy_category'], true);
                        $etsy_category = $this->CedEtsyCategory->getEtsyCategoryName($etsyCatMapping);

                    }

                    if(isset($category_mapping['store_category']) && $category_mapping['store_category'])
                    {
                        $store_category_id = Tools::jsonDecode($category_mapping['store_category'], true);
                        $store_category = $this->CedEtsyCategory->getStoreCategoryName($store_category_id, (int)$this->lang);

                    }

                    if (method_exists($this->context->controller, 'addCSS')) {
                        $this->context->controller->addCSS(Context::getContext()->shop->getBaseURL(true) . 'modules/cedetsy/views/css/font-awesome.min.css');
                    }

                    $mapped_option_action = $this->context->link->getAdminLink('AdminCedEtsyCatMapping') . '&method=renderMapOptions' . '&mapping_id=' . $mappedId;

                    $mapped_attribute_action = $this->context->link->getAdminLink('AdminCedEtsyCatMapping') . '&method=renderMapAttributes' . '&mapping_id=' . $mappedId;

                    $edit_cat_mapping = $this->context->link->getAdminLink('AdminCedEtsyCatMapping') . '&method=renderEditCatMapping' . '&mapping_id=' . $mappedId;

                    
                    $delete_action = $this->context->link->getAdminLink('AdminCedEtsyCatMapping') . '&method=deleteCategoryMapping' . '&mapping_id=' . $mappedId;

                    $category_mapping_list[] = array(
                        'mappedId' => $mappedId,
                        'etsy_category' => $etsy_category,
                        'store_category' => $store_category,
                        'mapped_option_action' => $mapped_option_action,
                        'mapped_attribute_action' => $mapped_attribute_action,
                        'edit_action' => $edit_cat_mapping,
                        'delete_action' => $delete_action
                        );
               
                }
            }
            // echo '<pre>'; print_r($category_mapping_list); die;
            $this->context->smarty->assign(array('token' => $this->token));
            $this->context->smarty->assign(array('mappings' => $category_mapping_list));

            $category_mapping_list_template = $this->context->smarty->fetch(
                _PS_MODULE_DIR_ . 'cedetsy/views/templates/admin/category/category_mapping_list.tpl'
            );

            return $category_mapping_list_template;
        }
    }

    public function array_sort_by_column(&$arr, $col, $dir = SORT_ASC) 
    {
        $sort_col = array();
        foreach ($arr as $key=> $row) {
            $sort_col[$key] = $row[$col];
        }
        array_multisort($sort_col, $dir, $arr);
    }

    public function initPageHeaderToolbar()
    {
        if (empty($this->display)) 
        {
            $this->page_header_toolbar_btn['add_category_mapping'] = array(
                'href' => self::$currentIndex . '&method=renderEditCatMapping&addcedetsy_category_mapping&token=' . $this->token,
                'desc' => $this->l('Add New Mapping', null, null, false),
                'icon' => 'process-icon-new'
            );

            $this->page_header_toolbar_btn['delete_category_mapping'] = array(
                'href' => self::$currentIndex . '&method=deleteAllCategoryMapping&token=' . $this->token,
                'desc' => $this->l('Delete All Mapping', null, null, false),
                'icon' => 'process-icon-delete'
            );
        } elseif ($this->display == 'edit' || $this->display == 'add') {
            $this->page_header_toolbar_btn['backtolist'] = array(
                'href' => self::$currentIndex . '&token=' . $this->token,
                'desc' => $this->l('Back To List', null, null, false),
                'icon' => 'process-icon-back'
            );
        }
        parent::initPageHeaderToolbar();
    }

    public function saveMappedAttributes()
    {
        $mapped_attribute_data = Tools::getAllValues();
        echo '<pre>'; print_r($mapped_attribute_data); die;
    }

    public function saveMappedOptions()
    {
        $mapped_options_data = Tools::getAllValues();
        // echo '<pre>'; print_r($mapped_options_data); die;
        if(isset($mapped_options_data['etsy_property']) && $mapped_options_data['etsy_property'])
        {
            $this->db->delete(
            'cedetsy_option_mapping',
            'mapping_id=' . (int) $mapped_options_data['mapping_id']
            );
            foreach ($mapped_options_data['etsy_property'] as $key => $value) 
            {
                $res = $this->db->insert(
                    'cedetsy_option_mapping',
                    array(
                        'option_id' => pSQL($value['option_id']),
                        'property_id' => (int) $value['property_id'],
                        'mapping_id' => (int) $mapped_options_data['mapping_id'],
                        'scale' => (isset($value['scale'])) ? pSQL($value['scale']) : ''
                    )
                );
            }
            if($res)
            {
                return true;
            } else {
                return false;
            }
        }
    }

    // public function renderForm()
    // {
    //     $etsyCategory = array();
    //     $storeCategory = array();
    //     $defaultAttributes = array();
    //     $attributes = array();
    //     $shippingTemplate = array();
    //     $shopSection = array();
    //     $idMapping = '';

    //     $etsyCategory = $this->CedEtsyCategory->fetchEtsyCategory();
    //     $defaultAttributes = $this->CedEtsyHelper->getDefaultFormFields();
    //     $shippingTemplate = $this->CedEtsyShippingTemplate->getAllShippingTemplates();
    //     $shopSection = $this->CedEtsyHelper->getAllShopSections();

    //     $attributes = $this->CedEtsyCategory->attributes();

    //     // $map_option_attribute = $this->getAttributesByCategory();

    //     $idMapping = Tools::getValue('id');

    //     if (!empty($idMapping)) 
    //     {
    //         $mappingData = $this->CedEtsyCategory->getMappingDataById($idMapping);
    //         // echo '<pre>'; print_r($mappingData); die;
    //         $etsy_category = $mappingData['etsy_category'];
    //         $storeCategory = $mappingData['store_category'];
    //         $mapped_fields = $mappingData['mapped_fields'];
    //         $default_values = $mappingData['default_values'];
    //         $extrs = $mappingData['extrs'];

    //         $this->context->smarty->assign(array(
    //             'etsy_category' => $etsy_category,
    //             'mapped_fields' => $mapped_fields,
    //             'mapped_default_values' => $default_values,
    //             'extrs' => $extrs
    //         ));
    //     }

    //     $this->context->smarty->assign(array('mappingId' => $idMapping));

    //     if (method_exists($this->context->controller, 'addJS')) {
    //         $this->context->controller->addJS(Context::getContext()->shop->getBaseURL(true) . 'modules/cedetsy/views/js/mock.js');
    //     }

    //     if (method_exists($this->context->controller, 'addCSS')) {
    //         $this->context->controller->addCSS(Context::getContext()->shop->getBaseURL(true) . 'modules/cedetsy/views/css/jquery.dropdown.min.css');
    //     }
    //     if (method_exists($this->context->controller, 'addJS')) {
    //         $this->context->controller->addJS(Context::getContext()->shop->getBaseURL(true) . 'modules/cedetsy/views/js/jquery.dropdown.js');
    //     }

    //      $this->context->smarty->assign(array(
    //         'controllerUrl' => $this->context->link->getAdminLink('AdminCedEtsyCatMapping'),
    //         'cat_token' => $this->token, //Tools::getAdminTokenLite('AdminCedEtsyCatMapping')
    //         'etsy_category_list' => $etsyCategory,
    //         'default_attribute_list' => $defaultAttributes,
    //         'attribute_list' => $attributes,
    //         'shipping_template_list' => $shippingTemplate,
    //         'shop_section_list' => $shopSection
    //     ));


    //     if (version_compare(_PS_VERSION_, '1.6.0', '>=') === true) {
    //         $tree_categories_helper = new HelperTreeCategories('categories-treeview');
    //         $tree_categories_helper->setRootCategory((Shop::getContext() == Shop::CONTEXT_SHOP ?
    //             Category::getRootCategory()->id_category : 0))
    //             ->setUseCheckBox(true);
    //     } else {
    //         if (Shop::getContext() == Shop::CONTEXT_SHOP) {
    //             $root_category = Category::getRootCategory();
    //             $root_category = array(
    //                 'id_category' => $root_category->id_category,
    //                 'name' => $root_category->name);
    //         } else {
    //             $root_category = array('id_category' => '0', 'name' => $this->l('Root'));
    //         }
    //         $tree_categories_helper = new Helper();
    //     }
    //     if (version_compare(_PS_VERSION_, '1.6.0', '>=') === true) {
    //         $tree_categories_helper->setUseSearch(true);
    //         $tree_categories_helper->setSelectedCategories($storeCategory);
    //         $this->context->smarty->assign(array(
    //             'storeCategories' => $tree_categories_helper->render()));
    //     } else {
    //         $this->context->smarty->assign(array(
    //             'storeCategories' => $tree_categories_helper->renderCategoryTree(
    //                 $root_category,
    //                 $storeCategory,
    //                 'categoryBox'
    //             )
    //         ));
    //     }
    //     $categoryMappingTemplate = $this->context->smarty->fetch(
    //         _PS_MODULE_DIR_ . 'cedetsy/views/templates/admin/category/category_mapping_form.tpl'
    //     );
    //     parent::renderForm();
    //     return $categoryMappingTemplate;
    // }

    public function saveMapping()
    {
        $db = Db::getInstance();
        $etsyCategory = Tools::getValue('etsy_category');
        $storeCategory = Tools::getValue('categoryBox');
        $mapped_fields = Tools::getValue('mapped_fields');
        $default_values = Tools::getValue('default_values');
        $extrs = Tools::getValue('extrs');
        $mappingId = Tools::getValue('mapping_id');
       // echo '<pre>'; print_r(Tools::getAllValues()); die;
       
        try {
            if (!empty($mappingId)) {
                $res = $db->update(
                    'cedetsy_category_mapping',
                    array(
                       'etsy_category' => pSQL(Tools::jsonEncode($etsyCategory)),
                       'store_category' => pSQL(Tools::jsonEncode($storeCategory)),
                       'mapped_fields' => pSQL(Tools::jsonEncode($mapped_fields)),
                       'default_values' => pSQL(Tools::jsonEncode($default_values)),
                       'extrs' => pSQL(Tools::jsonEncode($extrs))
                    ),
                    'id=' . (int)$mappingId
                );
                $this->CedEtsyCategory->getAllPropertySets($etsyCategory, $mappingId);
                $this->CedEtsyCategory->getAllPropertyNodes($etsyCategory, $mappingId);
                if ($res) {
                    $link = new LinkCore();
                    $controller_link = $link->getAdminLink('AdminCedEtsyCatMapping').'&updated=1';
                    Tools::redirectAdmin($controller_link);
                    $this->confirmations[] = "Category mapping updated successfully";
                }
            } else {
                    $res = $db->insert(
                        'cedetsy_category_mapping',
                        array(
                           'etsy_category' => pSQL(Tools::jsonEncode($etsyCategory)),
                       'store_category' => pSQL(Tools::jsonEncode($storeCategory)),
                       'mapped_fields' => pSQL(Tools::jsonEncode($mapped_fields)),
                       'default_values' => pSQL(Tools::jsonEncode($default_values)),
                       'extrs' => pSQL(Tools::jsonEncode($extrs))
                        )
                    );
                    $newMappingId = $db->Insert_ID();
                    if ($res && $newMappingId) {
                        $link = new LinkCore();
                        $controller_link = $link->getAdminLink('AdminCedEtsyCatMapping').'&created=1';
                        Tools::redirectAdmin($controller_link);
                        $this->confirmations[] = "Category mapping created successfully";
                    }
            }
        } catch (\Exception $e) {
            $this->errors[] = $e->getMessage();
        }
    }

    public function ajaxProcessGetEtsyCategory()
    {
        $json = array();
        $post_data = Tools::getAllValues();
        
        $category_id = isset($post_data['category_id']) ? $post_data['category_id'] : '';
        $children_id = isset($post_data['children_id']) ? $post_data['children_id'] : '';
        $mapping_id = isset($post_data['mapping_id']) ? $post_data['mapping_id'] : '';
        
        $mapping_info = $this->CedEtsyCategory->getMappingDataById($mapping_id);
        
        $etsy_category = array();
        if (isset($mapping_info['etsy_category']) && $mapping_info['etsy_category']) {
            $etsy_category = $mapping_info['etsy_category'];
        }

        $level = isset($post_data['level']) ? $post_data['level'] : '';
        
        $etsy_categories = $this->CedEtsyCategory->getEtsyCategoryByLevelParent($level, $category_id);

        if (isset($etsy_categories) && count($etsy_categories)) {
            $categoryHtml = '<option></option>';
            foreach ($etsy_categories as $category) {
                if (isset($etsy_category["select-level-" . $level]) && $etsy_category["select-level-" . $level] && (trim($etsy_category["select-level-" . $level]) == trim($category['children_id']))) {
                    $categoryHtml .= '<option selected="selected" value="' . $category['children_id'] . '" children_id="' . $category['category_id'] . '">' . $category['name'] . '</option>';
                } else {
                    $categoryHtml .= '<option value="' . $category['children_id'] . '" children_id="' . $category['category_id'] . '">' . $category['name'] . '</option>';
                }
            }
            $json = $categoryHtml;
        } else {
            $json = 'Unable to fetch category';
        }
        die(Tools::jsonEncode($json));
    }

    // public function ajaxProcessGetSelectedProperty()
    // {
    //     $properties = array();
    //     $scales = array();
    //     $mapping_info = $this->CedEtsyCategory->getOptionsMapping(Tools::getValue('mapping_id'));
    //     if (isset($mapping_info['properties']) && $mapping_info['properties']) {
    //         $properties = Tools::jsonDecode($mapping_info['properties'], true);
    //         if (isset($properties[Tools::getValue('property_id')])) {
    //             $properties = $properties[Tools::getValue('property_id')];
    //             if (isset($mapping_info['qualifiers']) && $mapping_info['qualifiers']) {
    //                 $qualifiers = Tools::jsonDecode($mapping_info['qualifiers'], true);
    //                 if (isset($qualifiers[Tools::getValue('property_id')])) {
    //                     $qualifiers = $qualifiers[Tools::getValue('property_id')];

    //                     if (isset($mapping_info['options']) && $mapping_info['options']) {
    //                         $options = Tools::jsonDecode($mapping_info['options'], true);
    //                         $option_list = array();
    //                         foreach ($qualifiers[0]['options'] as $key => $value) {
    //                             $option_list[$value] = $options[$value];
    //                         }
    //                         $qualifiers[0]['options'] = $option_list;
    //                     }
    //                 } else {
    //                     $qualifiers = array();
    //                 }
    //             }
    //         } else {
    //             $properties = array();
    //         }
    //     }
    //     if (isset($qualifiers['0']) && !empty($qualifiers['0']))
    //         $properties['scale'] = $qualifiers['0'];

    //     if (isset($properties['property_id'])) {
           
    //         die(Tools::jsonEncode(array('success' => true, 'message' => $properties)));
    //     } else {
    //         die(Tools::jsonEncode(array('success' => false)));
    //     }

    // }

    public function ajaxProcessAttributesByCategory()
    {
        $db = Db::getInstance();
        $mappedId = Tools::getValue('mapping_id');
        $category_id = Tools::getIsset('category_id')?Tools::getValue('category_id'):0;
        $taxonomy_id = Tools::getIsset('taxonomy_id')?Tools::getValue('taxonomy_id'):0;
        
        $html ='No Attribute Found , Please checkCategory.';
        if ($category_id) 
        {
            ini_set('memory_limit','512M');
           
            $attributes_options = $this->CedEtsyCategory->getAttributesByCategory($category_id, $taxonomy_id);
         
            $mapped_attributes_options = array();
            if($mappedId) 
            {
                $mapped_attributes_options = $this->CedEtsyCategory->getPropertiesMapping($mappedId);
            }
            
            $results = Feature::getFeatures($this->lang,true);
            $store_options = $this->CedEtsyCategory->storeOptions();
            $options = $store_options['options'];
            $attributes = $this->CedEtsyCategory->getAttributesByCategory($category_id, $taxonomy_id);

            $html ='';
            $required = array();

            foreach ($attributes as $attribute) 
            {
                $key   = $attribute['property_id'];
                $html .= '<tr>';
                $html .= '<td class="col-sm-12 col-md-3 col-lg-3 left">';
                if(isset($attribute['is_required']) && $attribute['is_required']){
                    $required[] = $attribute['property_id'];
                    $html .= '<span class="required">*</span>';
                    $html .= '<input type="hidden" name="etsy_category['.$key.'][is_required]" value="1"/>';
                } else {
                    $html .= '<input type="hidden" name="etsy_category['.$key.'][is_required]" value="0"/>';
                }
                $html .= '<input type="hidden" name="etsy_category['.$key.'][supports_attributes]" value="'.$attribute['supports_attributes'].'"/>';
                $html .= '<input type="hidden" name="etsy_category['.$key.'][supports_variations]" value="'.$attribute['supports_variations'].'"/>';
                $html .= '<input type="hidden" name="etsy_category['.$key.'][is_multivalued]" value="'.$attribute['is_multivalued'].'"/>';
                $html .= '<select name="etsy_category['.$key.'][etsy_attribute]" class="col-sm-12 col-md-8 col-lg-8">';

                $mapped_options = false;
                $store_selected_option = false;
                $default_values_selected = false;
                $default_values_id_selected = false;
                $etsy_selected_option = false;
                $etsy_selected_scale = false;
                if(isset($mapped_attributes_options[$attribute['property_id']]) && isset($mapped_attributes_options[$attribute['property_id']]['option']) && isset($mapped_attributes_options[$attribute['property_id']]['option'])) {
                    $mapped_options = $mapped_attributes_options[$attribute['property_id']]['option'];

                    if(is_array($mapped_options) && !empty($mapped_options)) {
                        $mapped_options = array_filter($mapped_options);
                        $mapped_options = array_values($mapped_options);
                    }
                    
                    if(isset($mapped_attributes_options[$attribute['property_id']]['store_attribute']) && $mapped_attributes_options[$attribute['property_id']]['store_attribute'])
                        $store_selected_option = $mapped_attributes_options[$attribute['property_id']]['store_attribute'];

                    if($mapped_attributes_options[$attribute['property_id']]['etsy_attribute'])
                        $etsy_selected_option = $mapped_attributes_options[$attribute['property_id']]['etsy_attribute'];

                    if($mapped_attributes_options[$attribute['property_id']]['default_values'])
                        $default_values_selected = $mapped_attributes_options[$attribute['property_id']]['default_values'];

                    if($mapped_attributes_options[$attribute['property_id']]['default_value_id'])
                        $default_values_id_selected = $mapped_attributes_options[$attribute['property_id']]['default_value_id'];

                    if($mapped_attributes_options[$attribute['property_id']]['scale'])
                        $etsy_selected_scale = $mapped_attributes_options[$attribute['property_id']]['scale'];
                }

                //$scale_options = '';
                if(!$attribute['is_required'])
                $html .= '<option value=""></option>';
                foreach ($attributes_options as $attriKey => $attribute_option) 
                {
                    if($etsy_selected_option && ($attribute_option['property_id']==$etsy_selected_option)) {
                        $html .= '<option selected="selected" value="'.$attribute_option['property_id'].'">';
                        $html .= $attribute_option['display_name'];
                        $html .= '</option>';
                    } else if($attribute['is_required'] && ($attribute_option['property_id']==$attribute['property_id'])){
                        $html .= '<option selected="selected" value="'.$attribute_option['property_id'].'">';
                        $html .= $attribute_option['display_name'];
                        $html .= '</option>';
                    } else if($attribute_option['property_id']==$attribute['property_id']){
                        $html .= '<option selected="selected" value="'.$attribute_option['property_id'].'">';
                        $html .= $attribute_option['display_name'];
                        $html .= '</option>';
                    } else {
                        $html .= '<option value="'.$attribute_option['property_id'].'">';
                        $html .= $attribute_option['display_name'];
                        $html .= '</option>';
                    }
                }
                $html .= '</select>';
                //$html .= '</td>';
                //$html .= '<td class="col-sm-12 col-md-3 col-lg-3 left">';
                $attribute['scales'] = Tools::jsonDecode($attribute['scales'], true);
                //echo '<pre>'; print_r($attribute['scales']); 
                if(isset($attribute['scales']) && is_array($attribute['scales']) && !empty($attribute['scales']))
                {
                    $html .= '<select name="etsy_category['.$key.'][scale]" class="col-sm-12 col-md-8 col-lg-8">';
                    //$html .= '<option value=""></option>';
                    foreach($attributes_options as $attriKey => $attribute_option)
                    {
                        if(isset($attribute_option['scales']) && !empty($attribute_option['scales']))
                        {
                            if($attribute_option['property_id'] == $key)
                            {
                                $attribute_option['scales'] = Tools::jsonDecode($attribute_option['scales'], true);
                                foreach($attribute_option['scales'] as $scaleKey => $scales)
                                {
                                    if($etsy_selected_scale && ($scales['scale_id']==$etsy_selected_scale))
                                    {
                                        $html .= '<option selected="selected" value="'.$scales['scale_id'].'">';
                                        $html .= $scales['display_name'];
                                        $html .= '</option>';
                                    } else {
                                        $html .= '<option value="'.$scales['scale_id'].'">';
                                        $html .= $scales['display_name'];
                                        $html .= '</option>';
                                    }

                                }
                            }
                        }
                    }
                    //$html .= $scale_options;
                    $html .= '</select>';
                }
                
                $html .= '</td>';
                $html .= '<td>';
                if(!empty($attribute['possible_values']))
                {
                    $attribute['possible_values'] = Tools::jsonDecode($attribute['possible_values'], true);
                }
                
                $html .= '<input type="text" class="col-sm-12 col-md-8 col-lg-8 text-left" name="etsy_category['.$key.'][default_values]" onkeyup="getBrand(this)" data-id="'.$key.'" value ="'.$default_values_selected.'" >';
                $html .= '<input type="hidden" value="" class="text-left" name="etsy_category['.$key.'][default_value_id]" value ="'.$default_values_id_selected.'" >';
                $html .= '</td>';
                $html .= '<td class="col-sm-12 col-md-3 col-lg-3 left">';
                if (($attribute['is_multivalued'] == '1') && !empty($attribute['possible_values'])) 
                {
                    $html .= '<select id="etsy_category['.$key.'][store_attribute]" name="etsy_category['.$key.'][store_attribute]" class="col-sm-12 col-md-8 col-lg-8">';
                    $html .= '<option value="">Select Mapping</option>';
                    $html .= '<optgroup label="Store Option">';
                    foreach ($options as $option) {
                        if($store_selected_option && ('option-'.$option['id_attribute_group']==$store_selected_option)) {
                            $html .= '<option show_option_mapping="1" selected="selected" value="option-'.$option['id_attribute_group'].'">';
                            $html .= $option['name'];
                            $html .= '</option>';
                        } else {
                            $html .= '<option show_option_mapping="1" value="option-'.$option['id_attribute_group'].'">';
                            $html .= $option['name'];
                            $html .= '</option>';
                        }

                    }
                    $html .= '</optgroup>';
                    $html .= '<optgroup label="Store Attributes">';
                    foreach ($results as $result) {
                        if($store_selected_option && ('attribute-'.$result['id_feature']==$store_selected_option)) {
                            $html .= '<option show_option_mapping="0" selected="selected" value="attribute-'.$result['id_feature'].'">';
                            $html .= $result['name'];
                            $html .= '</option>';
                        } else {
                            $html .= '<option show_option_mapping="0" value="attribute-'.$result['id_feature'].'">';
                            $html .= $result['name'];
                            $html .= '</option>';
                        }
                    }
                    $html .= '</optgroup>';
                    $product_fields = array(); 
                    try{
                        $columns = $db->ExecuteS("SHOW COLUMNS FROM `"._DB_PREFIX_."product`;");
                        if(isset($columns) && count($columns)) {
                            $product_fields = $columns;
                        }
                        $this->array_sort_by_column($product_fields, 'Field');
                    }catch(Exception $e){
                        echo $e->getMessage();die;
                    }
                   
                    $html .= '<optgroup label="Product Fields">';
                    foreach ($product_fields as $result) {
                        $show_option_mapping = 0 ;
                        if(in_array($result['Field'],array('manufacturer_id')))
                            $show_option_mapping = 1 ;
                        if($store_selected_option && ('product-'.$result['Field']==$store_selected_option)) {
                            $html .= '<option show_option_mapping="'.$show_option_mapping.'" selected="selected" value="product-'.$result['Field'].'">';
                            $html .= ucfirst(str_replace('_', ' ', $result['Field']));
                            $html .= '</option>';
                        } else {
                            $html .= '<option show_option_mapping="'.$show_option_mapping.'" value="product-'.$result['Field'].'">';
                            $html .= ucfirst(str_replace('_', ' ', $result['Field']));
                            $html .= '</option>';
                        }
                    }
                    $html .= '</optgroup>';
                    $html .= '</select>';               
                    $option_html = '';
                    $option_html .= '<a style="margin-left:1%; text-weight:bold;" class="center button" onclick="toggleOptions(' . $key . ')"> Map Option(s) </a><div style="display:none;" id="panel' . $key . '">';
                    $option_html .= '<table class="table table-bordered" id="option_mapping' . $key . '">';
                    $option_html .= '<thead>';
                    $option_html .= '<tr>';
                    $option_html .= '<td class="col-sm-12 col-md-4 col-lg-4 center">';
                    $option_html .= '<strong>Store Option</strong>';
                    $option_html .= '</td>';
                    $option_html .= '<td class="col-sm-12 col-md-4 col-lg-4 center">';
                    $option_html .= '<strong>Etsy Option</strong>';
                    $option_html .= '</td>';
                    $option_html .= '</tr>';
                    $option_html .= '</thead>';
                    $option_html .= '<tr>';
                    $option_html .= '<td>';
                    $option_html .= '<input type="text" class="col-sm-12 col-md-8 col-lg-8 text-left" name="etsy_category['.$key.'][option][store_attribute]" value="" onkeyup="getStoreOptions(this)" data-id="'.$key.'"/>';
                    $option_html .= '<input type="hidden" class="text-left" name="etsy_category['.$key.'][option][store_attribute_id]"/>';
                    $option_html .= '</td>';
                    $option_html .= '<td>';
                    $option_html .= '<input type="text" class="col-sm-12 col-md-8 col-lg-8 text-left" name="etsy_category['.$key.'][option][etsy_attribute]" onkeyup="getOptions(this)" data-id="'.$key.'">';
                    $option_html .= '</td>';
                    $option_html .= '<td>';
                    $option_html .= '<button type="button" class="btn btn-primary pull-right" onclick="addAttribute(this,'.$key.');" >Add Mapping</button>';
                    $option_html .= '</td>';
                    $option_html .= '</tr>';
                    $option_html .= '</thead>';
                    if(!empty($mapped_options))
                    {
                        foreach ($mapped_options as $key_p => $value) {
                            $option_html .= '<tr id="attribute-row'.$key.$key_p.'">';
                            $option_html .= '<td>';
                            $option_html .= '<input type="text" class="col-sm-12 col-md-8 col-lg-8 text-left" name="etsy_category['.$key.'][option]['.$key_p.'][store_attribute]" value="'.$value['store_attribute'].'"/>';
                            $option_html .= '<input type="hidden" class="text-left" name="etsy_category['.$key.'][option]['.$key_p.'][store_attribute_id]" value="'.$value['store_attribute_id'].'"/>';
                            $option_html .= '</td>';
                            $option_html .= '<td>';
                            $option_html .= '<input type="text" class="col-sm-12 col-md-8 col-lg-8 text-left" name="etsy_category['.$key.'][option]['.$key_p.'][etsy_attribute]" value="'.$value['etsy_attribute'].'">';
                            $option_html .= '</td>';
                            $option_html .= '<td>';
                            $option_html .= '<a type="button" onclick="$(\'#attribute-row'.$key.$key_p.'\').remove();" class="btn btn-danger pull-right"> Remove</a>';
                            $option_html .= '</td>';
                            $option_html .= '</tr>';
                        } 
                    }
                    $option_html .= '</table>';
                    $option_html .= '</div>';
                    $html .= $option_html;
                } elseif(($attribute['is_multivalued'] == 0) && !empty($attribute['possible_values']))
                {
                    $html .= '<select id="etsy_category['.$key.'][store_attribute]" name="etsy_category['.$key.'][store_attribute]" class="col-sm-12 col-md-8 col-lg-8" onchange="getStoreOptionValue(this.value, '.$key.');">';
                    $html .= '<option value="">Select Mapping</option>';
                    $html .= '<optgroup label="Store Option">';
                    foreach ($options as $option) {
                        if($store_selected_option && ('option-'.$option['id_attribute_group']==$store_selected_option)) {
                            $html .= '<option show_option_mapping="1" selected="selected" value="option-'.$option['id_attribute_group'].'">';
                            $html .= $option['name'];
                            $html .= '</option>';
                        } else {
                            $html .= '<option show_option_mapping="1" value="option-'.$option['id_attribute_group'].'">';
                            $html .= $option['name'];
                            $html .= '</option>';
                        }

                    }
                    $html .= '</optgroup>';
                    $html .= '<optgroup label="Store Attributes">';
                    foreach ($results as $result) {
                        if($store_selected_option && ('attribute-'.$result['id_feature']==$store_selected_option)) {
                            $html .= '<option show_option_mapping="0" selected="selected" value="attribute-'.$result['id_feature'].'">';
                            $html .= $result['name'];
                            $html .= '</option>';
                        } else {
                            $html .= '<option show_option_mapping="0" value="attribute-'.$result['id_feature'].'">';
                            $html .= $result['name'];
                            $html .= '</option>';
                        }
                    }
                    $html .= '</optgroup>';
                    $product_fields = array(); 
                    try{
                        $columns = $db->ExecuteS("SHOW COLUMNS FROM `"._DB_PREFIX_."product`;");
                        if(isset($columns) && count($columns)) {
                            $product_fields = $columns;
                        }
                        $this->array_sort_by_column($product_fields, 'Field');
                    }catch(Exception $e){
                        echo $e->getMessage();die;
                    }
                   
                    $html .= '<optgroup label="Product Fields">';
                    foreach ($product_fields as $result) {
                        $show_option_mapping = 0 ;
                        if(in_array($result['Field'],array('manufacturer_id')))
                            $show_option_mapping = 1 ;
                        if($store_selected_option && ('product-'.$result['Field']==$store_selected_option)) {
                            $html .= '<option show_option_mapping="'.$show_option_mapping.'" selected="selected" value="product-'.$result['Field'].'">';
                            $html .= ucfirst(str_replace('_', ' ', $result['Field']));
                            $html .= '</option>';
                        } else {
                            $html .= '<option show_option_mapping="'.$show_option_mapping.'" value="product-'.$result['Field'].'">';
                            $html .= ucfirst(str_replace('_', ' ', $result['Field']));
                            $html .= '</option>';
                        }
                    }
                    $html .= '</optgroup>';
                    $html .= '</select>';               
                    $option_html = '';
                    $option_html .= '<a style="margin-left:1%; text-weight:bold;" class="center button" onclick="toggleOptions(' . $key . ')"> Map Option(s) </a><div style="display:none;" id="panel' . $key . '">';
                    $option_html .= '<table class="table table-bordered" id="option_mapping' . $key . '">';
                    $option_html .= '<thead>';
                    $option_html .= '<tr>';
                    $option_html .= '<td class="col-sm-12 col-md-4 col-lg-4 center">';
                    $option_html .= '<strong>Store Option</strong>';
                    $option_html .= '</td>';
                    $option_html .= '<td class="col-sm-12 col-md-4 col-lg-4 center">';
                    $option_html .= '<strong>Etsy Option</strong>';
                    $option_html .= '</td>';
                    $option_html .= '</tr>';
                    $option_html .= '</thead>';
                    $option_html .= '<tr>';
                    $option_html .= '<td id="select_store_attribute_'.$key.'">';
                    // $option_html .= '<input type="text" class="col-sm-12 col-md-8 col-lg-8 text-left" name="etsy_category['.$key.'][option][store_attribute]" value="" onkeyup="getStoreOptions(this)" data-id="'.$key.'"/>';

                    //$option_html .= '<select name="etsy_category['.$key.'][option][store_attribute]" data-id="'.$key.'" class="col-sm-12 col-md-8 col-lg-8 text-left">';

                    // foreach($store_options['option_values'][$option['id_attribute_group']] as $optValKey => $option_values)
                    // {
                    //     $option_html .= '<option value="'.$option_values['id_attribute'].'">';
                    //     $option_html .= $option_values['name'];
                    //     $option_html .= '</option>';
                        
                    // }
                    //$option_html .= '</select>';

                    $option_html .= '<input type="hidden" class="text-left" name="etsy_category['.$key.'][option][store_attribute_id]"/>';

                    $option_html .= '</td>';
                    $option_html .= '<td>';

                    // $option_html .= '<input type="text" class="col-sm-12 col-md-8 col-lg-8 text-left" name="etsy_category['.$key.'][option][etsy_attribute]" onkeyup="getOptions(this)" data-id="'.$key.'">';
                    $option_html .= '<select name="etsy_category['.$key.'][option][etsy_attribute]" data-id="'.$key.'" class="col-sm-12 col-md-8 col-lg-8 text-left">';
                    foreach($attribute['possible_values'] as $possibleKey => $possible_values)
                    {
                        $option_html .= '<option value="'.$possible_values['value_id'].'">';
                        $option_html .= $possible_values['name'];
                        $option_html .= '</option>';
                    }
                    $option_html .= '</select>';
                    $option_html .= '</td>';
                    //$option_html .= '<td>';

                    //$option_html .= '<button type="button" class="btn btn-primary pull-right" onclick="addAttribute(this,'.$key.');" >Add Mapping</button>';
                    //$option_html .= '</td>';
                    $option_html .= '</tr>';
                    $option_html .= '</thead>';
                    if(!empty($mapped_options))
                    {
                        foreach ($mapped_options as $key_p => $value) {
                            $option_html .= '<tr id="attribute-row'.$key.$key_p.'">';
                            $option_html .= '<td>';
                            // $option_html .= '<input type="text" class="col-sm-12 col-md-8 col-lg-8 text-left" name="etsy_category['.$key.'][option]['.$key_p.'][store_attribute]" value="'.$value['store_attribute'].'"/>';
                            $option_html .= '<select name="etsy_category['.$key.'][option]['.$key_p.'][store_attribute]" data-id="'.$key.'" class="col-sm-12 col-md-8 col-lg-8 text-left">';

                            foreach($store_options['option_values'][$option['id_attribute_group']] as $optValKey => $option_values)
                            {
                                if($value['store_attribute'] == $option_values['id_attribute'])
                                {
                                    $option_html .= '<option value="'.$option_values['id_attribute'].'" selected="selected">';
                                    $option_html .= $option_values['name'];
                                    $option_html .= '</option>';
                                } else {
                                    $option_html .= '<option value="'.$option_values['id_attribute'].'">';
                                    $option_html .= $option_values['name'];
                                    $option_html .= '</option>';
                                } 
                            }
                            $option_html .= '</select>';
                            $option_html .= '<input type="hidden" class="text-left" name="etsy_category['.$key.'][option]['.$key_p.'][store_attribute_id]" value="'.$value['store_attribute_id'].'"/>';
                            $option_html .= '</td>';
                            $option_html .= '<td>';
                            $option_html .= '<select name="etsy_category['.$key.'][option]['.$key_p.'][etsy_attribute]" data-id="'.$key.'" class="col-sm-12 col-md-8 col-lg-8 text-left">';
                            foreach($attribute['possible_values'] as $possibleKey => $possible_values)
                            {
                                if($value['etsy_attribute']==$possible_values['value_id'])
                                {
                                    $option_html .= '<option value="'.$possible_values['value_id'].'" selected="selected">';
                                    $option_html .= $possible_values['name'];
                                    $option_html .= '</option>';
                                } else {
                                    $option_html .= '<option value="'.$possible_values['value_id'].'">';
                                    $option_html .= $possible_values['name'];
                                    $option_html .= '</option>';
                                } 
                            }
                            $option_html .= '</select>';
                            // $option_html .= '<input type="text" class="col-sm-12 col-md-8 col-lg-8 text-left" name="etsy_category['.$key.'][option]['.$key_p.'][etsy_attribute]" value="'.$value['etsy_attribute'].'">';
                            $option_html .= '</td>';
                            // $option_html .= '<td>';
                            // $option_html .= '<a type="button" onclick="$(\'#attribute-row'.$key.$key_p.'\').remove();" class="btn btn-danger pull-right"> Remove</a>';
                            // $option_html .= '</td>';
                            $option_html .= '</tr>';
                        } 
                    }
                    $option_html .= '</table>';
                    $option_html .= '</div>';
                    $html .= $option_html;
                } else {
                    if (isset($mapped_attributes_options[$key]['store_attribute'])) {
                        $html .= '<input type="text" value="'.$mapped_attributes_options[$key]['store_attribute'].'" class="col-sm-12 col-md-8 col-lg-8 text-left" name="etsy_category['.$key.'][store_attribute]" onkeyup="getBrand(this)" data-id="'.$key.'">';
                    } else {
                        $html .= '<input type="text" class="col-sm-12 col-md-8 col-lg-8 text-left" name="etsy_category['.$key.'][store_attribute]" onkeyup="getBrand(this)" data-id="'.$key.'">';
                    }
                }
                $html .= '</td>';
                $html .= '</tr>';
            }
            //echo '<pre>'; print_r($html); die;
            die($html);
        } else {
            die($html);
        }
    }

    public function ajaxProcessGetStoreOptions()
    {
        $returnResponse = array();
        $data = Tools::getAllValues();
        if (isset($data['filter_name']) && !empty($data['filter_name']) && isset($data['attribute_group_id']) && !empty($data['attribute_group_id']) && isset($data['catId']) && !empty($data['catId'])) {
            $attribute_group_id = $data['attribute_group_id']; 
            $type_array = explode('-', $attribute_group_id );
            if (isset($type_array['0']) && ($type_array['0']=='product')){
                // Manufacturer::getManufacturers(false, 0, true, false, false, false, true);
                $returnResponse = $this->CedEtsyCategory->getManufacturers(array('filter_name' => $data['filter_name']));
            } else if (isset($type_array['0']) && ($type_array['0']=='option')){
                $returnResponse = $this->CedEtsyCategory->getStoreOptions($data['catId'],$type_array['1'], $data['filter_name']);
            }
        }
        die(Tools::jsonEncode($returnResponse));
    }

    public function ajaxProcessBrandAuto()
    {
        $returnResponse = array();
        $data = Tools::getAllValues();
        if (isset($data['filter_name']) && !empty($data['filter_name']) && isset($data['attribute_id']) && !empty($data['attribute_id']) && isset($data['catId']) && !empty($data['catId'])) {
            $attribute_id = $data['attribute_id']; 
            $returnResponse = $this->CedEtsyCategory->getBrands($data['catId'],$attribute_id, $data['filter_name']);
        }
        die(Tools::jsonEncode($returnResponse));
    }

    public function ajaxProcessStoreOptionValue()
    {
        $html = '';
        $id_attribute_group_value = Tools::getValue('id_attribute_group');
        $key = Tools::getValue('key');
        $options = $this->CedEtsyCategory->storeOptions();
        if(isset($options['option_values']) && !empty($options['option_values'])){
            foreach($options['option_values'] as $id_attribute_group => $option_values){
                if($id_attribute_group_value == $id_attribute_group)
                {
                    $html .= '<select name="etsy_category['.$key.'][option][store_attribute]" data-id="'.$key.'" class="col-sm-12 col-md-8 col-lg-8 text-left">';
                    foreach($option_values as $option_value){
                        $html .= "<option value='".$option_value['id_attribute']."'>";
                        $html .= $option_value['name'];
                        $html .= "</option>";
                    }
                    $html .= '</select>';
                }
            }
            die($html);
        } else {
            die('No Option Value Available.');
        }
        
    }

}