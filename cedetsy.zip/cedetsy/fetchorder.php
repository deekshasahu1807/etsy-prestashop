<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedEtsy
 */

include(dirname(__FILE__).'/../../config/config.inc.php');
include_once(_PS_MODULE_DIR_.'cedetsy/classes/CedEtsyOrder.php');
include_once(_PS_MODULE_DIR_.'cedetsy/classes/CedEtsyHelper.php');


if (!Tools::getIsset('secure_key')
 || Tools::getValue('secure_key') != Configuration::get('CEDETSY_CRON_SECURE_KEY')) {
    die('Secure key does not matched');
}

try {
    $CedEtsyOrder = new CedEtsyOrder();
    $CedEtsyHelper = new CedEtsyHelper();
    $res = $CedEtsyOrder->fetchOrder();
    $CedEtsyHelper->log(
        'CronOrderFetch',
        'Info',
        'Cron For Order Fetch',
        ''
    );
} catch (Exception $e) {
    $CedEtsyHelper->log(
        'CronOrderFetch',
        'Exception',
        $e->getMessage(),
        Tools::jsonEncode(
            array(
                'Trace' => $e->getTraceAsString()
            )
        ),
        true
    );
}
